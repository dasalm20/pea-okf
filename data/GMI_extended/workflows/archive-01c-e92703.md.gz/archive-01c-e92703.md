# 01.Programs/archive/01c-GMI extended spells pov elasticity.do

PIP/GDP spell elasticities and descriptive regressions

Status: PARTIAL_STATIC. Every lexically active statement is indexed; complete runtime schema and macro expansion are not established.

Source snapshot: numbered source (deployment lookup: lookup/sources/GMI_extended/source_maps/archive-01c-e92703.md.md)

## Execution-order blocks

### block:ee96c3521997aa58

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L3-L3`. Next: `block:fb82e808c06b1f40`.

```stata
clear
```

### block:fb82e808c06b1f40

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L4-L4`. Next: `block:3a71b7db0f5224c3`.

```stata
tempfile pfw pip1 pip2 datagic dataall dataall2 prosdecomp
```

### block:3a71b7db0f5224c3

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L5-L5`. Next: `block:282b2b7f1cfec029`.

```stata
save `datagic', replace emptyok
```
Write datasets: `dataset:af27dd769958b449`

### block:282b2b7f1cfec029

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L6-L6`. Next: `block:9f5485b1aa379eda`.

```stata
save `prosdecomp', replace emptyok
```
Write datasets: `dataset:fdc113803a551220`

### block:9f5485b1aa379eda

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L7-L7`. Next: `block:a4e78eb924c027a0`.

```stata
save `dataall', replace emptyok
```
Write datasets: `dataset:73668592124500c3`

### block:a4e78eb924c027a0

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L8-L8`. Next: `block:4942b2221e4daf93`.

```stata
save `dataall2', replace emptyok
```
Write datasets: `dataset:d27fe1c915650afb`

### block:4942b2221e4daf93

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L10-L10`. Next: `block:858c33e25e327197`.

```stata
set varabbrev off
```

### block:858c33e25e327197

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L12-L12`. Next: `block:76b6ba7ff692f4a3`.

```stata
global rnd SM26
```

### block:76b6ba7ff692f4a3

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L13-L13`. Next: `block:60ec5d7da751a4d0`.

```stata
global path \\wbgfscifs01\GTSD\03.projects_corp\04.GPWG\04.GPWG_${rnd}\04.GPWG_${rnd}_QA
```

### block:60ec5d7da751a4d0

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L14-L14`. Next: `block:a55c3b1720a7dac5`.

```stata
global reposource "${path}\01.programs\02.dofile\repo\"
```

### block:a55c3b1720a7dac5

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L16-L16`. Next: `block:8fa840d1db329147`.

```stata
global out D:\daylan\test\GMI\out\
```

### block:8fa840d1db329147

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L17-L17`. Next: `block:97de45d7bb632363`.

```stata
global pea "${out}\04.output\PEA_Dashboard\"
```

### block:97de45d7bb632363

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L19-L19`. Next: `block:b042f5f6125bc61c`.

```stata
global ppplist 2017 2021
```

### block:b042f5f6125bc61c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L20-L20`. Next: `block:59a74f48be4cb49d`.

```stata
global pppmax 2021
```

### block:59a74f48be4cb49d

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L22-L22`. Next: `block:d7b74054b9c84762`.

```stata
global floor2021 0.28
```

### block:d7b74054b9c84762

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L23-L23`. Next: `block:dc7731375937f8f4`.

```stata
global gap2021 28
```

### block:dc7731375937f8f4

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L24-L24`. Next: `block:4e8a888952e1c879`.

```stata
global floor2017 0.25
```

### block:4e8a888952e1c879

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L25-L25`. Next: `block:6096ab378fbb0460`.

```stata
global gap2017 25
```

### block:6096ab378fbb0460

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L26-L26`. Next: `block:ff2c87d2800618f7`.

```stata
global floor2011 0.22
```

### block:ff2c87d2800618f7

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L27-L27`. Next: `block:91ada2a8d27c0451`.

```stata
global gap2011 22
```

### block:91ada2a8d27c0451

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L29-L29`. Next: `block:b47beb3426e706b6`.

```stata
global plines2021 300 420 830 450 630 1245 600 840 1660
```

### block:b47beb3426e706b6

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L30-L30`. Next: `block:2b55f5c5dd68b917`.

```stata
global plines2017 215 365 685 322 547 1027 430 730 1370
```

### block:2b55f5c5dd68b917

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L31-L31`. Next: `block:265bd7d85ba06a78`.

```stata
global plines2011 190 320 550
```

### block:265bd7d85ba06a78

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L32-L32`. Next: `block:a934c58af4af62b1`.

```stata
global cpiversion Support_2005_CPI_V15_M
```

### block:a934c58af4af62b1

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L34-L34`. Next: `block:0584004d1ea2bbe7`.

```stata
global pfw "D:\daylan\test\GMI\Survey_price_framework.dta"
```

### block:0584004d1ea2bbe7

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L35-L35`. Next: `block:944d9726c03a83f8`.

```stata
global repotxt repo(use ${rnd}all) reporoot(${reposource})
```

### block:944d9726c03a83f8

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L38-L38`. Next: `block:6ad001d05d2b45d7`.

```stata
dlw, country(support) year(2005) type(gmdraw) surveyid(${cpiversion}) filename(Survey_price_framework.dta) files
```
Read datasets: `dataset:04255bd89c92b8bf`

### block:6ad001d05d2b45d7

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L39-L39`. Next: `block:a609a51e7d286c4e`.

```stata
keep code year rep_year datatype display_cp survname
```
Read candidates: `variable:70b408586be84950`, `variable:97419472ac075c15`, `variable:bce80199592ce025`, `variable:cc25e73837257ded`, `variable:dfa04b6d3264c0e0`, `variable:8e6a10320ee7ea4f`

### block:a609a51e7d286c4e

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L40-L40`. Next: `block:595f3745c421f069`.

```stata
gen		welfare_type = 1 if datatype == "CONS" | datatype == "C" | datatype == "c"
```
New: `variable:d91aa609b388c1a6`
Read candidates: `variable:cc25e73837257ded`

### block:595f3745c421f069

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L41-L41`. Next: `block:e8ff75f66a64d597`.

```stata
replace welfare_type = 2 if datatype == "INC" | datatype == "I" | datatype == "i"
```
Modified: `variable:d91aa609b388c1a6`
Read candidates: `variable:cc25e73837257ded`

### block:e8ff75f66a64d597

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L42-L42`. Next: `block:3995dbb9b98fdf86`.

```stata
save `pfw', replace
```
Write datasets: `dataset:44c3bb3f5096947e`

### block:3995dbb9b98fdf86

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L45-L45`. Next: `block:25e2fb616087b6bd`.

```stata
use D:\daylan\test\GMI\pip2021.dta, clear
```
Read datasets: `dataset:93a3a240ca14601f`

### block:25e2fb616087b6bd

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L46-L46`. Next: `block:910ea0d76472a0bd`.

```stata
isid country_code year survey_acronym welfare_type
```
Read candidates: `variable:68eda82fd91123c1`, `variable:b900f539c2a356e1`, `variable:356d5d41204bc1e9`, `variable:15b9e6355b3d703d`

### block:910ea0d76472a0bd

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L47-L47`. Next: `block:3c95fc5cd5f0895f`.

```stata
keep country_code year survey_acronym welfare_type fgt0_*
```
Read candidates: `variable:68eda82fd91123c1`, `variable:b900f539c2a356e1`, `variable:356d5d41204bc1e9`, `variable:15b9e6355b3d703d`, `variable:15bf1295f4f8e5c1`

### block:3c95fc5cd5f0895f

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L48-L48`. Next: `block:61b3f3f094e4ed7c`.

```stata
reshape long fgt0_, i(country_code year survey_acronym welfare_type) j(povline)
```
Read candidates: `variable:15bf1295f4f8e5c1`, `variable:68eda82fd91123c1`, `variable:b900f539c2a356e1`, `variable:356d5d41204bc1e9`, `variable:15b9e6355b3d703d`, `variable:3498f1f521c0edb1`

### block:61b3f3f094e4ed7c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L49-L49`. Next: `block:22556ff2d1d12aaa`.

```stata
gen ppp = 2021
```
New: `variable:4bd2b36dd3e8c8f9`

### block:22556ff2d1d12aaa

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L50-L50`. Next: `block:c7680ebcfdbdcfce`.

```stata
save `pip1', replace
```
Write datasets: `dataset:be76a69895cf6940`

### block:c7680ebcfdbdcfce

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L52-L52`. Next: `block:3cfa5f72ddfc6b6f`.

```stata
use D:\daylan\test\GMI\pip2017.dta, clear
```
Read datasets: `dataset:cd1049bf073c2c02`

### block:3cfa5f72ddfc6b6f

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L53-L53`. Next: `block:4b5a679b6f9db7e4`.

```stata
isid country_code year survey_acronym welfare_type
```
Read candidates: `variable:9c68541df32f4b2c`, `variable:d4aa0ad11410555d`, `variable:04e9a303b857fa77`, `variable:cd05bd629a29703a`

### block:4b5a679b6f9db7e4

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L54-L54`. Next: `block:4b2fc72625baec7f`.

```stata
keep country_code year survey_acronym welfare_type fgt0_*
```
Read candidates: `variable:9c68541df32f4b2c`, `variable:d4aa0ad11410555d`, `variable:04e9a303b857fa77`, `variable:cd05bd629a29703a`, `variable:37e1855f15d1c987`

### block:4b2fc72625baec7f

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L55-L55`. Next: `block:de29b70c222febc4`.

```stata
reshape long fgt0_, i(country_code year survey_acronym welfare_type) j(povline)
```
Read candidates: `variable:37e1855f15d1c987`, `variable:9c68541df32f4b2c`, `variable:d4aa0ad11410555d`, `variable:04e9a303b857fa77`, `variable:cd05bd629a29703a`, `variable:6e03f46cc7f210c3`

### block:de29b70c222febc4

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L56-L56`. Next: `block:cbe543d4b4d7ca14`.

```stata
gen ppp = 2017
```
New: `variable:058426bcea56f4fc`

### block:cbe543d4b4d7ca14

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L57-L57`. Next: `block:83f8163d6eb5630a`.

```stata
append using `pip1'
```
Read datasets: `dataset:be76a69895cf6940`

### block:83f8163d6eb5630a

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L58-L58`. Next: `block:07f9014dbed118a6`.

```stata
ren country_code code
```
New: `variable:49d6364814975cfe`
Read candidates: `variable:9c68541df32f4b2c`

### block:07f9014dbed118a6

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L59-L59`. Next: `block:3323cf163429963d`.

```stata
merge m:1 code year using D:\daylan\test\GMI\PIP_all_GDP.dta, keepus(gdppc)
```
Read datasets: `dataset:d9f5186f9fae8360`

### block:3323cf163429963d

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L60-L60`. Next: `block:6a18bb4c07c4e8e8`.

```stata
drop if _merge==2
```
Read candidates: `variable:cbebacf7bf4fc38b`

### block:6a18bb4c07c4e8e8

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L61-L61`. Next: `block:dd918fa0e67d308e`.

```stata
drop _merge
```
Read candidates: `variable:cbebacf7bf4fc38b`

### block:dd918fa0e67d308e

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L62-L62`. Next: `block:54173463a9ff16d3`.

```stata
gen welftype = "CONS" if welfare_type==1
```
New: `variable:5fd7415b971d98d5`
Read candidates: `variable:cd05bd629a29703a`

### block:54173463a9ff16d3

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L63-L63`. Next: `block:eef6e4ad1ee73194`.

```stata
replace welftype = "INC" if welfare_type==2
```
Modified: `variable:5fd7415b971d98d5`
Read candidates: `variable:cd05bd629a29703a`

### block:eef6e4ad1ee73194

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L64-L64`. Next: `block:995b86112d4c5cac`.

```stata
ren survey_acronym survname
```
New: `variable:4b88532292726192`
Read candidates: `variable:04e9a303b857fa77`

### block:995b86112d4c5cac

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L65-L65`. Next: `block:7b3099b9c0ab9e03`.

```stata
ren year rep_year
```
New: `variable:f6fd0cd72c986604`
Read candidates: `variable:d4aa0ad11410555d`

### block:7b3099b9c0ab9e03

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L66-L66`. Next: `block:c816b016783ce074`.

```stata
merge m:1 code rep_year welfare_type survname using `pfw', nogen
```
Read datasets: `dataset:44c3bb3f5096947e`

### block:c816b016783ce074

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L67-L67`. Next: `block:e851a7a31f1bfbd8`.

```stata
drop if display_cp == 0 | display_cp == .
```
Read candidates: `variable:0a96f16f3c3a148c`

### block:e851a7a31f1bfbd8

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L68-L68`. Next: `block:7b5972dbd0dc4610`.

```stata
save `pip1', replace
```
Write datasets: `dataset:be76a69895cf6940`

### block:7b5972dbd0dc4610

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L71-L71`. Next: `block:bcde7c9a1adab84a`.

```stata
tempfile data1 data2
```

### block:bcde7c9a1adab84a

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L72-L72`. Next: `block:9e996182cc32b537`.

```stata
use \\wbgfscifs01\GTSD\03.projects_corp\04.GPWG\04.GPWG_${rnd}\04.GPWG_${rnd}_QA\01.programs\02.dofile\repo\repo_${rnd}all.dta , clear
```
Read datasets: `dataset:96215c3f23c334b3`

### block:9e996182cc32b537

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L73-L73`. Next: `block:e82da32cd79caa91`.

```stata
gen year = years
```
New: `variable:66d95f7dd84cbfd8`
Read candidates: `variable:055f489047ae048a`

### block:e82da32cd79caa91

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L74-L74`. Next: `block:839bcd0e152f8c96`.

```stata
destring year, replace
```
Modified: `variable:66d95f7dd84cbfd8`
Read candidates: `variable:66d95f7dd84cbfd8`

### block:839bcd0e152f8c96

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L75-L75`. Next: `block:a2f81130e181704c`.

```stata
ren country countrycode
```
New: `variable:cba835939c6358ce`
Read candidates: `variable:4a12791ce0f1c835`

### block:a2f81130e181704c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L76-L76`. Next: `block:bf3ad447e2e61661`.

```stata
keep if module=="ALL"
```
Read candidates: `variable:150217580bbc0f97`

### block:bf3ad447e2e61661

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L77-L77`. Next: `block:556ab276381c30b7`.

```stata
save `data1', replace
```
Write datasets: `dataset:679e685480a83997`

### block:556ab276381c30b7

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L79-L79`. Next: `block:cc80624407518807`.

```stata
use "\\wbgfscifs01\GTSD\03.projects_corp\06.GMI\06.GMI_${rnd}\06.GMI_${rnd}_QA\03.output\01.data\GMI_SPspell_all.dta" , clear
```
Read datasets: `dataset:4f0ea2547d8ecc02`

### block:cc80624407518807

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L80-L80`. Next: `block:228aeb24a50339de`.

```stata
drop if datamod=="bin"
```
Read candidates: `variable:209654ea999cbf7c`

### block:228aeb24a50339de

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L81-L81`. Next: `block:bb5a2338af2fa01b`.

```stata
drop if countrycode=="ISO3"|countrycode=="ISO3"|countrycode=="ISO3"|countrycode=="ISO3"
```
Read candidates: `variable:089611c70fd751c6`

### block:bb5a2338af2fa01b

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L82-L82`. Next: `block:3da535c8eaf8ac24`.

```stata
ren surveyname survname
```
New: `variable:f3e7ce241e0f6096`
Read candidates: `variable:4f6288d6219aa5fe`

### block:3da535c8eaf8ac24

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L83-L83`. Next: `block:be811e0109391ee2`.

```stata
merge m:m countrycode year survname using `data1', keepus(module)
```
Read datasets: `dataset:679e685480a83997`

### block:be811e0109391ee2

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L84-L84`. Next: `block:32d989ed3d7d68ec`.

```stata
drop if _merge==2
```
Read candidates: `variable:42203381475afe7a`

### block:32d989ed3d7d68ec

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L86-L86`. Next: `block:b9daac75ef331c30`.

```stata
bys countrycode period welftype (year): gen seq = _N
```
New: `variable:507a1acde0fda185`
Read candidates: `variable:089611c70fd751c6`, `variable:048e3d6297b4f165`, `variable:593d2dbbe2a7199c`

### block:b9daac75ef331c30

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L87-L87`. Next: `block:e3a087c5fc2bdc13`.

```stata
bys countrycode period welftype (year): gen seq1 = _n
```
New: `variable:e536ae26211c8a44`
Read candidates: `variable:089611c70fd751c6`, `variable:048e3d6297b4f165`, `variable:593d2dbbe2a7199c`

### block:e3a087c5fc2bdc13

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L88-L88`. Next: `block:5207d70f3a796c5d`.

```stata
drop if seq==1
```
Read candidates: `variable:507a1acde0fda185`

### block:5207d70f3a796c5d

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L89-L89`. Next: `block:28a47544e29bb7d2`.

```stata
drop seq _merge ref rep region welvar datamod filename
```
Read candidates: `variable:507a1acde0fda185`, `variable:42203381475afe7a`, `variable:1855caa9e81b1e96`, `variable:961c3613083d54bc`, `variable:305e844b810cd628`, `variable:7a35efefb15baba7`, `variable:209654ea999cbf7c`, `variable:e7ea9fec525a5fe3`

### block:28a47544e29bb7d2

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L90-L90`. Next: `block:685337a03528b8d4`.

```stata
replace module="MIS" if module==""
```
Modified: `variable:df0f6b50a406fa1e`
Read candidates: `variable:df0f6b50a406fa1e`

### block:685337a03528b8d4

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L92-L92`. Next: `block:b656b1200b638932`.

```stata
reshape wide year survname module, i(countrycode period welftype) j(seq1)
```
Read candidates: `variable:102dae33710634e1`, `variable:593d2dbbe2a7199c`, `variable:f3e7ce241e0f6096`, `variable:df0f6b50a406fa1e`, `variable:089611c70fd751c6`, `variable:048e3d6297b4f165`, `variable:383c32d374b11513`, `variable:e536ae26211c8a44`

### block:b656b1200b638932

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L93-L93`. Next: `block:5b45b1ed2a2dabb6`.

```stata
gen type = 0
```
New: `variable:848e17b2f5b755ef`

### block:5b45b1ed2a2dabb6

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L94-L94`. Next: `block:c0194627eadf3ade`.

```stata
replace type = 1 if module1=="ALL" & module2=="ALL"
```
Modified: `variable:848e17b2f5b755ef`
Read candidates: `variable:93b318bb9e345716`, `variable:86468bf19a8c0006`

### block:c0194627eadf3ade

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L95-L95`. Next: `block:9c74d911f8178d66`.

```stata
drop if countrycode=="ISO3" & year1==0000
```
Read candidates: `variable:089611c70fd751c6`, `variable:d2cd8a72a6192a72`

### block:9c74d911f8178d66

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L97-L97`. Next: `block:4e93518e8325f011`.

```stata
local nobs = _N
```

### block:4e93518e8325f011

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L98-L98`. Next: `block:3cd520f5b579a08d`.

```stata
save `data1', replace
```
Write datasets: `dataset:679e685480a83997`

### block:3cd520f5b579a08d

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L100-L100`. Next: `block:5a060e3f5fb5514f`.

```stata
keep countrycode welftype period year1 survname1 module1
```
Read candidates: `variable:089611c70fd751c6`, `variable:383c32d374b11513`, `variable:048e3d6297b4f165`, `variable:d2cd8a72a6192a72`, `variable:fb4b4488f24680f4`, `variable:93b318bb9e345716`

### block:5a060e3f5fb5514f

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L101-L101`. Next: `block:479c1d68f6fdcd91`.

```stata
ren year1 year
```
New: `variable:593d2dbbe2a7199c`
Read candidates: `variable:d2cd8a72a6192a72`

### block:479c1d68f6fdcd91

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L102-L102`. Next: `block:cacc74cedbf56a57`.

```stata
ren survname1 survname
```
New: `variable:f3e7ce241e0f6096`
Read candidates: `variable:fb4b4488f24680f4`

### block:cacc74cedbf56a57

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L103-L103`. Next: `block:dfc2ae46eac24a9d`.

```stata
ren module1 module
```
New: `variable:df0f6b50a406fa1e`
Read candidates: `variable:93b318bb9e345716`

### block:dfc2ae46eac24a9d

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L104-L104`. Next: `block:e294b19f05008cd4`.

```stata
save `data2', replace
```
Write datasets: `dataset:c5e926fe224a401c`

### block:e294b19f05008cd4

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L106-L106`. Next: `block:8d853651e4638195`.

```stata
use `data1', clear
```
Read datasets: `dataset:679e685480a83997`

### block:8d853651e4638195

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L107-L107`. Next: `block:68023c11b85dfbdc`.

```stata
keep countrycode welftype period year2 survname2 module2
```
Read candidates: `variable:82ced8cb3de77b1d`, `variable:f01e40c87f660aa2`, `variable:1cb73cbf48bb4e0c`, `variable:7ad2fadc3dd50fb2`, `variable:c6a0dad7153c171a`, `variable:5c52acb45ac82c52`

### block:68023c11b85dfbdc

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L108-L108`. Next: `block:9d1e1acd92e5e5d8`.

```stata
ren year2 year
```
New: `variable:a13ab8b931f0dcfa`
Read candidates: `variable:7ad2fadc3dd50fb2`

### block:9d1e1acd92e5e5d8

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L109-L109`. Next: `block:264ac30dceacf583`.

```stata
ren survname2 survname
```
New: `variable:a1e27acf93c85b22`
Read candidates: `variable:c6a0dad7153c171a`

### block:264ac30dceacf583

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L110-L110`. Next: `block:496c8743a15b4cd2`.

```stata
ren module2 module
```
New: `variable:fa8666d356d5676d`
Read candidates: `variable:5c52acb45ac82c52`

### block:496c8743a15b4cd2

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L111-L111`. Next: `block:cb5c93f5f6e8dfdf`.

```stata
append using `data2'
```
Read datasets: `dataset:c5e926fe224a401c`

### block:cb5c93f5f6e8dfdf

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L112-L112`. Next: `block:c0a7601506ecb159`.

```stata
ren countrycode code
```
New: `variable:12013531d4db1eef`
Read candidates: `variable:82ced8cb3de77b1d`

### block:c0a7601506ecb159

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L113-L113`. Next: `block:988729c4d3857458`.

```stata
save `data2', replace
```
Write datasets: `dataset:c5e926fe224a401c`

### block:988729c4d3857458

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L115-L115`. Next: `block:214a5c84319ff590`.

```stata
joinby code year survname welftype using `pip1'
```
Read datasets: `dataset:be76a69895cf6940`

### block:214a5c84319ff590

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L117-L117`. Next: `block:3684d14057fe39dc`.

```stata
sort ppp code  welftype povline period year
```

### block:3684d14057fe39dc

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L118-L118`. Next: `block:559e74e007ff847f`.

```stata
bys ppp code  welftype povline period (year): gen x = _N
```
New: `variable:65948095f1b2f0d9`
Read candidates: `variable:8521ea4d834ef6db`, `variable:12013531d4db1eef`, `variable:f01e40c87f660aa2`, `variable:28d12dd95259376b`, `variable:a13ab8b931f0dcfa`

### block:559e74e007ff847f

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L119-L119`. Next: `block:aa0ca38b493b24e2`.

```stata
ta x
```
Read candidates: `variable:65948095f1b2f0d9`

### block:aa0ca38b493b24e2

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L120-L120`. Next: `block:7a1a0a91a2c0f494`.

```stata
drop if x==1
```
Read candidates: `variable:65948095f1b2f0d9`

### block:7a1a0a91a2c0f494

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L121-L121`. Next: `block:d6e941fc884f269c`.

```stata
drop x
```
Read candidates: `variable:65948095f1b2f0d9`

### block:d6e941fc884f269c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L122-L122`. Next: `block:904b08fddf7c7d65`.

```stata
bys ppp code  welftype povline period (year): gen ch_fgt0 = ln(fgt0_[2]/fgt0_[1])
```
New: `variable:7acc830cc123f09f`
Read candidates: `variable:b778e64e1d18c297`, `variable:8521ea4d834ef6db`, `variable:12013531d4db1eef`, `variable:f01e40c87f660aa2`, `variable:28d12dd95259376b`, `variable:a13ab8b931f0dcfa`

### block:904b08fddf7c7d65

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L123-L123`. Next: `block:bd4aaa707125f146`.

```stata
bys ppp code  welftype povline period (year): gen ch_gdppc = ln(gdppc[2]/gdppc[1])
```
New: `variable:7fae3c43c5ddaa14`
Read candidates: `variable:3d20f63bb8048e0e`, `variable:8521ea4d834ef6db`, `variable:12013531d4db1eef`, `variable:f01e40c87f660aa2`, `variable:28d12dd95259376b`, `variable:a13ab8b931f0dcfa`

### block:bd4aaa707125f146

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L124-L124`. Next: `block:915108ad5ef5b31e`.

```stata
bys ppp code  welftype povline period (year): gen ch_year = year[2]-year[1]
```
New: `variable:9e1544a4c5844b02`
Read candidates: `variable:a13ab8b931f0dcfa`, `variable:8521ea4d834ef6db`, `variable:12013531d4db1eef`, `variable:f01e40c87f660aa2`, `variable:28d12dd95259376b`

### block:915108ad5ef5b31e

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L125-L125`. Next: `block:ee1297150a193930`.

```stata
bys ppp code  welftype povline period (year): gen gr_fgt0 = ((fgt0_[2]/fgt0_[1])^(1/(year[2]-year[1])) -1)*100
```
New: `variable:d88734e25000c35b`
Read candidates: `variable:b778e64e1d18c297`, `variable:a13ab8b931f0dcfa`, `variable:8521ea4d834ef6db`, `variable:12013531d4db1eef`, `variable:f01e40c87f660aa2`, `variable:28d12dd95259376b`

### block:ee1297150a193930

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L126-L126`. Next: `block:5e58d05de116af72`.

```stata
bys ppp code  welftype povline period (year): gen gr_gdppc = ((gdppc[2]/gdppc[1])^(1/(year[2]-year[1])) -1)*100
```
New: `variable:67cf73a9d79c122f`
Read candidates: `variable:3d20f63bb8048e0e`, `variable:a13ab8b931f0dcfa`, `variable:8521ea4d834ef6db`, `variable:12013531d4db1eef`, `variable:f01e40c87f660aa2`, `variable:28d12dd95259376b`

### block:5e58d05de116af72

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L127-L127`. Next: `block:7d6f1f4a5c78bc2b`.

```stata
gen double pov_elasticity = ch_fgt0/ch_gdppc
```
New: `variable:5e62b36d1ecf2790`
Read candidates: `variable:7acc830cc123f09f`, `variable:7fae3c43c5ddaa14`

### block:7d6f1f4a5c78bc2b

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L128-L128`. Next: `block:3c44b2a00a7accb8`.

```stata
gen double pov_elasticity2 = gr_fgt0/gr_gdppc
```
New: `variable:99734a6250b00a63`
Read candidates: `variable:d88734e25000c35b`, `variable:67cf73a9d79c122f`

### block:3c44b2a00a7accb8

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L129-L129`. Next: `block:9698293816ae043c`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_pov_elas_raw", replace
```
Write datasets: `dataset:31557146f904dbda`

### block:9698293816ae043c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L132-L132`. Next: `block:39591f97d210aad8`.

```stata
keep code welftype period povline ppp ch_fgt0 ch_gdppc ch_year pov_elasticity gr_fgt0 gr_gdppc pov_elasticity2
```
Read candidates: `variable:12013531d4db1eef`, `variable:f01e40c87f660aa2`, `variable:1cb73cbf48bb4e0c`, `variable:28d12dd95259376b`, `variable:8521ea4d834ef6db`, `variable:7acc830cc123f09f`, `variable:7fae3c43c5ddaa14`, `variable:9e1544a4c5844b02`, `variable:5e62b36d1ecf2790`, `variable:d88734e25000c35b`, `variable:67cf73a9d79c122f`, `variable:99734a6250b00a63`

### block:39591f97d210aad8

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L133-L133`. Next: `block:22d8cf62aaeee126`.

```stata
duplicates drop _all, force
```

### block:22d8cf62aaeee126

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L134-L134`. Next: `block:e8ac90cf01076f59`.

```stata
la var ch_fgt0 		"Change in poverty rate (difference in log)"
```

### block:e8ac90cf01076f59

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L135-L135`. Next: `block:b32954932ee7a804`.

```stata
la var ch_gdppc 	"Change in GDP per capita (difference in log)"
```

### block:b32954932ee7a804

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L136-L136`. Next: `block:4cd8ceae5ab68522`.

```stata
la var pov_elasticity 	   	"GPD-poverty elasticity (annualized)"
```

### block:4cd8ceae5ab68522

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L138-L138`. Next: `block:ee2558eb6e36eabb`.

```stata
la var gr_fgt0 		"Change in poverty rate (annualized growth)"
```

### block:ee2558eb6e36eabb

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L139-L139`. Next: `block:2fdbbf6ccac2b9ee`.

```stata
la var gr_gdppc 	"Change in GDP per capita (annualized growth)"
```

### block:2fdbbf6ccac2b9ee

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L140-L140`. Next: `block:8eed7f4bf60c3216`.

```stata
la var pov_elasticity2 	   	"GPD-poverty elasticity (annualized growth)"
```

### block:8eed7f4bf60c3216

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L142-L142`. Next: `block:5ee5b0e2d3584ed6`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_pov_elas_fmt", replace
```
Write datasets: `dataset:5eceb36819fd2743`

### block:5ee5b0e2d3584ed6

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L143-L143`. Next: `block:3a37fe06ad892b54`.

```stata
save "${pea}\GMI_extended_pov_elas_fmt", replace
```
Write datasets: `dataset:085509f7e55fbfe3`

### block:3a37fe06ad892b54

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L146-L146`. Next: `block:43322eeeeae8bb3c`.

```stata
tempfile data10
```

### block:43322eeeeae8bb3c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L147-L147`. Next: `block:6c8cee2413faa3ae`.

```stata
use D:\daylan\test\GMI\CLASS_incg_region.dta, clear
```
Read datasets: `dataset:bd13cd17c8fc0d7e`

### block:6c8cee2413faa3ae

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L148-L148`. Next: `block:8926da7d76b52ee7`.

```stata
su year, meanonly
```
Read candidates: `variable:f733271f4c772ae2`, `variable:5874897c5ec10525`

### block:8926da7d76b52ee7

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L149-L149`. Next: `block:f17cec4f35937d6b`.

```stata
local ymax = r(max)
```

### block:f17cec4f35937d6b

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L150-L150`. Next: `block:55c325f4770bdf4a`.

```stata
keep if year==`ymax'
```
Read candidates: `variable:f733271f4c772ae2`

### block:55c325f4770bdf4a

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L151-L151`. Next: `block:3e5c904792da571f`.

```stata
save `data10', replace
```
Write datasets: `dataset:f0b99e403d08d0aa`

### block:3e5c904792da571f

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L153-L153`. Next: `block:5ddaf988c3ec1c37`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_pov_elas_fmt", clear
```
Read datasets: `dataset:5eceb36819fd2743`

### block:5ddaf988c3ec1c37

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L154-L154`. Next: `block:e4fb2698b8d7cb78`.

```stata
merge m:1 code using `data10', keepus(region region_pip region_SSA incgroup_current)
```
Read datasets: `dataset:f0b99e403d08d0aa`

### block:e4fb2698b8d7cb78

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L155-L155`. Next: `block:cc0543bf485fd455`.

```stata
drop if _merge==2
```
Read candidates: `variable:7cc41083eac78742`

### block:cc0543bf485fd455

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L156-L156`. Next: `block:00eddc61ffc05950`.

```stata
drop _merge
```
Read candidates: `variable:7cc41083eac78742`

### block:00eddc61ffc05950

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L158-L158`. Next: `block:54e5998fa52cc8f4`.

```stata
gen lnline = ln(povline)
```
New: `variable:7f44e68439d28947`
Read candidates: `variable:0d96c6f5038f134f`

### block:54e5998fa52cc8f4

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L159-L159`. Next: `block:b6eddb6d9d1889c1`.

```stata
encode welftype, gen(type)
```
New: `variable:c861e1ec3a636212`
Read candidates: `variable:31f1c45a38139712`

### block:b6eddb6d9d1889c1

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L160-L160`. Next: `block:483e81844b00e99c`.

```stata
encode region, gen(region2)
```
New: `variable:0ad2ac3ef8bfe8a1`
Read candidates: `variable:f4ef2fecc5bd36a8`

### block:483e81844b00e99c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L161-L161`. Next: `block:3dd34ca390549b30`.

```stata
encode region_pip, gen(region_pip2)
```
New: `variable:2250e22157b43969`
Read candidates: `variable:90d12816030f97ee`

### block:3dd34ca390549b30

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L162-L162`. Next: `block:e2ddfcefc8bd9f92`.

```stata
encode incgroup_current, gen(incgroup_current2)
```
New: `variable:6b47bd8d947026f2`
Read candidates: `variable:666f7749a77a689c`

### block:e2ddfcefc8bd9f92

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L165-L165`. Next: `block:9e528c898bbb5e64`.

```stata
reg ch_fgt0 ch_gdppc lnline i.type i.region2 i.incgroup_current2 if  ppp==2021
```
Read candidates: `variable:f7883e1c6eb6b4bb`, `variable:21835225188c4010`, `variable:7f44e68439d28947`, `variable:c505ca5d828c9acf`, `variable:c861e1ec3a636212`, `variable:0ad2ac3ef8bfe8a1`, `variable:6b47bd8d947026f2`, `variable:9c10115065b0f5fc`

### block:9e528c898bbb5e64

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L167-L167`. Next: `block:08afb4620f410ea6`.

```stata
bys region2: reg ch_fgt0 ch_gdppc lnline i.type  if  ppp==2021
```
Read candidates: `variable:f7883e1c6eb6b4bb`, `variable:21835225188c4010`, `variable:7f44e68439d28947`, `variable:c505ca5d828c9acf`, `variable:c861e1ec3a636212`, `variable:9c10115065b0f5fc`

### block:08afb4620f410ea6

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L169-L169`. Next: `block:6acf3e0e4169d14c`.

```stata
bys incgroup_current2: reg ch_fgt0 ch_gdppc lnline i.type  if  ppp==2021
```
Read candidates: `variable:f7883e1c6eb6b4bb`, `variable:21835225188c4010`, `variable:7f44e68439d28947`, `variable:c505ca5d828c9acf`, `variable:c861e1ec3a636212`, `variable:9c10115065b0f5fc`

### block:6acf3e0e4169d14c

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L172-L172`. Next: `block:4bbb36aa08d38265`.

```stata
reg ch_fgt0 ch_gdppc  i.type i.region2 i.incgroup_current2 if  ppp==2021 & povline==300
```
Read candidates: `variable:f7883e1c6eb6b4bb`, `variable:21835225188c4010`, `variable:c505ca5d828c9acf`, `variable:c861e1ec3a636212`, `variable:0ad2ac3ef8bfe8a1`, `variable:6b47bd8d947026f2`, `variable:9c10115065b0f5fc`, `variable:0d96c6f5038f134f`

### block:4bbb36aa08d38265

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L174-L174`. Next: `block:daca57e8726e3a21`.

```stata
bys region2: reg ch_fgt0 ch_gdppc  i.type  if  ppp==2021 & povline==300
```
Read candidates: `variable:f7883e1c6eb6b4bb`, `variable:21835225188c4010`, `variable:c505ca5d828c9acf`, `variable:c861e1ec3a636212`, `variable:9c10115065b0f5fc`, `variable:0d96c6f5038f134f`

### block:daca57e8726e3a21

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L176-L176`. Next: `block:d88ea2f21bb2378e`.

```stata
bys incgroup_current2: reg ch_fgt0 ch_gdppc  i.type  if  ppp==2021 & povline==300
```
Read candidates: `variable:f7883e1c6eb6b4bb`, `variable:21835225188c4010`, `variable:c505ca5d828c9acf`, `variable:c861e1ec3a636212`, `variable:9c10115065b0f5fc`, `variable:0d96c6f5038f134f`

### block:d88ea2f21bb2378e

Evidence: `01.Programs/archive/01c-GMI extended spells pov elasticity.do:L179-L179`. Next: `end`.

```stata
s
```
