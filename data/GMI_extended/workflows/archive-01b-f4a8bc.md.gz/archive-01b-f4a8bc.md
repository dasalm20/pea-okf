# 01.Programs/archive/01b-GMI extended indicators spells.do

GIC welfare bins and spell decompositions

Status: PARTIAL_STATIC. Every lexically active statement is indexed; complete runtime schema and macro expansion are not established.

Source snapshot: numbered source (deployment lookup: lookup/sources/GMI_extended/source_maps/archive-01b-f4a8bc.md.md)

## Execution-order blocks

### block:c9106713b2148bbe

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L51-L51`. Next: `block:f971081c56d5f3fc`.

```stata
clear
```

### block:f971081c56d5f3fc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L52-L52`. Next: `block:9f2c1deebcf3c125`.

```stata
set max_memory ., permanently
```

### block:9f2c1deebcf3c125

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L53-L53`. Next: `block:3a5889ad960b58d7`.

```stata
tempfile datagic dataall dataall2 prosdecomp
```

### block:3a5889ad960b58d7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L54-L54`. Next: `block:da2216f4d6adbbde`.

```stata
save `datagic', replace emptyok
```
Write datasets: `dataset:487c529c5153c918`

### block:da2216f4d6adbbde

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L55-L55`. Next: `block:9a420183335e034b`.

```stata
save `prosdecomp', replace emptyok
```
Write datasets: `dataset:a404fd2d1680b9c0`

### block:9a420183335e034b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L56-L56`. Next: `block:7a6e0a7c55b69cf2`.

```stata
save `dataall', replace emptyok
```
Write datasets: `dataset:873b66466c7dc505`

### block:7a6e0a7c55b69cf2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L57-L57`. Next: `block:82e7af9a843bc832`.

```stata
save `dataall2', replace emptyok
```
Write datasets: `dataset:9dd587dd11bfb0e2`

### block:82e7af9a843bc832

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L59-L59`. Next: `block:4bb4f904afdd79f2`.

```stata
set varabbrev off
```

### block:4bb4f904afdd79f2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L61-L61`. Next: `block:917ba745fdac1216`.

```stata
global rnd SM26
```

### block:917ba745fdac1216

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L62-L62`. Next: `block:d2d77ebe0f8a8a90`.

```stata
global path \\wbgfscifs01\GTSD\03.projects_corp\04.GPWG\04.GPWG_${rnd}\04.GPWG_${rnd}_QA
```

### block:d2d77ebe0f8a8a90

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L63-L63`. Next: `block:7211007b474bfa14`.

```stata
global reposource "${path}\01.programs\02.dofile\repo\"
```

### block:7211007b474bfa14

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L64-L64`. Next: `block:1cde2b6fc78993ca`.

```stata
global out D:\daylan\test\GMI\out
```

### block:1cde2b6fc78993ca

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L68-L68`. Next: `block:db511b81170f9348`.

```stata
global qclog "${out}\\03.intermediate\\GIC_QC_flagged_${rnd}.log"
```

### block:db511b81170f9348

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L69-L69`. Next: `block:1e518cdffd550a5c`.

```stata
global qccsv "${out}\\03.intermediate\\GIC_QC_flagged_${rnd}.csv"
```

### block:1e518cdffd550a5c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L71-L71`. Next: `block:68760d768e059461`.

```stata
global ppplist 2017 2021
```

### block:68760d768e059461

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L72-L72`. Next: `block:d4ddfbf5967e735b`.

```stata
global pppmax 2021
```

### block:d4ddfbf5967e735b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L74-L74`. Next: `block:74bc4d81a438d997`.

```stata
global floor2021 0.28
```

### block:74bc4d81a438d997

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L75-L75`. Next: `block:71710753af2a113e`.

```stata
global gap2021 28
```

### block:71710753af2a113e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L76-L76`. Next: `block:d80855124418f2d6`.

```stata
global floor2017 0.25
```

### block:d80855124418f2d6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L77-L77`. Next: `block:b07c177b60a9a3da`.

```stata
global gap2017 25
```

### block:b07c177b60a9a3da

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L78-L78`. Next: `block:dd53652a698b04e0`.

```stata
global floor2011 0.22
```

### block:dd53652a698b04e0

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L79-L79`. Next: `block:29c44fe3efb7990b`.

```stata
global gap2011 22
```

### block:29c44fe3efb7990b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L81-L81`. Next: `block:ad7d82fb1818a675`.

```stata
global plines2021 300 420 830 450 630 1245 600 840 1660
```

### block:ad7d82fb1818a675

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L82-L82`. Next: `block:b4cd7ec2993557eb`.

```stata
global plines2017 215 365 685 322 547 1027 430 730 1370
```

### block:b4cd7ec2993557eb

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L83-L83`. Next: `block:e80310a43907dc9e`.

```stata
global plines2011 190 320 550
```

### block:e80310a43907dc9e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L84-L84`. Next: `block:5aa67c0e33ca948d`.

```stata
global cpiversion Support_2005_CPI_V14_M
```

### block:5aa67c0e33ca948d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L86-L86`. Next: `block:51e2fc170dd61958`.

```stata
global pwf "D:\daylan\test\GMI\Survey_price_framework.dta"
```

### block:51e2fc170dd61958

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L87-L87`. Next: `block:7b130f0419e5c19d`.

```stata
global repotxt repo(use ${rnd}all) reporoot(${reposource})
```

### block:7b130f0419e5c19d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L89-L89`. Next: `block:532bb0bd8f28bf12`.

```stata
tempfile data1
```

### block:532bb0bd8f28bf12

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L90-L90`. Next: `block:5d697b52f4c50057`.

```stata
use \\wbgfscifs01\GTSD\03.projects_corp\04.GPWG\04.GPWG_${rnd}\04.GPWG_${rnd}_QA\01.programs\02.dofile\repo\repo_${rnd}all.dta , clear
```
Read datasets: `dataset:96215c3f23c334b3`

### block:5d697b52f4c50057

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L91-L91`. Next: `block:066ce022f9ed3a9f`.

```stata
gen year = years
```
New: `variable:9e7f3d4d6e5fc7a2`
Read candidates: `variable:ae691ee3349d6bc5`

### block:066ce022f9ed3a9f

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L92-L92`. Next: `block:d5efa87046ad3d72`.

```stata
destring year, replace
```
Modified: `variable:9e7f3d4d6e5fc7a2`
Read candidates: `variable:9e7f3d4d6e5fc7a2`

### block:d5efa87046ad3d72

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L93-L93`. Next: `block:361a065fd63c2d25`.

```stata
ren country countrycode
```
New: `variable:bb24a6c6ea33d8ab`
Read candidates: `variable:9edb301986b59c2e`

### block:361a065fd63c2d25

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L94-L94`. Next: `block:8c15ca99f7de1cca`.

```stata
keep if module=="ALL"
```
Read candidates: `variable:36f768cb08f99b6e`

### block:8c15ca99f7de1cca

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L95-L95`. Next: `block:05ab69cbfbb03b11`.

```stata
save `data1', replace
```
Write datasets: `dataset:a91f917022016300`

### block:05ab69cbfbb03b11

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L97-L97`. Next: `block:bbcc8ae30a6de8e3`.

```stata
use "\\wbgfscifs01\GTSD\03.projects_corp\06.GMI\06.GMI_${rnd}\06.GMI_${rnd}_QA\03.output\01.data\GMI_SPspell_all.dta", clear
```
Read datasets: `dataset:4f0ea2547d8ecc02`

### block:bbcc8ae30a6de8e3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L99-L99`. Next: `block:a5142aac09260e3f`.

```stata
drop if datamod=="bin"
```
Read candidates: `variable:e74d0246308868b0`

### block:a5142aac09260e3f

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L100-L100`. Next: `block:54cd7369185aa200`.

```stata
drop if countrycode=="ISO3"|countrycode=="ISO3"|countrycode=="ISO3"|countrycode=="ISO3"
```
Read candidates: `variable:d4b267301faefeac`

### block:54cd7369185aa200

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L101-L101`. Next: `block:1d5eb7de3f4b26e5`.

```stata
ren surveyname survname
```
New: `variable:585387e1d65856f2`
Read candidates: `variable:e057bad485e1dd16`

### block:1d5eb7de3f4b26e5

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L102-L102`. Next: `block:b56896e358c813c3`.

```stata
merge m:m countrycode year survname using `data1', keepus(module)
```
Read datasets: `dataset:a91f917022016300`

### block:b56896e358c813c3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L103-L103`. Next: `block:26dda5bebba891d4`.

```stata
drop if _merge==2
```
Read candidates: `variable:d291e21e66626364`

### block:26dda5bebba891d4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L105-L105`. Next: `block:dc99724d5b95095b`.

```stata
bys countrycode period welftype (year): gen seq = _N
```
New: `variable:695c338a9a6c3892`
Read candidates: `variable:d4b267301faefeac`, `variable:8583c46878df3e25`, `variable:d1e06a57f103bd04`

### block:dc99724d5b95095b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L106-L106`. Next: `block:88ae2d444ca0ca35`.

```stata
bys countrycode period welftype (year): gen seq1 = _n
```
New: `variable:03458ef91e431c14`
Read candidates: `variable:d4b267301faefeac`, `variable:8583c46878df3e25`, `variable:d1e06a57f103bd04`

### block:88ae2d444ca0ca35

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L107-L107`. Next: `block:21e664e1f732e380`.

```stata
drop if seq==1
```
Read candidates: `variable:695c338a9a6c3892`

### block:21e664e1f732e380

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L108-L108`. Next: `block:629a070fd6b42282`.

```stata
drop seq _merge ref rep region welvar datamod filename
```
Read candidates: `variable:695c338a9a6c3892`, `variable:d291e21e66626364`, `variable:e968e7e0a28edda3`, `variable:79dd33dfe8527929`, `variable:4b7d735998d98c33`, `variable:ad6f445dace54279`, `variable:e74d0246308868b0`, `variable:cf2856955d34a0ec`

### block:629a070fd6b42282

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L109-L109`. Next: `block:8b0109e32a3ccf18`.

```stata
replace module="MIS" if module==""
```
Modified: `variable:6b56bc8e5304e354`
Read candidates: `variable:6b56bc8e5304e354`

### block:8b0109e32a3ccf18

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L111-L111`. Next: `block:09a90bdf160d2e7c`.

```stata
reshape wide year survname module, i(countrycode period welftype) j(seq1)
```
Read candidates: `variable:ed4d620977ce8e86`, `variable:d1e06a57f103bd04`, `variable:585387e1d65856f2`, `variable:6b56bc8e5304e354`, `variable:d4b267301faefeac`, `variable:8583c46878df3e25`, `variable:6b7ff0e8f48f6e81`, `variable:03458ef91e431c14`

### block:09a90bdf160d2e7c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L112-L112`. Next: `block:3f98c74196a46e17`.

```stata
gen type = 0
```
New: `variable:7d2f3e58ff0b2946`

### block:3f98c74196a46e17

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L113-L113`. Next: `block:f7b993ba29f775a3`.

```stata
replace type = 1 if module1=="ALL" & module2=="ALL"
```
Modified: `variable:7d2f3e58ff0b2946`
Read candidates: `variable:a4717b1309488446`, `variable:4d254a49a3d94364`

### block:f7b993ba29f775a3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L114-L114`. Next: `block:f6a0b487925d943e`.

```stata
drop if countrycode=="ISO3" & year1==0000
```
Read candidates: `variable:d4b267301faefeac`, `variable:af072b9645b2bdca`

### block:f6a0b487925d943e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L116-L116`. Next: `block:218fb0fede767522`.

```stata
drop if countrycode=="ISO3" & (year1==0000 & survname1=="EPH") | (year2==0000 & survname2=="EPH")
```
Read candidates: `variable:d4b267301faefeac`, `variable:af072b9645b2bdca`, `variable:cc47a9ed001159d6`, `variable:b33cb8248916211d`, `variable:07586007b8f960f9`

### block:218fb0fede767522

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L117-L117`. Next: `block:3cca2d86ec755eb5`.

```stata
local nobs = _N
```

### block:3cca2d86ec755eb5

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L119-L119`. Next: `block:b54239e8dc4c8c8e`.

```stata
replace welftype = "INC" if countrycode=="ISO3" & period=="0000-0000" & welftype=="CONS"
```
Modified: `variable:6b7ff0e8f48f6e81`
Read candidates: `variable:d4b267301faefeac`, `variable:8583c46878df3e25`, `variable:6b7ff0e8f48f6e81`

### block:b54239e8dc4c8c8e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L159-L159`. Next: `block:f543f74c9eccc939`.

```stata
save `data1', replace
```
Write datasets: `dataset:a91f917022016300`

### block:f543f74c9eccc939

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L161-L161`. Next: `block:376b442cbc9d1d3e`.

```stata
cap frame create temp_frame
```

### block:376b442cbc9d1d3e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L162-L162`. Next: `block:4462927ca70f53c9`.

```stata
cap frame change temp_frame
```

### block:4462927ca70f53c9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L163-L163`. Next: `block:9c3d9576012e61c0`.

```stata
cap frame drop decomp_results
```

### block:9c3d9576012e61c0

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L164-L164`. Next: `block:34c8a6ebfc724fe8`.

```stata
cap frame drop decomp_results2
```

### block:34c8a6ebfc724fe8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L165-L165`. Next: `block:604692539d076093`.

```stata
frame create decomp_results strL(code welftype decomp spell povline) float(value1 value2 value3 value4 ppp)
```

### block:604692539d076093

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L166-L166`. Next: `block:6b990b74677df7d3`.

```stata
frame create decomp_results2 strL(code welftype decomp spell povline) float(value1 value2 value3 value4 value5 ppp)
```

### block:6b990b74677df7d3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L171-L171`. Next: `block:9406cf844eb48275`.

```stata
tempfile qccollect
```

### block:9406cf844eb48275

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L172-L172`. Next: `block:03d46eccfc5613fd`.

```stata
capture postclose qcdrops
```

### block:03d46eccfc5613fd

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L173-L175`. Next: `block:6d233b6cd194098d`.

```stata
postfile qcdrops str3 qc_code str20 qc_spell str4 qc_welf int qc_ppp str12 qc_block long qc_ndropped long qc_ntotal double qc_pctdropped using `qccollect', replace
```
Write datasets: `dataset:3f8e83d7cb5e6088`

### block:6d233b6cd194098d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L201-L201`. Next: `block:45f2cdb0dcd287a8`.

```stata
local nobs = _N
```

### block:45f2cdb0dcd287a8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L202-L202`. Next: `block:eeb1ad78ec14eea2`.

```stata
save 	`data1', replace
```
Write datasets: `dataset:a91f917022016300`

### block:eeb1ad78ec14eea2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L206-L206`. Next: `block:d7ef46c95df6cc07`.

```stata
forv i=1(1)`nobs' {
```

### block:d7ef46c95df6cc07

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L208-L208`. Next: `block:a5e0d29735a6d42c`.

```stata
tempfile data1a data1b
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:a5e0d29735a6d42c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L209-L209`. Next: `block:5bcb3fcf33dc2879`.

```stata
use `data1', clear
```
Enclosing controls: `forv i=1(1)`nobs' {`
Read datasets: `dataset:a91f917022016300`

### block:5bcb3fcf33dc2879

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L211-L211`. Next: `block:c7af4400674b2dd9`.

```stata
local welftype = welftype[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:c7af4400674b2dd9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L212-L212`. Next: `block:c65960e8f224db88`.

```stata
local code = countrycode[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:c65960e8f224db88

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L213-L213`. Next: `block:a2dda4cc45b09772`.

```stata
local year1 = year1[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:a2dda4cc45b09772

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L214-L214`. Next: `block:cbe7e6e2faeed5e8`.

```stata
local survname1 = survname1[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:cbe7e6e2faeed5e8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L216-L216`. Next: `block:6911cde57eb6dee1`.

```stata
local year2 = year2[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:6911cde57eb6dee1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L217-L217`. Next: `block:458ee6759f778c8e`.

```stata
local survname2 = survname2[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:458ee6759f778c8e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L219-L219`. Next: `block:7c2182c0e60ad994`.

```stata
local spellx = period[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:7c2182c0e60ad994

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L220-L220`. Next: `block:ae8d92254b7848e1`.

```stata
local type = type[`i']
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:ae8d92254b7848e1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L225-L225`. Next: `block:244d79bf25e7eb96`.

```stata
noi dis "`i'-`code'-`year1'-`survname1'-`year2'-`survname2'-`spellx'"
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:244d79bf25e7eb96

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L227-L227`. Next: `block:8916e58b06c54cbd`.

```stata
local mod GPWG
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:8916e58b06c54cbd

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L228-L228`. Next: `block:e236360bb0652ae1`.

```stata
local wgt weight
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:e236360bb0652ae1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L229-L229`. Next: `block:7f1f8c04a2bf5626`.

```stata
local x1 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:7f1f8c04a2bf5626

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L230-L230`. Next: `block:c96e22de60db50ea`.

```stata
local x2 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:c96e22de60db50ea

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L232-L232`. Next: `block:96e46cb9f6391345`.

```stata
cap dlw, country(`code') year(`year1') type(gmd) surveyid(`survname1') mod(`mod') files $repotxt
```
Enclosing controls: `forv i=1(1)`nobs' {`
Read datasets: `dataset:51712dd5b8516c04`

### block:96e46cb9f6391345

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L233-L233`. Next: `block:707e9bb72613f84c`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:707e9bb72613f84c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L234-L234`. Next: `block:c8e10d6f4d70742e`.

```stata
cap drop survname
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Read candidates: `variable:2c6c694575d099b0`

### block:c8e10d6f4d70742e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L235-L235`. Next: `block:0dccff145f935007`.

```stata
gen survname = "`survname1'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
New: `variable:2c6c694575d099b0`

### block:0dccff145f935007

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L236-L236`. Next: `block:10f7d03a74528f04`.

```stata
egen HHID_new = group(hhid)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
New: `variable:a5ca684d5b8cbce6`
Read candidates: `variable:2a4351fbd98f75cd`

### block:10f7d03a74528f04

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L237-L237`. Next: `block:8f501b83aa10afea`.

```stata
local x1=1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:8f501b83aa10afea

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L238-L238`. Next: `block:443975057227ec0d`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:443975057227ec0d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L239-L239`. Next: `block:627eb665d76c35e5`.

```stata
gen double __a`ppp1' = welfare/cpi`ppp1'/icp`ppp1'/365
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:d3b2488ae164082b`
Read candidates: `variable:fae60b96b14c2ef0`, `variable:c05fbd7f4c9364da`, `variable:3277a8951a491a3e`

### block:627eb665d76c35e5

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L240-L240`. Next: `block:1233d93818e6cc04`.

```stata
replace __a`ppp1' = ${floor`ppp1'} if __a`ppp1' < ${floor`ppp1'}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
Modified: `variable:d3b2488ae164082b`
Read candidates: `variable:bf9cc6e9af343886`, `variable:d3b2488ae164082b`

### block:1233d93818e6cc04

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L241-L241`. Next: `block:62595b9db506868c`.

```stata
su __a`ppp1' [aw=weight]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
Read candidates: `variable:d3b2488ae164082b`, `variable:b01bf8037c645555`

### block:62595b9db506868c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L242-L242`. Next: `block:f0b96f83442ba320`.

```stata
local m1 = r(mean)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`

### block:f0b96f83442ba320

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L243-L243`. Next: `block:17c08a9856f39f77`.

```stata
gen inq_y_ybar`ppp1' = `m1'/__a`ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:a0c54a950ae30ac2`
Read candidates: `variable:d3b2488ae164082b`

### block:17c08a9856f39f77

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L244-L244`. Next: `block:1775e1934daf5b9e`.

```stata
gen prosg`ppp1' = ${gap`ppp1'}/__a`ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:63f0157cad56e994`
Read candidates: `variable:0365a06263408c06`, `variable:d3b2488ae164082b`

### block:1775e1934daf5b9e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L245-L245`. Next: `block:5d76463372ceb18e`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:5d76463372ceb18e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L246-L246`. Next: `block:c8eb0abb23460979`.

```stata
cap des urban
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:c8eb0abb23460979

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L247-L247`. Next: `block:ce287265ec7eccd6`.

```stata
if _rc==0 keep code year HHID_new  __a* weight urban prosg* inq_y_ybar* survname
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Read candidates: `variable:1f97a455a33dca54`, `variable:c0004e7f5501b5a5`, `variable:a5ca684d5b8cbce6`, `variable:1fc2cee9d1281ff1`, `variable:b01bf8037c645555`, `variable:46e52eccc7b49c86`, `variable:083801cbd09c93f7`, `variable:ac5aff3d02724885`, `variable:2c6c694575d099b0`

### block:ce287265ec7eccd6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L248-L248`. Next: `block:fa4d63148577b9e4`.

```stata
else keep code year HHID_new  __a* weight prosg* inq_y_ybar* survname
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Read candidates: `variable:1f97a455a33dca54`, `variable:c0004e7f5501b5a5`, `variable:a5ca684d5b8cbce6`, `variable:1fc2cee9d1281ff1`, `variable:b01bf8037c645555`, `variable:083801cbd09c93f7`, `variable:ac5aff3d02724885`, `variable:2c6c694575d099b0`

### block:fa4d63148577b9e4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L249-L249`. Next: `block:0ac204d299d7c768`.

```stata
save `data1a', replace
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Write datasets: `dataset:903da197524cd35e`

### block:0ac204d299d7c768

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L250-L250`. Next: `block:e3d28f348c41efad`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:e3d28f348c41efad

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L252-L252`. Next: `block:3ca69d56c3ef6e39`.

```stata
cap dlw, country(`code') year(`year2') type(gmd) surveyid(`survname2') mod(`mod') files $repotxt
```
Enclosing controls: `forv i=1(1)`nobs' {`
Read datasets: `dataset:d38a902c7d194a08`

### block:3ca69d56c3ef6e39

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L253-L253`. Next: `block:8611e6393fa44bc4`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:8611e6393fa44bc4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L254-L254`. Next: `block:f23daf2b268e049c`.

```stata
cap drop survname
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Read candidates: `variable:9cc96b7fdc7bd140`

### block:f23daf2b268e049c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L255-L255`. Next: `block:7c967471cc3e73b8`.

```stata
gen survname = "`survname2'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
New: `variable:9cc96b7fdc7bd140`

### block:7c967471cc3e73b8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L256-L256`. Next: `block:b355d49fedd8b89d`.

```stata
egen HHID_new = group(hhid)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
New: `variable:f30a2e898ae727c5`
Read candidates: `variable:9a96619406bcf620`

### block:b355d49fedd8b89d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L257-L257`. Next: `block:0d3d5b28ba90805e`.

```stata
local x2=1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:0d3d5b28ba90805e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L258-L258`. Next: `block:cd6b52120e87987c`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:cd6b52120e87987c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L259-L259`. Next: `block:6da06752c371498e`.

```stata
gen double __a`ppp1' = welfare/cpi`ppp1'/icp`ppp1'/365
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:e768736a0d511a82`
Read candidates: `variable:ec8c4e82bc86782f`, `variable:0a83400d4aeb2990`, `variable:cae77686e0b57fc5`

### block:6da06752c371498e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L260-L260`. Next: `block:0a2d2b27ba358663`.

```stata
replace __a`ppp1' = ${floor`ppp1'} if __a`ppp1' < ${floor`ppp1'}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
Modified: `variable:e768736a0d511a82`
Read candidates: `variable:ac488a714a74bd21`, `variable:e768736a0d511a82`

### block:0a2d2b27ba358663

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L261-L261`. Next: `block:b31ce606bd28bf46`.

```stata
su __a`ppp1' [aw=weight]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
Read candidates: `variable:e768736a0d511a82`, `variable:0004f3eedd093db9`

### block:b31ce606bd28bf46

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L262-L262`. Next: `block:d833ef872da23a58`.

```stata
local m1 = r(mean)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`

### block:d833ef872da23a58

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L263-L263`. Next: `block:0a84522c5acb6e1c`.

```stata
gen inq_y_ybar`ppp1' = `m1'/__a`ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:4e692db9c2640156`
Read candidates: `variable:e768736a0d511a82`

### block:0a84522c5acb6e1c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L264-L264`. Next: `block:fbdc38ebfa36c841`.

```stata
gen prosg`ppp1' = ${gap`ppp1'}/__a`ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:f2721261c2ee6509`
Read candidates: `variable:437b9c5f461ad17b`, `variable:e768736a0d511a82`

### block:fbdc38ebfa36c841

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L265-L265`. Next: `block:922b199478109d3e`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:922b199478109d3e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L266-L266`. Next: `block:99cf4f0cfbc623e8`.

```stata
cap des urban
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`

### block:99cf4f0cfbc623e8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L267-L267`. Next: `block:3c66f9e6cb2522f0`.

```stata
if _rc==0 keep code year HHID_new  __a* weight urban prosg* inq_y_ybar* survname
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Read candidates: `variable:09623bea7685fad6`, `variable:a25d7b83e1c88da9`, `variable:f30a2e898ae727c5`, `variable:35ac94e6165888fe`, `variable:0004f3eedd093db9`, `variable:9fcc38077d524e7c`, `variable:38a463d609d80694`, `variable:0e64baf15897e3f2`, `variable:9cc96b7fdc7bd140`

### block:3c66f9e6cb2522f0

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L268-L268`. Next: `block:82b645f5bd676e93`.

```stata
else keep code year HHID_new  __a* weight prosg* inq_y_ybar* survname
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Read candidates: `variable:09623bea7685fad6`, `variable:a25d7b83e1c88da9`, `variable:f30a2e898ae727c5`, `variable:35ac94e6165888fe`, `variable:0004f3eedd093db9`, `variable:38a463d609d80694`, `variable:0e64baf15897e3f2`, `variable:9cc96b7fdc7bd140`

### block:82b645f5bd676e93

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L269-L269`. Next: `block:0776d95cd0c6b364`.

```stata
append using `data1a'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Read datasets: `dataset:903da197524cd35e`

### block:0776d95cd0c6b364

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L270-L270`. Next: `block:27736d322dabe54c`.

```stata
save `data1a', replace
```
Enclosing controls: `forv i=1(1)`nobs' {` → `qui if _rc==0 {`
Write datasets: `dataset:903da197524cd35e`

### block:27736d322dabe54c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L271-L271`. Next: `block:3ebba6eeee9412be`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:3ebba6eeee9412be

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L273-L273`. Next: `block:8160470c8d1af21d`.

```stata
if `x1'==1 & `x2'==1 {
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:8160470c8d1af21d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L274-L274`. Next: `block:41c02ad885a42a9e`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {`

### block:41c02ad885a42a9e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L276-L276`. Next: `block:db5ec32b311a018e`.

```stata
use `data1a', clear
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read datasets: `dataset:903da197524cd35e`

### block:db5ec32b311a018e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L283-L283`. Next: `block:240ef85719681054`.

```stata
qui count
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:240ef85719681054

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L284-L284`. Next: `block:4126c8bce033e632`.

```stata
local qc_tot = r(N)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:4126c8bce033e632

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L285-L285`. Next: `block:c080ae739f533101`.

```stata
qui count if missing(__a`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read candidates: `variable:3ac61b0f88e315b6`

### block:c080ae739f533101

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L286-L286`. Next: `block:e4e418e72751511e`.

```stata
local qc_drop = r(N)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:e4e418e72751511e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L287-L287`. Next: `block:6d4be6ac72d427bb`.

```stata
if `qc_drop' > 0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:6d4be6ac72d427bb

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L288-L288`. Next: `block:abec7a4965002a21`.

```stata
local qc_pct = 100*`qc_drop'/`qc_tot'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if `qc_drop' > 0 {`

### block:abec7a4965002a21

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L289-L289`. Next: `block:4480de3bfd4ea121`.

```stata
noi dis in yellow "  FLAG GIC-nat: `code' `spellx' ppp`ppp1' - dropped `qc_drop' of `qc_tot' missing welfare"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if `qc_drop' > 0 {`

### block:4480de3bfd4ea121

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L290-L291`. Next: `block:745de3804c43bc86`.

```stata
post qcdrops ("`code'") ("`spellx'") ("`welftype'") (`ppp1') ("national") (`qc_drop') (`qc_tot') (`qc_pct')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if `qc_drop' > 0 {`

### block:745de3804c43bc86

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L292-L292`. Next: `block:9405c9dd90e758ad`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:9405c9dd90e758ad

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L293-L293`. Next: `block:63c18ef1d2308e42`.

```stata
drop if missing(__a`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read candidates: `variable:3ac61b0f88e315b6`

### block:63c18ef1d2308e42

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L295-L295`. Next: `block:fb2c835c5c3d49a2`.

```stata
clonevar q100 = __a`ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
New: `variable:e32c288964617bfe`
Read candidates: `variable:3ac61b0f88e315b6`

### block:fb2c835c5c3d49a2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L296-L296`. Next: `block:e98dc086756eedd4`.

```stata
groupfunction [aw=`wgt'], mean(__a`ppp1') xtile(q100) nq(100) by(year )
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read candidates: `variable:3ac61b0f88e315b6`, `variable:e32c288964617bfe`, `variable:4b053cb314f0664f`

### block:e98dc086756eedd4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L297-L297`. Next: `block:613f0042307abc4c`.

```stata
ren __a`ppp1' mean
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
New: `variable:4a0e3b40b25c2344`
Read candidates: `variable:3ac61b0f88e315b6`

### block:613f0042307abc4c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L298-L298`. Next: `block:ef46b7ad1d3c5381`.

```stata
gen ppp = `ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
New: `variable:118b24301278f657`

### block:ef46b7ad1d3c5381

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L299-L299`. Next: `block:7778a7f2c11c0297`.

```stata
gen data = "All sample"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
New: `variable:6489d420cb1f2f6f`

### block:7778a7f2c11c0297

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L300-L300`. Next: `block:c368a74132465606`.

```stata
gen data_group = 1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
New: `variable:99dfb3393c6265bd`

### block:c368a74132465606

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L301-L301`. Next: `block:df7e8753d96200d8`.

```stata
gen welftype = "`welftype'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
New: `variable:90cf7306c184d176`

### block:df7e8753d96200d8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L302-L302`. Next: `block:86bc41c827e65022`.

```stata
gen code = "`code'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
New: `variable:6c18f771d4740e52`

### block:86bc41c827e65022

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L303-L303`. Next: `block:06051a1ab58c961d`.

```stata
append using `datagic'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read datasets: `dataset:487c529c5153c918`

### block:06051a1ab58c961d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L304-L304`. Next: `block:d7f6121ccaf64906`.

```stata
save `datagic', replace
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Write datasets: `dataset:487c529c5153c918`

### block:d7f6121ccaf64906

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L307-L307`. Next: `block:f5f69c6420cb191c`.

```stata
use `data1a', clear
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read datasets: `dataset:903da197524cd35e`

### block:f5f69c6420cb191c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L308-L308`. Next: `block:79a0f070d1167ae1`.

```stata
cap des urban
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:79a0f070d1167ae1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L309-L309`. Next: `block:4a9c0986ce67bf7f`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:4a9c0986ce67bf7f

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L314-L314`. Next: `block:32ad6d6f9a721474`.

```stata
qui count
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`

### block:32ad6d6f9a721474

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L315-L315`. Next: `block:d1e942f7a9ca131b`.

```stata
local qc_tot = r(N)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`

### block:d1e942f7a9ca131b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L316-L316`. Next: `block:6734fba82ec599fc`.

```stata
qui count if missing(__a`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
Read candidates: `variable:cc418b1355f44714`

### block:6734fba82ec599fc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L317-L317`. Next: `block:2ad693709eebc110`.

```stata
local qc_drop = r(N)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`

### block:2ad693709eebc110

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L318-L318`. Next: `block:d56e2f8685a4cd83`.

```stata
if `qc_drop' > 0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`

### block:d56e2f8685a4cd83

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L319-L319`. Next: `block:e9818bbf55ab081a`.

```stata
local qc_pct = 100*`qc_drop'/`qc_tot'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {` → `if `qc_drop' > 0 {`

### block:e9818bbf55ab081a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L320-L320`. Next: `block:d7a0182384147710`.

```stata
noi dis in yellow "  FLAG GIC-u/r: `code' `spellx' ppp`ppp1' - dropped `qc_drop' of `qc_tot' missing welfare"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {` → `if `qc_drop' > 0 {`

### block:d7a0182384147710

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L321-L322`. Next: `block:003666e2bad17288`.

```stata
post qcdrops ("`code'") ("`spellx'") ("`welftype'") (`ppp1') ("urban_rural") (`qc_drop') (`qc_tot') (`qc_pct')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {` → `if `qc_drop' > 0 {`

### block:003666e2bad17288

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L323-L323`. Next: `block:61d97c0b28b6c9a3`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`

### block:61d97c0b28b6c9a3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L324-L324`. Next: `block:7b54c60fe826e73a`.

```stata
drop if missing(__a`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
Read candidates: `variable:cc418b1355f44714`

### block:7b54c60fe826e73a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L326-L326`. Next: `block:356fe45e64ca5d05`.

```stata
clonevar q100 = __a`ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
New: `variable:2baaf2ef5c560ed4`
Read candidates: `variable:cc418b1355f44714`

### block:356fe45e64ca5d05

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L327-L327`. Next: `block:486a786df6ee030e`.

```stata
groupfunction [aw=`wgt'], mean(__a`ppp1') xtile(q100) nq(100) by(year  urban)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
Read candidates: `variable:cc418b1355f44714`, `variable:2baaf2ef5c560ed4`, `variable:fba46c85a4a8c3fa`, `variable:678f11bd640b375b`

### block:486a786df6ee030e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L328-L328`. Next: `block:3e3a68b77a94d96a`.

```stata
ren __a`ppp1' mean
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
New: `variable:dfd11a7be00c03e0`
Read candidates: `variable:cc418b1355f44714`

### block:3e3a68b77a94d96a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L329-L329`. Next: `block:4b51cb035af6d686`.

```stata
gen ppp = `ppp1'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
New: `variable:f22e2282a158a8f2`

### block:4b51cb035af6d686

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L330-L330`. Next: `block:b96b9e68bd2d4825`.

```stata
gen data = "Urban or rural"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
New: `variable:30665661eec856ee`

### block:b96b9e68bd2d4825

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L331-L331`. Next: `block:3dc264be2cd5fe87`.

```stata
ren urban data_group
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
New: `variable:6d3a28b20066bc1e`
Read candidates: `variable:678f11bd640b375b`

### block:3dc264be2cd5fe87

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L332-L332`. Next: `block:d5befb4f24502bd3`.

```stata
gen welftype = "`welftype'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
New: `variable:0baf1407eacda42b`

### block:d5befb4f24502bd3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L333-L333`. Next: `block:4227dc8fe42db4cc`.

```stata
gen code = "`code'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
New: `variable:683cb6e70f2bc454`

### block:4227dc8fe42db4cc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L334-L334`. Next: `block:541ec059be7ca552`.

```stata
append using `datagic'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
Read datasets: `dataset:487c529c5153c918`

### block:541ec059be7ca552

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L335-L335`. Next: `block:82d034683f0eac2b`.

```stata
save `datagic', replace
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `if _rc==0 {`
Write datasets: `dataset:487c529c5153c918`

### block:82d034683f0eac2b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L336-L336`. Next: `block:fb7ef447a90b79f1`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:fb7ef447a90b79f1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L341-L341`. Next: `block:2186b2b4f995014c`.

```stata
use `data1a', clear
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read datasets: `dataset:903da197524cd35e`

### block:2186b2b4f995014c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L342-L342`. Next: `block:de41e7d6d76191f1`.

```stata
qui {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:de41e7d6d76191f1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L343-L343`. Next: `block:9336ce6e4be0eaa1`.

```stata
groupfunction [aw=`wgt'], mean(__a* prosg* inq_y_ybar*) by(year )
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
Read candidates: `variable:4d6509a8e36a92a4`, `variable:8a9f19a3ceb2db80`, `variable:3eeb75d63c4e91a5`, `variable:f32de8e193ce3256`

### block:9336ce6e4be0eaa1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L344-L344`. Next: `block:71d409075dba1203`.

```stata
gen spell = "`spellx'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
New: `variable:db38c44902eaa215`

### block:71d409075dba1203

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L345-L345`. Next: `block:a9403f5cf32cb78a`.

```stata
reshape long __a prosg inq_y_ybar, i(spell year) j(ppp)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
Read candidates: `variable:4d6509a8e36a92a4`, `variable:8a9f19a3ceb2db80`, `variable:3eeb75d63c4e91a5`, `variable:db38c44902eaa215`, `variable:f32de8e193ce3256`, `variable:b75e4fc6d5a09079`

### block:a9403f5cf32cb78a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L346-L346`. Next: `block:43d9c9ccc06f560e`.

```stata
ren __a mean
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
New: `variable:d45125d7c2f6fa19`
Read candidates: `variable:4d6509a8e36a92a4`

### block:43d9c9ccc06f560e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L347-L347`. Next: `block:cd1285aa19fdbbc7`.

```stata
foreach var of varlist prosg inq_y_ybar mean {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`

### block:cd1285aa19fdbbc7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L348-L348`. Next: `block:527388bba8c617b3`.

```stata
gen ln`var' = ln(`var')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {` → `foreach var of varlist prosg inq_y_ybar mean {`
New: `variable:91244b39aa0669e0`

### block:527388bba8c617b3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L350-L350`. Next: `block:1409726d66f96175`.

```stata
bys ppp spell (year): gen ch_ln`var' = (ln`var'[_n]- ln`var'[_n-1])/(year[_n]-year[_n-1])
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {` → `foreach var of varlist prosg inq_y_ybar mean {`
New: `variable:85306a7f27ae6b29`
Read candidates: `variable:91244b39aa0669e0`, `variable:f32de8e193ce3256`, `variable:b75e4fc6d5a09079`

### block:1409726d66f96175

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L351-L351`. Next: `block:35bfcb25fbe4cf7f`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`

### block:35bfcb25fbe4cf7f

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L352-L352`. Next: `block:a3695d4224854758`.

```stata
gen code = "`code'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
New: `variable:e7c176df6ea46831`

### block:a3695d4224854758

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L353-L353`. Next: `block:1334512accf28ff1`.

```stata
gen welftype = "`welftype'"
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
New: `variable:3c0482d59a5ca69a`

### block:1334512accf28ff1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L354-L354`. Next: `block:f7896527ca3bb221`.

```stata
replace ch_lninq_y_ybar = ch_lninq_y_ybar *100
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
Modified: `variable:f11d70e4eb890f0f`
Read candidates: `variable:f11d70e4eb890f0f`

### block:f7896527ca3bb221

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L355-L355`. Next: `block:7399c30d69579c8e`.

```stata
replace ch_lnmean = -1 * ch_lnmean *100
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
Modified: `variable:4e0390f58092651c`
Read candidates: `variable:4e0390f58092651c`

### block:7399c30d69579c8e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L356-L356`. Next: `block:09c21a7d7ef6725c`.

```stata
replace ch_lnprosg = ch_lnprosg *100
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
Modified: `variable:7c60c06cc6878168`
Read candidates: `variable:7c60c06cc6878168`

### block:09c21a7d7ef6725c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L357-L357`. Next: `block:946628d6247aba1e`.

```stata
append using `prosdecomp'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
Read datasets: `dataset:a404fd2d1680b9c0`

### block:946628d6247aba1e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L358-L358`. Next: `block:b6d5ee261b8d62da`.

```stata
save `prosdecomp', replace
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `qui {`
Write datasets: `dataset:a404fd2d1680b9c0`

### block:b6d5ee261b8d62da

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L359-L359`. Next: `block:6cb55ddbfe3837b1`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:6cb55ddbfe3837b1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L363-L363`. Next: `block:2e43d24e9122376e`.

```stata
use `data1a', clear
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`
Read datasets: `dataset:903da197524cd35e`

### block:2e43d24e9122376e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L364-L364`. Next: `block:83d22282da5be2aa`.

```stata
foreach num of numlist ${plines`ppp1'} {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:83d22282da5be2aa

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L365-L365`. Next: `block:ff4bf7449d46e422`.

```stata
gen _pline`num' = `=`num'/100'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
New: `variable:c8e2ed6525dc165e`

### block:ff4bf7449d46e422

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L369-L369`. Next: `block:a391c2459765a4cc`.

```stata
qui drdecomp __a`ppp1' [aw=`wgt'] if year==`year1'|year==`year2', by(year) varpl(_pline`num')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
Read candidates: `variable:7b46ba7f4a4cd0b1`, `variable:d29543551059cc5b`, `variable:c8e2ed6525dc165e`

### block:a391c2459765a4cc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L370-L370`. Next: `block:37b5015fd3884f84`.

```stata
mat a = r(b)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:37b5015fd3884f84

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L371-L371`. Next: `block:f27a7fcd460b9a77`.

```stata
local value1 = a[1,3]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:f27a7fcd460b9a77

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L372-L372`. Next: `block:0637dbaa09d69299`.

```stata
local value2 = a[2,3]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:0637dbaa09d69299

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L373-L373`. Next: `block:e6ab1451eae98942`.

```stata
local value3 = a[3,3]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:e6ab1451eae98942

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L376-L376`. Next: `block:ebb2112bc406b939`.

```stata
frame decomp_results {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:ebb2112bc406b939

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L377-L377`. Next: `block:c69c84faba4f1d33`.

```stata
frame post decomp_results ("`code'") ("`welftype'") ("Datt-Ravallion") ("`spellx'") ("`num'") (`value3') (`value1') (`value2') (-9999)	(`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {` → `frame decomp_results {`
Write datasets: `dataset:cfbe93e9226a1c7b`

### block:c69c84faba4f1d33

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L378-L378`. Next: `block:b693c4f5d3129ebb`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:b693c4f5d3129ebb

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L382-L382`. Next: `block:ec5b94b244e83eb1`.

```stata
qui skdecomp __a`ppp1' [aw=`wgt'] if year==`year1'|year==`year2', by(year) varpl(_pline`num')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
Read candidates: `variable:7b46ba7f4a4cd0b1`, `variable:d29543551059cc5b`, `variable:c8e2ed6525dc165e`

### block:ec5b94b244e83eb1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L383-L383`. Next: `block:475f7a79a1a10660`.

```stata
mat a = r(b)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:475f7a79a1a10660

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L384-L384`. Next: `block:a6f2df30b7000ae4`.

```stata
local value1 = a[1,3]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:a6f2df30b7000ae4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L385-L385`. Next: `block:f7e29cc38145d31e`.

```stata
local value2 = a[2,3]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:f7e29cc38145d31e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L386-L386`. Next: `block:ded50b77ce00c87d`.

```stata
local value3 = a[3,3]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:ded50b77ce00c87d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L387-L387`. Next: `block:f02296ce49aebb00`.

```stata
local value4 = a[4,3]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:f02296ce49aebb00

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L389-L389`. Next: `block:2cc332bf0defaa50`.

```stata
frame decomp_results {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:2cc332bf0defaa50

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L390-L390`. Next: `block:695990615c60e571`.

```stata
frame post decomp_results ("`code'") ("`welftype'") ("Shorrocks-Kolenikov") ("`spellx'") ("`num'") (`value4') (`value1') (`value2') (`value3') (`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {` → `frame decomp_results {`
Write datasets: `dataset:cfbe93e9226a1c7b`

### block:695990615c60e571

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L391-L391`. Next: `block:2a2bf81198bf9bcd`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:2a2bf81198bf9bcd

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L392-L392`. Next: `block:dd459d5fe36277de`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {` → `foreach ppp1 of global ppplist {`

### block:dd459d5fe36277de

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L393-L393`. Next: `block:9179462c3987a688`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `x1'==1 & `x2'==1 {`

### block:9179462c3987a688

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L394-L394`. Next: `block:d5472011c0e1bd1d`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:d5472011c0e1bd1d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L396-L396`. Next: `block:920587c6f122b68a`.

```stata
if `type'==1 {
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:920587c6f122b68a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L400-L400`. Next: `block:b1f744f70c4e9b7d`.

```stata
local mod ALL
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:b1f744f70c4e9b7d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L401-L401`. Next: `block:eea11fe5b903c949`.

```stata
local wgt weight_p
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:eea11fe5b903c949

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L402-L402`. Next: `block:6bf3a3c39622d3b9`.

```stata
local x1 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:6bf3a3c39622d3b9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L403-L403`. Next: `block:34d3dddb20ce572c`.

```stata
local x2 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:34d3dddb20ce572c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L406-L406`. Next: `block:6cf8f371c85893bc`.

```stata
cap dlw, country(`code') year(`year2') type(gmd) surveyid(`survname2') mod(`mod') files $repotxt
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`
Read datasets: `dataset:d38a902c7d194a08`

### block:6cf8f371c85893bc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L407-L407`. Next: `block:8fbdf0e7a41a62e5`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:8fbdf0e7a41a62e5

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L408-L408`. Next: `block:7a1dd92d2324df41`.

```stata
egen HHID_new = group(hhid)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
New: `variable:8a9c2b35a7484f2c`
Read candidates: `variable:fd83a252ab948524`

### block:7a1dd92d2324df41

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L409-L409`. Next: `block:f6f48d41b41597df`.

```stata
local x2=1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:f6f48d41b41597df

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L410-L410`. Next: `block:7e3eb3b49dee8a4d`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:7e3eb3b49dee8a4d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L411-L411`. Next: `block:d73bbdde0e84da29`.

```stata
gen double __a`ppp1' = welfare/cpi`ppp1'/icp`ppp1'/365
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:7159e348a88b0b27`
Read candidates: `variable:35d55139208d57c2`, `variable:06ef208ef56bbf12`, `variable:a0acf8df26c248a3`

### block:d73bbdde0e84da29

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L412-L412`. Next: `block:848dc03bca1943aa`.

```stata
replace __a`ppp1' = ${floor`ppp1'} if __a`ppp1' < ${floor`ppp1'}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
Modified: `variable:7159e348a88b0b27`
Read candidates: `variable:c9fff5912644fb13`, `variable:7159e348a88b0b27`

### block:848dc03bca1943aa

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L413-L413`. Next: `block:48f1a39307a1908e`.

```stata
foreach num of numlist ${plines`ppp1'} {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`

### block:48f1a39307a1908e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L414-L414`. Next: `block:a68e3ee6b915d851`.

```stata
gen _pline`num' = `=`num'/100'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
New: `variable:c4cdc98d756cde74`

### block:a68e3ee6b915d851

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L415-L415`. Next: `block:5e9e8bd12be2195d`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`

### block:5e9e8bd12be2195d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L416-L416`. Next: `block:b2263027328880b9`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:b2263027328880b9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L418-L418`. Next: `block:8ac3d699a7a4dd5b`.

```stata
local ub2 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:8ac3d699a7a4dd5b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L419-L419`. Next: `block:8182b856565d7820`.

```stata
local ubvar
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:8182b856565d7820

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L420-L420`. Next: `block:fe16d3ccf1b2f3ea`.

```stata
cap des urban
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:fe16d3ccf1b2f3ea

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L421-L421`. Next: `block:0874af768f4c1e1d`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:0874af768f4c1e1d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L422-L422`. Next: `block:acca919b9510fe41`.

```stata
su urban,d
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`
Read candidates: `variable:460f3da5f0f96720`, `variable:097f6106a30d33e7`

### block:acca919b9510fe41

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L423-L423`. Next: `block:3c6949bae3ef4400`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:3c6949bae3ef4400

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L424-L424`. Next: `block:970fc6374197af00`.

```stata
local ub2 = 1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:970fc6374197af00

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L425-L425`. Next: `block:e0c4102403366db0`.

```stata
local ubvar urban
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:e0c4102403366db0

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L426-L426`. Next: `block:3b6dca324a77d1fd`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:3b6dca324a77d1fd

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L427-L427`. Next: `block:7d7c9a495f30c9a2`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:7d7c9a495f30c9a2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L429-L429`. Next: `block:c353d516c6fa9332`.

```stata
local ind2 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:c353d516c6fa9332

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L430-L430`. Next: `block:85d8fae522191ce3`.

```stata
local indvar
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:85d8fae522191ce3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L431-L431`. Next: `block:cbf554bbf7b6c32a`.

```stata
cap des industrycat4
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:cbf554bbf7b6c32a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L432-L432`. Next: `block:0a6b113d24b2aed4`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:0a6b113d24b2aed4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L433-L433`. Next: `block:6a66eb5b9ac9a271`.

```stata
su industrycat4,d
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`
Read candidates: `variable:a7971a01996b134e`, `variable:097f6106a30d33e7`

### block:6a66eb5b9ac9a271

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L434-L434`. Next: `block:429538bcf2404e8b`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:429538bcf2404e8b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L435-L435`. Next: `block:ba8ba2ce6f421de2`.

```stata
local ind2 = 1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:ba8ba2ce6f421de2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L436-L436`. Next: `block:6ffa2425049b7c8d`.

```stata
gen sector_nonag = industrycat4 ~= 1 if industrycat4 ~= .
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:5390fcf902ab7dfd`
Read candidates: `variable:a7971a01996b134e`

### block:6ffa2425049b7c8d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L437-L437`. Next: `block:14e19b3e12e7e53c`.

```stata
local indvar industrycat4 sector_nonag
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:14e19b3e12e7e53c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L438-L438`. Next: `block:df4955487cdc667a`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:df4955487cdc667a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L439-L439`. Next: `block:0b843d28c3b48574`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:0b843d28c3b48574

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L440-L440`. Next: `block:804db6fee55f66f6`.

```stata
cap des weight_p
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:804db6fee55f66f6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L441-L441`. Next: `block:749998fba417c397`.

```stata
if _rc~=0 gen weight_p = weight
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
New: `variable:86cecc735de1ed3c`
Read candidates: `variable:76068db09bff4fed`

### block:749998fba417c397

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L442-L442`. Next: `block:0633918334be81d6`.

```stata
keep code year HHID_new  __a* `wgt' `ubvar' `indvar' _pline*
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
Read candidates: `variable:b4949c8ac2967258`, `variable:f67c9eadc299026d`, `variable:8a9c2b35a7484f2c`, `variable:862bed19a2d8ac27`, `variable:f4ffa4623313b63d`

### block:0633918334be81d6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L443-L443`. Next: `block:177406f427ccfb91`.

```stata
save `data1b', replace
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
Write datasets: `dataset:4616d75592347ad4`

### block:177406f427ccfb91

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L444-L444`. Next: `block:a396711ac46a74e2`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:a396711ac46a74e2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L447-L447`. Next: `block:937c42531cfbcae8`.

```stata
cap dlw, country(`code') year(`year1') type(gmd) surveyid(`survname1') mod(`mod') files $repotxt
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`
Read datasets: `dataset:51712dd5b8516c04`

### block:937c42531cfbcae8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L448-L448`. Next: `block:a8ea293e52854861`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:a8ea293e52854861

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L449-L449`. Next: `block:eb670bc461d90126`.

```stata
egen HHID_new = group(hhid)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
New: `variable:f8cf9ab1d8bc872f`
Read candidates: `variable:4deafc5d197c50d3`

### block:eb670bc461d90126

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L450-L450`. Next: `block:72e4bc230972d9b7`.

```stata
local x1=1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:72e4bc230972d9b7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L451-L451`. Next: `block:ef9bd1b3bb2d9c3c`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:ef9bd1b3bb2d9c3c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L452-L452`. Next: `block:883185e5486012fe`.

```stata
gen double __a`ppp1' = welfare/cpi`ppp1'/icp`ppp1'/365
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
New: `variable:3c7f7431f0d29062`
Read candidates: `variable:d47779eb3221486b`, `variable:293f51addcd8aeae`, `variable:78384e94c886ce54`

### block:883185e5486012fe

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L453-L453`. Next: `block:e8182f5c3de1dd18`.

```stata
replace __a`ppp1' = ${floor`ppp1'} if __a`ppp1' < ${floor`ppp1'}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`
Modified: `variable:3c7f7431f0d29062`
Read candidates: `variable:8aa04197749f8301`, `variable:3c7f7431f0d29062`

### block:e8182f5c3de1dd18

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L454-L454`. Next: `block:f4368b9ab225d1da`.

```stata
foreach num of numlist ${plines`ppp1'} {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`

### block:f4368b9ab225d1da

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L455-L455`. Next: `block:78fa903f87314109`.

```stata
gen _pline`num' = `=`num'/100'
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
New: `variable:c87fef65fc245378`

### block:78fa903f87314109

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L456-L456`. Next: `block:cbd5ba3de841b53a`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `foreach ppp1 of global ppplist {`

### block:cbd5ba3de841b53a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L457-L457`. Next: `block:81ae5743c8bd7c97`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:81ae5743c8bd7c97

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L459-L459`. Next: `block:07c9f0be028808fa`.

```stata
local ub1 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:07c9f0be028808fa

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L460-L460`. Next: `block:7407b9fc954a3be6`.

```stata
local ubvar
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:7407b9fc954a3be6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L461-L461`. Next: `block:2c0b403d7380b0de`.

```stata
cap des urban
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:2c0b403d7380b0de

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L462-L462`. Next: `block:6a5fd15339b76180`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:6a5fd15339b76180

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L463-L463`. Next: `block:93df22e61ac8e4e1`.

```stata
su urban,d
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`
Read candidates: `variable:d0f4d88761c36350`, `variable:c13b9324875aa3e8`

### block:93df22e61ac8e4e1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L464-L464`. Next: `block:83f1ca26e8af955c`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:83f1ca26e8af955c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L465-L465`. Next: `block:70b508adbbb09763`.

```stata
local ub1 = 1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:70b508adbbb09763

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L466-L466`. Next: `block:ed07848a0e569768`.

```stata
local ubvar urban
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:ed07848a0e569768

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L467-L467`. Next: `block:890ff7190fb615c9`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:890ff7190fb615c9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L468-L468`. Next: `block:a29f9dc69c045a80`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:a29f9dc69c045a80

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L470-L470`. Next: `block:172f6014fe79d935`.

```stata
local ind1 = 0
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:172f6014fe79d935

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L471-L471`. Next: `block:749f8cc9c7cb932c`.

```stata
local indvar
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:749f8cc9c7cb932c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L472-L472`. Next: `block:05d072e03b545880`.

```stata
cap des industrycat4
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:05d072e03b545880

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L473-L473`. Next: `block:0b8ad67b13583485`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:0b8ad67b13583485

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L474-L474`. Next: `block:9f5de247d44b3ba5`.

```stata
su industrycat4,d
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`
Read candidates: `variable:5d0ac006034b2f92`, `variable:c13b9324875aa3e8`

### block:9f5de247d44b3ba5

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L475-L475`. Next: `block:96b3bfcaf2fef644`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:96b3bfcaf2fef644

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L476-L476`. Next: `block:c2d60d1ecaf4700b`.

```stata
local ind1 = 1
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:c2d60d1ecaf4700b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L477-L477`. Next: `block:2d3c6a4119a9aeb7`.

```stata
gen sector_nonag = industrycat4 ~= 1 if industrycat4 ~= .
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:ff45a50828bdb87a`
Read candidates: `variable:5d0ac006034b2f92`

### block:2d3c6a4119a9aeb7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L478-L478`. Next: `block:8d62b575a9315eee`.

```stata
local indvar industrycat4 sector_nonag
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {` → `if r(N)>0 {`

### block:8d62b575a9315eee

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L479-L479`. Next: `block:424bd1bae8b25526`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {` → `if _rc==0 {`

### block:424bd1bae8b25526

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L480-L480`. Next: `block:1df7b5637778ae7c`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:1df7b5637778ae7c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L481-L481`. Next: `block:0086f2d321f888f9`.

```stata
cap des weight_p
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`

### block:0086f2d321f888f9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L482-L482`. Next: `block:176aff42114938ef`.

```stata
if _rc~=0 gen weight_p = weight
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
New: `variable:72f0c8f14603dec4`
Read candidates: `variable:7aee173b804c9be0`

### block:176aff42114938ef

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L483-L483`. Next: `block:86959cc20aaa150c`.

```stata
keep code year HHID_new  __a* `wgt' `ubvar' `indvar' _pline*
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
Read candidates: `variable:5df5a90bab06e43d`, `variable:2039aaad787afd31`, `variable:f8cf9ab1d8bc872f`, `variable:80256376cc62914f`, `variable:9f2cd728d3187c2b`

### block:86959cc20aaa150c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L484-L484`. Next: `block:684d65dbd64c10dc`.

```stata
save `data1a', replace
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `qui if _rc==0 {`
Write datasets: `dataset:903da197524cd35e`

### block:684d65dbd64c10dc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L485-L485`. Next: `block:dee7eb6a5f093e3c`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:dee7eb6a5f093e3c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L488-L488`. Next: `block:3fb3f8b0a4d41f19`.

```stata
if `x1'==1 & `x2'==1 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:3fb3f8b0a4d41f19

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L490-L490`. Next: `block:b66d1138e4eee5eb`.

```stata
if `ub1'==1 & `ub2'==1 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {`

### block:b66d1138e4eee5eb

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L491-L491`. Next: `block:d2c51d0d4dfeef79`.

```stata
use `data1a', clear
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {`
Read datasets: `dataset:903da197524cd35e`

### block:d2c51d0d4dfeef79

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L492-L492`. Next: `block:f46e02c13015d2fe`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {`

### block:f46e02c13015d2fe

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L493-L493`. Next: `block:0441c4483ad4bda6`.

```stata
foreach num of numlist ${plines`ppp1'} {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {`

### block:0441c4483ad4bda6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L494-L494`. Next: `block:f6661dde0e853552`.

```stata
qui sedecomposition using `data1b' [aw=`wgt'], sector(urban) pline1(_pline`num') pline2(_pline`num') var1(__a`ppp1') var2(__a`ppp1') hc
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
Read candidates: `variable:990adc04c454df60`, `variable:cd0839602a6c74dc`, `variable:a14080f9f068948f`, `variable:727537baff0c3839`
Read datasets: `dataset:4616d75592347ad4`

### block:f6661dde0e853552

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L495-L495`. Next: `block:8a1730faf69ab208`.

```stata
mat a = r(b_sec)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:8a1730faf69ab208

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L496-L496`. Next: `block:a6201f2b46381bda`.

```stata
mat b = r(b_tot)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:a6201f2b46381bda

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L498-L498`. Next: `block:4be48a1283d49ac1`.

```stata
local value1 = b[1,1]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:4be48a1283d49ac1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L499-L499`. Next: `block:e7b72f48183b7111`.

```stata
local value2 = a[1,2]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:e7b72f48183b7111

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L500-L500`. Next: `block:0f609102d0187429`.

```stata
local value3 = a[2,2]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:0f609102d0187429

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L501-L501`. Next: `block:19196eeda770caf8`.

```stata
local value4 = b[3,1]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:19196eeda770caf8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L502-L502`. Next: `block:faca00d2d049c488`.

```stata
local value5 = b[4,1]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:faca00d2d049c488

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L504-L504`. Next: `block:488cf25c52b5d8e7`.

```stata
frame decomp_results2 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:488cf25c52b5d8e7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L505-L505`. Next: `block:8b7eb51a409fc06d`.

```stata
frame post decomp_results2 ("`code'") ("`welftype'") ("Huppi-Ravallion UR") ("`spellx'") ("`num'") (`value1') (`value2') (`value3') (`value4') (`value5') (`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {` → `frame decomp_results2 {`
Write datasets: `dataset:3b820d3458e8607d`

### block:8b7eb51a409fc06d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L506-L506`. Next: `block:f60d575d14c407d7`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:f60d575d14c407d7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L507-L507`. Next: `block:cf5b1735d2acd9c5`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {` → `foreach ppp1 of global ppplist {`

### block:cf5b1735d2acd9c5

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L508-L508`. Next: `block:71bc7880ac4c88e4`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ub1'==1 & `ub2'==1 {`

### block:71bc7880ac4c88e4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L509-L509`. Next: `block:05c32f1d6503f593`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {`

### block:05c32f1d6503f593

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L512-L512`. Next: `block:7a7cf840cfaf3acc`.

```stata
if `ind1'==1 & `ind2'==1 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {`

### block:7a7cf840cfaf3acc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L513-L513`. Next: `block:5d0f54fa15890239`.

```stata
use `data1a', clear
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {`
Read datasets: `dataset:903da197524cd35e`

### block:5d0f54fa15890239

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L514-L514`. Next: `block:50008f36a58e1009`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {`

### block:50008f36a58e1009

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L515-L515`. Next: `block:4c649ec3fab97bce`.

```stata
foreach num of numlist ${plines`ppp1'} {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {`

### block:4c649ec3fab97bce

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L516-L516`. Next: `block:dfac971aa4fa3019`.

```stata
qui sedecomposition using `data1b' [aw=`wgt'], sector(sector_nonag) pline1(_pline`num') pline2(_pline`num') var1(__a`ppp1') var2(__a`ppp1') hc
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
Read candidates: `variable:43af1c57d15f30d1`, `variable:4ce0e78914b8777d`, `variable:66527c5c6ddae5fc`, `variable:135ca909da06b94a`
Read datasets: `dataset:4616d75592347ad4`

### block:dfac971aa4fa3019

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L517-L517`. Next: `block:34fb6b1fd28afa4b`.

```stata
mat a = r(b_sec)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:34fb6b1fd28afa4b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L518-L518`. Next: `block:ecaaeda0bc8b55a6`.

```stata
mat b = r(b_tot)
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:ecaaeda0bc8b55a6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L520-L520`. Next: `block:978111a405da7c9b`.

```stata
local value1 = b[1,1]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:978111a405da7c9b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L521-L521`. Next: `block:f6c216fc1953efca`.

```stata
local value2 = a[1,2]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:f6c216fc1953efca

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L522-L522`. Next: `block:1cfa5991364db719`.

```stata
local value3 = a[2,2]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:1cfa5991364db719

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L523-L523`. Next: `block:5a8282ca23cb07cd`.

```stata
local value4 = b[3,1]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:5a8282ca23cb07cd

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L524-L524`. Next: `block:1d758af85a8829d1`.

```stata
local value5 = b[4,1]
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:1d758af85a8829d1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L527-L527`. Next: `block:f527becf5a8d1502`.

```stata
frame decomp_results2 {
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:f527becf5a8d1502

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L528-L528`. Next: `block:eca582cdcacb7fad`.

```stata
frame post decomp_results2 ("`code'") ("`welftype'") ("Huppi-Ravallion SEC") ("`spellx'") ("`num'") (`value1') (`value2') (`value3') (`value4') (`value5') (`ppp1')
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {` → `frame decomp_results2 {`
Write datasets: `dataset:3b820d3458e8607d`

### block:eca582cdcacb7fad

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L529-L529`. Next: `block:2fbdd5f6c0372c46`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:2fbdd5f6c0372c46

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L530-L530`. Next: `block:ead465475bcfb5f2`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {` → `foreach ppp1 of global ppplist {`

### block:ead465475bcfb5f2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L531-L531`. Next: `block:a07950079df5bf66`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {` → `if `ind1'==1 & `ind2'==1 {`

### block:a07950079df5bf66

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L532-L532`. Next: `block:fa8238b720815416`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {` → `if `x1'==1 & `x2'==1 {`

### block:fa8238b720815416

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L533-L533`. Next: `block:5893022a49df8665`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {` → `if `type'==1 {`

### block:5893022a49df8665

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L534-L534`. Next: `block:0a9dbf5c551b9548`.

```stata
}
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:0a9dbf5c551b9548

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L535-L535`. Next: `block:602768f74226690b`.

```stata
clear
```
Enclosing controls: `forv i=1(1)`nobs' {`

### block:602768f74226690b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L536-L536`. Next: `block:561bdb56c3d7503c`.

```stata
}
```

### block:561bdb56c3d7503c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L539-L539`. Next: `block:83f392c8c806513d`.

```stata
capture postclose qcdrops
```

### block:83f392c8c806513d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L541-L541`. Next: `block:703377d94d66aedc`.

```stata
use `datagic', clear
```
Read datasets: `dataset:487c529c5153c918`

### block:703377d94d66aedc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L542-L542`. Next: `block:eac9c72c135ce2cf`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_GIC", replace
```
Write datasets: `dataset:97b4d1fe2fca3006`

### block:eac9c72c135ce2cf

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L561-L561`. Next: `block:007eb04060e8a2fb`.

```stata
tempfile qcbins
```

### block:007eb04060e8a2fb

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L562-L562`. Next: `block:890a9d049c63261e`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_GIC", clear
```
Read datasets: `dataset:97b4d1fe2fca3006`

### block:890a9d049c63261e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L563-L563`. Next: `block:cc84891f59dc35c2`.

```stata
keep if data_group==1
```
Read candidates: `variable:bf62ba9a10606c58`

### block:cc84891f59dc35c2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L564-L564`. Next: `block:49303b80ac6a77f9`.

```stata
bys code year ppp welftype: gen nbins = _N
```
New: `variable:f17d78f1cdfd0993`
Read candidates: `variable:e3bd25741ad65d18`, `variable:dfa074bc00669dca`, `variable:8c524680e0249c9b`, `variable:9989b1d4c5b21096`

### block:49303b80ac6a77f9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L565-L565`. Next: `block:2dc7c6b62e6adb5a`.

```stata
keep if nbins < 100
```
Read candidates: `variable:f17d78f1cdfd0993`

### block:2dc7c6b62e6adb5a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L566-L566`. Next: `block:f4ab6e1dd580a0fb`.

```stata
bys code year ppp welftype: keep if _n==1
```

### block:f4ab6e1dd580a0fb

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L567-L567`. Next: `block:28929edd3536d04c`.

```stata
keep code year ppp welftype nbins
```
Read candidates: `variable:e3bd25741ad65d18`, `variable:dfa074bc00669dca`, `variable:8c524680e0249c9b`, `variable:9989b1d4c5b21096`, `variable:f17d78f1cdfd0993`

### block:28929edd3536d04c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L568-L568`. Next: `block:81a855d920859f78`.

```stata
save `qcbins', replace
```
Write datasets: `dataset:064b6b46d9cb8bd0`

### block:81a855d920859f78

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L569-L569`. Next: `block:fdacb3263ef8a087`.

```stata
local n_binfail = _N
```

### block:fdacb3263ef8a087

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L572-L572`. Next: `block:aaf7bbd33281f8e2`.

```stata
use `qccollect', clear
```
Read datasets: `dataset:3f8e83d7cb5e6088`

### block:aaf7bbd33281f8e2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L573-L573`. Next: `block:66cb34afa445d29e`.

```stata
local n_drops = _N
```

### block:66cb34afa445d29e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L576-L576`. Next: `block:753be647e0c6838b`.

```stata
capture log close qcflag
```

### block:753be647e0c6838b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L577-L577`. Next: `block:cbd0e5f02eefa466`.

```stata
log using "$qclog", replace text name(qcflag)
```
Write datasets: `dataset:613925dd975a1816`

### block:cbd0e5f02eefa466

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L579-L579`. Next: `block:63dc6843aa392c2e`.

```stata
dis "=============================================================="
```

### block:63dc6843aa392c2e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L580-L580`. Next: `block:dda30156c4652268`.

```stata
dis " GIC QC - FLAGGED COUNTRIES ONLY"
```

### block:dda30156c4652268

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L581-L581`. Next: `block:a1b20c4709d9d1b2`.

```stata
dis " Round: ${rnd}"
```

### block:a1b20c4709d9d1b2

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L582-L582`. Next: `block:81a822959788bc97`.

```stata
dis " Run:   `c(current_date)' `c(current_time)'"
```

### block:81a822959788bc97

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L583-L583`. Next: `block:931b67a1486bd8c5`.

```stata
dis "=============================================================="
```

### block:931b67a1486bd8c5

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L584-L584`. Next: `block:bb97cfd355eb6456`.

```stata
dis ""
```

### block:bb97cfd355eb6456

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L585-L585`. Next: `block:c1287c06cd455f56`.

```stata
dis "SECTION A - records dropped for missing welfare before tiling"
```

### block:c1287c06cd455f56

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L586-L586`. Next: `block:d07afbd4413ba0b9`.

```stata
dis "--------------------------------------------------------------"
```

### block:d07afbd4413ba0b9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L587-L587`. Next: `block:5826c26e136b0911`.

```stata
if `n_drops' == 0 {
```

### block:5826c26e136b0911

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L588-L588`. Next: `block:98ac98e73d68d7f3`.

```stata
dis "  None. No survey had missing welfare in any spell."
```
Enclosing controls: `if `n_drops' == 0 {`

### block:98ac98e73d68d7f3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L589-L589`. Next: `block:1ea854b6f2d01937`.

```stata
}
```

### block:1ea854b6f2d01937

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L590-L590`. Next: `block:c1095476eb14e68e`.

```stata
else {
```

### block:c1095476eb14e68e

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L591-L591`. Next: `block:7edae658839c0fdd`.

```stata
dis "  `n_drops' country-spell-ppp-block combination(s) affected."
```
Enclosing controls: `else {`

### block:7edae658839c0fdd

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L592-L592`. Next: `block:6b82af0fe3c9cfd3`.

```stata
dis "  A high percentage means the published GIC would have been"
```
Enclosing controls: `else {`

### block:6b82af0fe3c9cfd3

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L593-L593`. Next: `block:6c5be8972309fab0`.

```stata
dis "  materially wrong without the fix."
```
Enclosing controls: `else {`

### block:6c5be8972309fab0

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L594-L594`. Next: `block:f70c3258882e96ee`.

```stata
dis ""
```
Enclosing controls: `else {`

### block:f70c3258882e96ee

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L595-L595`. Next: `block:23e87f9e73d50d73`.

```stata
use `qccollect', clear
```
Enclosing controls: `else {`
Read datasets: `dataset:3f8e83d7cb5e6088`

### block:23e87f9e73d50d73

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L596-L596`. Next: `block:9175e3504272dd01`.

```stata
gsort -qc_pctdropped
```
Enclosing controls: `else {`

### block:9175e3504272dd01

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L597-L598`. Next: `block:67eb92ccf71b8c89`.

```stata
list qc_code qc_spell qc_welf qc_ppp qc_block qc_ndropped qc_ntotal qc_pctdropped, noobs sep(0) abbrev(12)
```
Enclosing controls: `else {`

### block:67eb92ccf71b8c89

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L599-L599`. Next: `block:3f08647b81d663f1`.

```stata
}
```

### block:3f08647b81d663f1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L601-L601`. Next: `block:2cfb4e111e9a9edd`.

```stata
dis ""
```

### block:2cfb4e111e9a9edd

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L602-L602`. Next: `block:a49d86fdfdc34107`.

```stata
dis "SECTION B - national GIC series with fewer than 100 bins"
```

### block:a49d86fdfdc34107

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L603-L603`. Next: `block:9f04f11ee88a7ea8`.

```stata
dis "--------------------------------------------------------------"
```

### block:9f04f11ee88a7ea8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L604-L604`. Next: `block:b2cdf9c0732ba515`.

```stata
if `n_binfail' == 0 {
```

### block:b2cdf9c0732ba515

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L605-L605`. Next: `block:c08acfa24d0811ce`.

```stata
dis "  None. All national GIC series have a full 100 bins."
```
Enclosing controls: `if `n_binfail' == 0 {`

### block:c08acfa24d0811ce

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L606-L606`. Next: `block:26a5ad76cae69456`.

```stata
}
```

### block:26a5ad76cae69456

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L607-L607`. Next: `block:f78ded782d9e34da`.

```stata
else {
```

### block:f78ded782d9e34da

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L608-L608`. Next: `block:e4efa97efc5af025`.

```stata
dis "  `n_binfail' series still incomplete - INVESTIGATE before release."
```
Enclosing controls: `else {`

### block:e4efa97efc5af025

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L609-L609`. Next: `block:55dbd0b8b5db10c8`.

```stata
dis "  With FIX 1 and FIX 2 applied this should normally be empty."
```
Enclosing controls: `else {`

### block:55dbd0b8b5db10c8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L610-L610`. Next: `block:efaf1fa946e3b8c7`.

```stata
dis ""
```
Enclosing controls: `else {`

### block:efaf1fa946e3b8c7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L611-L611`. Next: `block:c95e56eb86825c42`.

```stata
use `qcbins', clear
```
Enclosing controls: `else {`
Read datasets: `dataset:064b6b46d9cb8bd0`

### block:c95e56eb86825c42

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L612-L612`. Next: `block:5ecf3ca4197ef2c4`.

```stata
list code year ppp welftype nbins, noobs sep(0)
```
Enclosing controls: `else {`

### block:5ecf3ca4197ef2c4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L613-L613`. Next: `block:84c1b12f904a3bac`.

```stata
}
```

### block:84c1b12f904a3bac

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L615-L615`. Next: `block:3ac5c220c80253b9`.

```stata
dis ""
```

### block:3ac5c220c80253b9

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L616-L616`. Next: `block:2d911ef844e131f8`.

```stata
dis "=============================================================="
```

### block:2d911ef844e131f8

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L617-L617`. Next: `block:19dac034628206a1`.

```stata
if `n_drops'==0 & `n_binfail'==0 {
```

### block:19dac034628206a1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L618-L618`. Next: `block:b9c8fb524198c453`.

```stata
dis " RESULT: CLEAN - nothing flagged."
```
Enclosing controls: `if `n_drops'==0 & `n_binfail'==0 {`

### block:b9c8fb524198c453

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L619-L619`. Next: `block:43191c2695d055de`.

```stata
}
```

### block:43191c2695d055de

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L620-L620`. Next: `block:33629f1127686c03`.

```stata
else {
```

### block:33629f1127686c03

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L621-L621`. Next: `block:4324e1a925f48b2d`.

```stata
dis " RESULT: `n_drops' drop event(s), `n_binfail' incomplete series."
```
Enclosing controls: `else {`

### block:4324e1a925f48b2d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L622-L622`. Next: `block:3f60d91a47cde7dc`.

```stata
}
```

### block:3f60d91a47cde7dc

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L623-L623`. Next: `block:c891da1b21649b9c`.

```stata
dis "=============================================================="
```

### block:c891da1b21649b9c

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L625-L625`. Next: `block:71c66f060d7dc5b7`.

```stata
log close qcflag
```

### block:71c66f060d7dc5b7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L628-L628`. Next: `block:8b983ad4a76d431d`.

```stata
use `qccollect', clear
```
Read datasets: `dataset:3f8e83d7cb5e6088`

### block:8b983ad4a76d431d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L629-L629`. Next: `block:f6616a72d93e9cb4`.

```stata
gen str12 qc_section = "A_dropped"
```
New: `variable:9ef1d6d598ac3e5b`

### block:f6616a72d93e9cb4

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L630-L630`. Next: `block:e8e70639af624c9d`.

```stata
if `n_binfail' > 0 {
```

### block:e8e70639af624c9d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L631-L631`. Next: `block:c550ba3969988e05`.

```stata
tempfile qcA
```
Enclosing controls: `if `n_binfail' > 0 {`

### block:c550ba3969988e05

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L632-L632`. Next: `block:b8f5ff4fe883ffb1`.

```stata
save `qcA', replace
```
Enclosing controls: `if `n_binfail' > 0 {`
Write datasets: `dataset:19195d204fba7f6e`

### block:b8f5ff4fe883ffb1

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L633-L633`. Next: `block:4a851f950092f9da`.

```stata
use `qcbins', clear
```
Enclosing controls: `if `n_binfail' > 0 {`
Read datasets: `dataset:064b6b46d9cb8bd0`

### block:4a851f950092f9da

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L634-L634`. Next: `block:c26cb958a08c3d89`.

```stata
tostring year, replace
```
Enclosing controls: `if `n_binfail' > 0 {`
Modified: `variable:1c4076a26c3f017e`
Read candidates: `variable:1c4076a26c3f017e`

### block:c26cb958a08c3d89

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L635-L635`. Next: `block:5b759ab98d2e6201`.

```stata
rename (code year ppp welftype nbins) (qc_code qc_spell qc_ppp qc_welf qc_nbins)
```
Enclosing controls: `if `n_binfail' > 0 {`
New: `variable:47a6a23cd6485834`, `variable:22938b9680b9bab1`, `variable:d19b0a1ba078c5ec`, `variable:36a78665ba17d152`, `variable:e7abf5ba14ed63ad`
Read candidates: `variable:5cb26fa480e2bfed`, `variable:1c4076a26c3f017e`, `variable:d72e1759f550b31f`, `variable:f04474016cdef316`, `variable:ec8af207820bb4bd`

### block:5b759ab98d2e6201

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L636-L636`. Next: `block:159ca0d7f382ef83`.

```stata
gen str12 qc_section = "B_bins_lt100"
```
Enclosing controls: `if `n_binfail' > 0 {`
New: `variable:638ebd340ad9892f`

### block:159ca0d7f382ef83

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L637-L637`. Next: `block:ce008e01f449006d`.

```stata
append using `qcA'
```
Enclosing controls: `if `n_binfail' > 0 {`
Read datasets: `dataset:19195d204fba7f6e`

### block:ce008e01f449006d

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L638-L638`. Next: `block:384d8a529d3e0aa6`.

```stata
}
```

### block:384d8a529d3e0aa6

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L639-L639`. Next: `block:d1e17ccbc70f9210`.

```stata
export delimited using "$qccsv", replace
```
Write datasets: `dataset:d026fafdcd1e36ae`

### block:d1e17ccbc70f9210

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L641-L641`. Next: `block:84b37f0405274663`.

```stata
noi dis in green "QC log written to: $qclog"
```

### block:84b37f0405274663

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L642-L642`. Next: `block:123cecfd66126635`.

```stata
noi dis in green "QC csv written to: $qccsv"
```

### block:123cecfd66126635

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L645-L645`. Next: `block:77722577814e8666`.

```stata
use `prosdecomp', clear
```
Read datasets: `dataset:a404fd2d1680b9c0`

### block:77722577814e8666

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L646-L646`. Next: `block:28da60cede52159a`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_prosg_decomp", replace
```
Write datasets: `dataset:f60ae57952f91282`

### block:28da60cede52159a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L648-L648`. Next: `block:1f55094345cade68`.

```stata
frame change decomp_results
```

### block:1f55094345cade68

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L649-L649`. Next: `block:76aba104ed82ce00`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_decomp1", replace
```
Write datasets: `dataset:95a0eaf4ef22f613`

### block:76aba104ed82ce00

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L651-L651`. Next: `block:1ca31fe01bdf4ebb`.

```stata
frame change decomp_results2
```

### block:1ca31fe01bdf4ebb

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L652-L652`. Next: `block:2a79a6c46e150e49`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_decomp2", replace
```
Write datasets: `dataset:21a89f14bf7eb45c`

### block:2a79a6c46e150e49

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L653-L653`. Next: `block:48b9a4371d86eb08`.

```stata
s
```

### block:48b9a4371d86eb08

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L654-L654`. Next: `block:2840b93fe607f75a`.

```stata
reshape long value, i(decomp spell povline) j(subind)
```
Read candidates: `variable:1c8e32590edb6672`, `variable:f7e0e87d6455d0b9`, `variable:f5ed34269cd1e1e3`, `variable:e6518e270b8302f7`, `variable:ee18fb70c087ad78`

### block:2840b93fe607f75a

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L655-L655`. Next: `block:f4222d9c00b2921b`.

```stata
la def subind 1 "Total change in p.p." 2 "Growth" 3 "Redistribution" 4 "Line"
```

### block:f4222d9c00b2921b

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L656-L656`. Next: `block:7c4684391032d1a7`.

```stata
la val subind subind
```

### block:7c4684391032d1a7

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L657-L657`. Next: `block:b695d4dde924d259`.

```stata
decomp_results2
```

### block:b695d4dde924d259

Evidence: `01.Programs/archive/01b-GMI extended indicators spells.do:L658-L658`. Next: `end`.

```stata
la def subind 1 "Total change in p.p." `rlbl' 4 "Population shift" 5 "Interaction"
```
