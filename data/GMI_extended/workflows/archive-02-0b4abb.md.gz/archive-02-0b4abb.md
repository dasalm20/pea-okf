# 01.Programs/archive/02-GMI format.do

Format demographic, labor, GIC and decomposition outputs

Status: PARTIAL_STATIC. Every lexically active statement is indexed; complete runtime schema and macro expansion are not established.

Source snapshot: numbered source (deployment lookup: lookup/sources/GMI_extended/source_maps/archive-02-0b4abb.md.md)

## Execution-order blocks

### block:d3e0ac67d81300dc

Evidence: `01.Programs/archive/02-GMI format.do:L3-L3`. Next: `block:a7f916f22b6d2287`.

```stata
global rnd SM26
```

### block:a7f916f22b6d2287

Evidence: `01.Programs/archive/02-GMI format.do:L4-L4`. Next: `block:3afd86eb8c524c25`.

```stata
global rnd1 SM2026
```

### block:3afd86eb8c524c25

Evidence: `01.Programs/archive/02-GMI format.do:L5-L5`. Next: `block:df12576f6ad2dc87`.

```stata
global path \\wbgfscifs01\GTSD\03.projects_corp\04.GPWG\04.GPWG_${rnd}\04.GPWG_${rnd}_QA
```

### block:df12576f6ad2dc87

Evidence: `01.Programs/archive/02-GMI format.do:L6-L6`. Next: `block:75a3621996ce957d`.

```stata
global reposource "${path}\01.programs\02.dofile\repo\"
```

### block:75a3621996ce957d

Evidence: `01.Programs/archive/02-GMI format.do:L8-L8`. Next: `block:a0cea4d71436647c`.

```stata
global out D:\daylan\test\GMI\out\
```

### block:a0cea4d71436647c

Evidence: `01.Programs/archive/02-GMI format.do:L9-L9`. Next: `block:f2f2c250dd3972d6`.

```stata
global pfw "D:\daylan\test\GMI\Survey_price_framework.dta"
```

### block:f2f2c250dd3972d6

Evidence: `01.Programs/archive/02-GMI format.do:L10-L10`. Next: `block:47dc92762babaca1`.

```stata
global pea "${out}\04.output\PEA_Dashboard\"
```

### block:47dc92762babaca1

Evidence: `01.Programs/archive/02-GMI format.do:L12-L12`. Next: `block:943e71f5d25e6260`.

```stata
global ppplist 2017 2021
```

### block:943e71f5d25e6260

Evidence: `01.Programs/archive/02-GMI format.do:L13-L13`. Next: `block:caf885ea0dfc2609`.

```stata
global pppmax 2021
```

### block:caf885ea0dfc2609

Evidence: `01.Programs/archive/02-GMI format.do:L15-L15`. Next: `block:4a5418d02e1da63c`.

```stata
global plines2021 300 420 830 450 630 1245 600 840 1660
```

### block:4a5418d02e1da63c

Evidence: `01.Programs/archive/02-GMI format.do:L16-L16`. Next: `block:18c1537cf5bf2452`.

```stata
global plines2017 215 365 685 322 547 1027 430 730 1370
```

### block:18c1537cf5bf2452

Evidence: `01.Programs/archive/02-GMI format.do:L17-L17`. Next: `block:c50337ac62f6daeb`.

```stata
global plines2011 190 320 550
```

### block:c50337ac62f6daeb

Evidence: `01.Programs/archive/02-GMI format.do:L20-L20`. Next: `block:584158307d7857e4`.

```stata
tempfile data1pfw
```

### block:584158307d7857e4

Evidence: `01.Programs/archive/02-GMI format.do:L21-L21`. Next: `block:ddff747404b373ff`.

```stata
use "$pfw" , clear
```
Read datasets: `dataset:0fa1cc3d12b9e4be`

### block:ddff747404b373ff

Evidence: `01.Programs/archive/02-GMI format.do:L22-L22`. Next: `block:32e42de01745ea85`.

```stata
gen welftype = "CONS" if datatype=="c"|datatype=="C"
```
New: `variable:d3eae46ebdd76cdb`
Read candidates: `variable:d4c9539f02668501`

### block:32e42de01745ea85

Evidence: `01.Programs/archive/02-GMI format.do:L23-L23`. Next: `block:7f899ec385b3b075`.

```stata
replace welftype = "INC" if datatype=="i"|datatype=="I"
```
Modified: `variable:d3eae46ebdd76cdb`
Read candidates: `variable:d4c9539f02668501`

### block:7f899ec385b3b075

Evidence: `01.Programs/archive/02-GMI format.do:L24-L24`. Next: `block:d344cd3f36fdc58c`.

```stata
isid code year welftype
```
Read candidates: `variable:5e56739be2ebf745`, `variable:8d2477fdf93d7840`, `variable:d3eae46ebdd76cdb`

### block:d344cd3f36fdc58c

Evidence: `01.Programs/archive/02-GMI format.do:L25-L25`. Next: `block:8d283b1ea3b83825`.

```stata
save `data1pfw', replace
```
Write datasets: `dataset:ccfc1bd3bc5a5910`

### block:8d283b1ea3b83825

Evidence: `01.Programs/archive/02-GMI format.do:L28-L28`. Next: `block:30fb98e8cc9e4e48`.

```stata
tempfile data1
```

### block:30fb98e8cc9e4e48

Evidence: `01.Programs/archive/02-GMI format.do:L29-L29`. Next: `block:bab1228b14694c23`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_allgroups1", clear
```
Read datasets: `dataset:1a291c72644c9300`

### block:bab1228b14694c23

Evidence: `01.Programs/archive/02-GMI format.do:L31-L31`. Next: `block:36273a9e564ea6ac`.

```stata
drop lvlvar
```
Read candidates: `variable:8d065155a4af317b`

### block:36273a9e564ea6ac

Evidence: `01.Programs/archive/02-GMI format.do:L32-L32`. Next: `block:229523c0f13986ec`.

```stata
replace level = trim(level)
```
Modified: `variable:78d93e682673618d`
Read candidates: `variable:78d93e682673618d`

### block:229523c0f13986ec

Evidence: `01.Programs/archive/02-GMI format.do:L33-L33`. Next: `block:41fb6ffb77356759`.

```stata
replace level = proper(level)
```
Modified: `variable:78d93e682673618d`
Read candidates: `variable:78d93e682673618d`

### block:41fb6ffb77356759

Evidence: `01.Programs/archive/02-GMI format.do:L34-L34`. Next: `block:d0350f0a1ff57b0d`.

```stata
drop poor
```
Read candidates: `variable:784af7e2443c0dfd`

### block:d0350f0a1ff57b0d

Evidence: `01.Programs/archive/02-GMI format.do:L35-L35`. Next: `block:5268742c9fb744fe`.

```stata
gen data = ""
```
New: `variable:efe30c22f0cabbc2`

### block:5268742c9fb744fe

Evidence: `01.Programs/archive/02-GMI format.do:L36-L36`. Next: `block:cea10329d32a2ca2`.

```stata
replace data = "All sample" if byvar=="_all_"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:cea10329d32a2ca2

Evidence: `01.Programs/archive/02-GMI format.do:L37-L37`. Next: `block:c74336aee2eeebf9`.

```stata
replace data = "Urban or rural" if byvar=="_urban_"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:c74336aee2eeebf9

Evidence: `01.Programs/archive/02-GMI format.do:L38-L38`. Next: `block:1cd627636a9f5916`.

```stata
replace data = "Gender" if byvar=="_male_"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:1cd627636a9f5916

Evidence: `01.Programs/archive/02-GMI format.do:L39-L39`. Next: `block:d8718d5f980c13b2`.

```stata
replace data = "Education" if byvar=="_educat"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:d8718d5f980c13b2

Evidence: `01.Programs/archive/02-GMI format.do:L40-L40`. Next: `block:ba222166f1c4a843`.

```stata
replace data = "Age groups" if byvar=="_agegr1_"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:ba222166f1c4a843

Evidence: `01.Programs/archive/02-GMI format.do:L41-L41`. Next: `block:a2964f5950e5422f`.

```stata
replace data = "Gender-age 5-year groups" if byvar=="_agegender1"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:a2964f5950e5422f

Evidence: `01.Programs/archive/02-GMI format.do:L42-L42`. Next: `block:16b594d2fca593f1`.

```stata
replace data = "Gender-age groups" if byvar=="_agegender2"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:16b594d2fca593f1

Evidence: `01.Programs/archive/02-GMI format.do:L43-L43`. Next: `block:33d96cd56e137a45`.

```stata
replace data = "HH head age groups" if byvar=="_agegr2Xhh"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:33d96cd56e137a45

Evidence: `01.Programs/archive/02-GMI format.do:L44-L44`. Next: `block:22821be59e1273a0`.

```stata
replace data = "HH head education" if byvar=="_eduXhh"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:22821be59e1273a0

Evidence: `01.Programs/archive/02-GMI format.do:L45-L45`. Next: `block:a2356ba23bac224e`.

```stata
replace data = "HH head gender" if byvar=="_maleXhh"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:a2356ba23bac224e

Evidence: `01.Programs/archive/02-GMI format.do:L46-L46`. Next: `block:b6a65174a5303db5`.

```stata
replace data = "Labor status" if byvar=="_lstatus"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:b6a65174a5303db5

Evidence: `01.Programs/archive/02-GMI format.do:L47-L47`. Next: `block:46c651634290368f`.

```stata
replace data = "Labor status 2" if byvar=="_lstatus2"
```
Modified: `variable:efe30c22f0cabbc2`
Read candidates: `variable:b33d6a8a45d85c50`

### block:46c651634290368f

Evidence: `01.Programs/archive/02-GMI format.do:L49-L49`. Next: `block:4e30f5f9d4e568a2`.

```stata
gen data_group = ""
```
New: `variable:9c53aa7b8363c5eb`

### block:4e30f5f9d4e568a2

Evidence: `01.Programs/archive/02-GMI format.do:L51-L51`. Next: `block:9c27f55d6d83b27d`.

```stata
local byvarlist _all_ _urban_ _male_ _educat _agegr1_ _agegender1 _agegender2 _agegr2Xhh _eduXhh _maleXhh _lstatus _lstatus2
```

### block:9c27f55d6d83b27d

Evidence: `01.Programs/archive/02-GMI format.do:L52-L52`. Next: `block:ac705187d3b95513`.

```stata
foreach byvar1 of local byvarlist {
```

### block:ac705187d3b95513

Evidence: `01.Programs/archive/02-GMI format.do:L53-L53`. Next: `block:66454e71bc2c913e`.

```stata
replace data_group = level if byvar=="`byvar1'"
```
Enclosing controls: `foreach byvar1 of local byvarlist {`
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:78d93e682673618d`, `variable:b33d6a8a45d85c50`

### block:66454e71bc2c913e

Evidence: `01.Programs/archive/02-GMI format.do:L54-L54`. Next: `block:71baf3718832d177`.

```stata
}
```

### block:71baf3718832d177

Evidence: `01.Programs/archive/02-GMI format.do:L56-L56`. Next: `block:aa21ca464a5b5a69`.

```stata
replace data_group = "Urban" if byvar=="_urban_" & level=="1"| level=="1.Urban"
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:aa21ca464a5b5a69

Evidence: `01.Programs/archive/02-GMI format.do:L57-L57`. Next: `block:39001da38899007f`.

```stata
replace data_group = "Rural" if byvar=="_urban_" & level=="0"| level=="0.Rural"
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:39001da38899007f

Evidence: `01.Programs/archive/02-GMI format.do:L59-L59`. Next: `block:5604199cddf04440`.

```stata
replace data_group = "Male" if byvar=="_male_" & level=="1"| level=="1. Male"|level=="1.Male"
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:5604199cddf04440

Evidence: `01.Programs/archive/02-GMI format.do:L60-L60`. Next: `block:7e2032f75e4b72e5`.

```stata
replace data_group = "Female" if byvar=="_male_" & level=="0"| level=="0.Female"
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:7e2032f75e4b72e5

Evidence: `01.Programs/archive/02-GMI format.do:L61-L61`. Next: `block:d9ea539e4a8f77f4`.

```stata
replace data_group = "Missing" if byvar=="_male_" & level=="."
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:d9ea539e4a8f77f4

Evidence: `01.Programs/archive/02-GMI format.do:L63-L63`. Next: `block:f3955b1c09948a1b`.

```stata
replace data_group = "Male" if byvar=="_maleXhh" & level=="1"| level=="1. Male"|level=="1.Male"
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:f3955b1c09948a1b

Evidence: `01.Programs/archive/02-GMI format.do:L64-L64`. Next: `block:73dc478cb82f4b16`.

```stata
replace data_group = "Female" if byvar=="_maleXhh" & level=="0"| level=="0.Female"
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:73dc478cb82f4b16

Evidence: `01.Programs/archive/02-GMI format.do:L65-L65`. Next: `block:46728ff3e82ccf29`.

```stata
replace data_group = "Missing" if byvar=="_maleXhh" & level=="."
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:46728ff3e82ccf29

Evidence: `01.Programs/archive/02-GMI format.do:L67-L67`. Next: `block:71f58de7ff004100`.

```stata
replace data_group = "Missing" if byvar=="_agegender2" & (level=="F_"|level=="M_")
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:71f58de7ff004100

Evidence: `01.Programs/archive/02-GMI format.do:L68-L68`. Next: `block:b600af05573325b1`.

```stata
replace data_group = "Missing" if byvar=="_agegender1" & (level=="F_"|level=="M_")
```
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:b600af05573325b1

Evidence: `01.Programs/archive/02-GMI format.do:L69-L69`. Next: `block:7343eeeb436950b3`.

```stata
forv x=0(5)70 {
```

### block:7343eeeb436950b3

Evidence: `01.Programs/archive/02-GMI format.do:L70-L70`. Next: `block:03df1d3f82484cc2`.

```stata
replace data_group = "Missing" if byvar=="_agegender1" & level=="`x'-"
```
Enclosing controls: `forv x=0(5)70 {`
Modified: `variable:9c53aa7b8363c5eb`
Read candidates: `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`

### block:03df1d3f82484cc2

Evidence: `01.Programs/archive/02-GMI format.do:L71-L71`. Next: `block:14920a755c17d752`.

```stata
}
```

### block:14920a755c17d752

Evidence: `01.Programs/archive/02-GMI format.do:L72-L72`. Next: `block:0a034179bc9498f3`.

```stata
drop if data_group=="9" & (data=="Gender"|data=="HH head gender")
```
Read candidates: `variable:9c53aa7b8363c5eb`, `variable:efe30c22f0cabbc2`

### block:0a034179bc9498f3

Evidence: `01.Programs/archive/02-GMI format.do:L74-L74`. Next: `block:3117f5c452c8109d`.

```stata
save `data1', replace
```
Write datasets: `dataset:5a2ef51d43dd56ca`

### block:3117f5c452c8109d

Evidence: `01.Programs/archive/02-GMI format.do:L76-L76`. Next: `block:80a36765803ae5ed`.

```stata
sort code year surveyid byvar level
```

### block:80a36765803ae5ed

Evidence: `01.Programs/archive/02-GMI format.do:L77-L77`. Next: `block:1bf78466cb1c8d64`.

```stata
drop mean2017 mean2021 nohh count noind* gini theil totalhh totalind* sh_hh sh_pop* sh_b40 sh_t60 sh_d_1 sh_d_2 sh_d_3 sh_d_4 sh_d_5 prosgap2017 prosgap2021 poor_b40 poor_d1 poor_d2 poor_d3 poor_d4 poor_d5
```
Read candidates: `variable:a905b6db5be9c172`, `variable:60f598bd934bf2f0`, `variable:718bedb6497e305a`, `variable:45417e5296644cb4`, `variable:ea337113fe429ea2`, `variable:4838b032550856f5`, `variable:fc1a41aa2b777c65`, `variable:4a60d66325f16969`, `variable:79b0f2e1d1e0b6d3`, `variable:8fb0c3a68713fbdd`, `variable:a6c7015a6cbad95d`, `variable:27cd4b4639a2ff3d`, `variable:27aa725a1947eacd`, `variable:c4ba338867513811`, `variable:bdcb86c1d3ee8a29`, `variable:20b9144cbdff237d`, `variable:563869b577a0f145`, `variable:f1cc652b87cd5b15`, `variable:182f43e05d27a1ad`, `variable:c4b339d94ec868a2`, `variable:0fd6ed66b6cd492a`, `variable:2f81f5f6ebba1a16`, `variable:258d8799b5cf75cd`, `variable:eb71f81316fdbd73`, `variable:34e4b3012d003c08`, `variable:d5da1c616598d897`

### block:1bf78466cb1c8d64

Evidence: `01.Programs/archive/02-GMI format.do:L79-L79`. Next: `block:8595390f6b79bb6e`.

```stata
reshape long poor gap1_ gap2_, i( code surveyid year mod byvar level data data_group) j(line)
```
Read candidates: `variable:784af7e2443c0dfd`, `variable:2cfe4f24271f72ef`, `variable:a88b5cff420e4dfb`, `variable:7eaf02b90badee77`, `variable:345b234b7f9aed18`, `variable:05cfbcd81a6123a5`, `variable:d383ad922ecb9e37`, `variable:b33d6a8a45d85c50`, `variable:78d93e682673618d`, `variable:efe30c22f0cabbc2`, `variable:9c53aa7b8363c5eb`, `variable:cccd162db92c2fc5`

### block:8595390f6b79bb6e

Evidence: `01.Programs/archive/02-GMI format.do:L81-L81`. Next: `block:7ae48b3a64a913ab`.

```stata
gen ppp = .
```
New: `variable:2cfe74bf61835a06`

### block:7ae48b3a64a913ab

Evidence: `01.Programs/archive/02-GMI format.do:L82-L82`. Next: `block:e839f7b8fe36131e`.

```stata
foreach ppp1 of global ppplist {
```

### block:e839f7b8fe36131e

Evidence: `01.Programs/archive/02-GMI format.do:L83-L83`. Next: `block:f837b60d19bdf6a8`.

```stata
foreach num of numlist ${plines`ppp1'} {
```
Enclosing controls: `foreach ppp1 of global ppplist {`

### block:f837b60d19bdf6a8

Evidence: `01.Programs/archive/02-GMI format.do:L84-L84`. Next: `block:b83b7146a969a08b`.

```stata
replace ppp = `ppp1' if line==`num'
```
Enclosing controls: `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
Modified: `variable:2cfe74bf61835a06`
Read candidates: `variable:cccd162db92c2fc5`

### block:b83b7146a969a08b

Evidence: `01.Programs/archive/02-GMI format.do:L85-L85`. Next: `block:1977945a4ac45345`.

```stata
}
```
Enclosing controls: `foreach ppp1 of global ppplist {`

### block:1977945a4ac45345

Evidence: `01.Programs/archive/02-GMI format.do:L86-L86`. Next: `block:635bc694d313f764`.

```stata
}
```

### block:635bc694d313f764

Evidence: `01.Programs/archive/02-GMI format.do:L88-L88`. Next: `block:18ab9f3192271efc`.

```stata
gen linegroup = .
```
New: `variable:1c55d7302a685cb5`

### block:18ab9f3192271efc

Evidence: `01.Programs/archive/02-GMI format.do:L89-L89`. Next: `block:f3f72617e4e0d69f`.

```stata
replace linegroup = 1 if inlist(line,300, 420, 830, 215, 365, 685)
```
Modified: `variable:1c55d7302a685cb5`
Read candidates: `variable:cccd162db92c2fc5`

### block:f3f72617e4e0d69f

Evidence: `01.Programs/archive/02-GMI format.do:L90-L90`. Next: `block:fa3e41809663ae69`.

```stata
replace linegroup = 2 if inlist(line,450, 630, 1245, 322, 547, 1027)
```
Modified: `variable:1c55d7302a685cb5`
Read candidates: `variable:cccd162db92c2fc5`

### block:fa3e41809663ae69

Evidence: `01.Programs/archive/02-GMI format.do:L91-L91`. Next: `block:bf15e84dfec7d3e5`.

```stata
replace linegroup = 3 if inlist(line,600, 840, 1660, 430, 730, 1370)
```
Modified: `variable:1c55d7302a685cb5`
Read candidates: `variable:cccd162db92c2fc5`

### block:bf15e84dfec7d3e5

Evidence: `01.Programs/archive/02-GMI format.do:L92-L92`. Next: `block:5c319b51d09ac498`.

```stata
la def linegroup 1 "International PLs" 2 "1.5*International PLs" 3 "2*International PLs"
```

### block:5c319b51d09ac498

Evidence: `01.Programs/archive/02-GMI format.do:L93-L93`. Next: `block:4521969c1ca2f348`.

```stata
la val linegroup linegroup
```

### block:4521969c1ca2f348

Evidence: `01.Programs/archive/02-GMI format.do:L95-L95`. Next: `block:de12e82390cfe228`.

```stata
sort code surveyid year mod ppp line byvar level
```

### block:de12e82390cfe228

Evidence: `01.Programs/archive/02-GMI format.do:L97-L97`. Next: `block:41fc4943fc6e15cd`.

```stata
merge m:1 code surveyid year mod byvar level using `data1', keepus(noind* sh_hh sh_pop*)
```
Read datasets: `dataset:5a2ef51d43dd56ca`

### block:41fc4943fc6e15cd

Evidence: `01.Programs/archive/02-GMI format.do:L99-L99`. Next: `block:afa2582e1d71ef62`.

```stata
drop _merge
```
Read candidates: `variable:1137fdd538d20093`

### block:afa2582e1d71ef62

Evidence: `01.Programs/archive/02-GMI format.do:L100-L100`. Next: `block:a2533d6a80e6939b`.

```stata
sort code surveyid year mod ppp line byvar level
```

### block:a2533d6a80e6939b

Evidence: `01.Programs/archive/02-GMI format.do:L103-L103`. Next: `block:c51ae57c25b443e2`.

```stata
replace sh_pop = sh_pop15p if byvar=="_educat"
```
Modified: `variable:a6c7015a6cbad95d`
Read candidates: `variable:213b07090ac55d2f`, `variable:b33d6a8a45d85c50`

### block:c51ae57c25b443e2

Evidence: `01.Programs/archive/02-GMI format.do:L104-L104`. Next: `block:5b9a9ecb25acc5eb`.

```stata
replace sh_pop = sh_pop1564 if byvar=="_lstatus"|byvar=="_lstatus2"
```
Modified: `variable:a6c7015a6cbad95d`
Read candidates: `variable:b45fd727b4e504bc`, `variable:b33d6a8a45d85c50`

### block:5b9a9ecb25acc5eb

Evidence: `01.Programs/archive/02-GMI format.do:L106-L106`. Next: `block:b58c74bf44a103b9`.

```stata
drop if data_group=="Missing"
```
Read candidates: `variable:9c53aa7b8363c5eb`

### block:b58c74bf44a103b9

Evidence: `01.Programs/archive/02-GMI format.do:L107-L107`. Next: `block:94247c7e607ccac2`.

```stata
ren poor fgt0_headcount
```
New: `variable:159da1eb48ee91c2`
Read candidates: `variable:784af7e2443c0dfd`

### block:94247c7e607ccac2

Evidence: `01.Programs/archive/02-GMI format.do:L108-L108`. Next: `block:2547cade87aa85b3`.

```stata
gen fgt0_npoor = fgt0_headcount*noind
```
New: `variable:8ee50ac7c13c492e`
Read candidates: `variable:159da1eb48ee91c2`, `variable:ea337113fe429ea2`

### block:2547cade87aa85b3

Evidence: `01.Programs/archive/02-GMI format.do:L109-L109`. Next: `block:b1f02eea3aeb7097`.

```stata
replace fgt0_npoor = fgt0_headcount*noind15p if byvar=="_educat"
```
Modified: `variable:8ee50ac7c13c492e`
Read candidates: `variable:159da1eb48ee91c2`, `variable:4f7afef364e030c3`, `variable:b33d6a8a45d85c50`

### block:b1f02eea3aeb7097

Evidence: `01.Programs/archive/02-GMI format.do:L110-L110`. Next: `block:5ebabe8470a03060`.

```stata
replace fgt0_npoor = fgt0_headcount*noind1564 if byvar=="_lstatus"|byvar=="_lstatus2"
```
Modified: `variable:8ee50ac7c13c492e`
Read candidates: `variable:159da1eb48ee91c2`, `variable:2dc8f895f3a2d331`, `variable:b33d6a8a45d85c50`

### block:5ebabe8470a03060

Evidence: `01.Programs/archive/02-GMI format.do:L111-L111`. Next: `block:13113d60ff3b1035`.

```stata
ren gap1_ fgt1
```
New: `variable:2aed16fb9bd5e29a`
Read candidates: `variable:2cfe4f24271f72ef`

### block:13113d60ff3b1035

Evidence: `01.Programs/archive/02-GMI format.do:L112-L112`. Next: `block:5e9a1bb9bc80155e`.

```stata
ren gap2_ fgt2
```
New: `variable:6581cdf6771dc868`
Read candidates: `variable:a88b5cff420e4dfb`

### block:5e9a1bb9bc80155e

Evidence: `01.Programs/archive/02-GMI format.do:L114-L114`. Next: `block:d2b01ca3dde1e989`.

```stata
bys code surveyid year ppp line data (data_group): egen totalpoor = total(fgt0_npoor)
```
New: `variable:5ed9872c78126a37`
Read candidates: `variable:8ee50ac7c13c492e`, `variable:7eaf02b90badee77`, `variable:345b234b7f9aed18`, `variable:05cfbcd81a6123a5`, `variable:2cfe74bf61835a06`, `variable:cccd162db92c2fc5`, `variable:9c53aa7b8363c5eb`

### block:d2b01ca3dde1e989

Evidence: `01.Programs/archive/02-GMI format.do:L115-L115`. Next: `block:21a76dccf7a9dbca`.

```stata
sort code surveyid year ppp line data data_group
```

### block:21a76dccf7a9dbca

Evidence: `01.Programs/archive/02-GMI format.do:L116-L116`. Next: `block:88fd1017977b8baa`.

```stata
gen fgt0_sharepoor = fgt0_npoor/totalpoor
```
New: `variable:8211785cb586f894`
Read candidates: `variable:8ee50ac7c13c492e`, `variable:5ed9872c78126a37`

### block:88fd1017977b8baa

Evidence: `01.Programs/archive/02-GMI format.do:L118-L118`. Next: `block:d75c3e028d04d231`.

```stata
la var code "Country code"
```

### block:d75c3e028d04d231

Evidence: `01.Programs/archive/02-GMI format.do:L119-L119`. Next: `block:04f0c30c5e88a83c`.

```stata
la var year "Survey year"
```

### block:04f0c30c5e88a83c

Evidence: `01.Programs/archive/02-GMI format.do:L120-L120`. Next: `block:810655e9d05f1bd8`.

```stata
la var surveyid "Survey ID"
```

### block:810655e9d05f1bd8

Evidence: `01.Programs/archive/02-GMI format.do:L121-L121`. Next: `block:7d115f0f71902397`.

```stata
la var ppp "PPP years"
```

### block:7d115f0f71902397

Evidence: `01.Programs/archive/02-GMI format.do:L122-L122`. Next: `block:ffdc49c3b4387524`.

```stata
la var line "Poverty line"
```

### block:ffdc49c3b4387524

Evidence: `01.Programs/archive/02-GMI format.do:L123-L123`. Next: `block:f079dd3d67da0b63`.

```stata
la var linegroup "Poverty line groups"
```

### block:f079dd3d67da0b63

Evidence: `01.Programs/archive/02-GMI format.do:L124-L124`. Next: `block:5274065d43eafddd`.

```stata
la var data "Group level"
```

### block:5274065d43eafddd

Evidence: `01.Programs/archive/02-GMI format.do:L125-L125`. Next: `block:329361e1b74857d2`.

```stata
la var data_group "Group categories"
```

### block:329361e1b74857d2

Evidence: `01.Programs/archive/02-GMI format.do:L126-L126`. Next: `block:09f4e9199163009a`.

```stata
la var noind "Number of individuals"
```

### block:09f4e9199163009a

Evidence: `01.Programs/archive/02-GMI format.do:L128-L128`. Next: `block:15b52e74b155621f`.

```stata
la var fgt0_headcount "Poverty rate"
```

### block:15b52e74b155621f

Evidence: `01.Programs/archive/02-GMI format.do:L129-L129`. Next: `block:be42c1289f042464`.

```stata
la var fgt0_npoor "Number of poor"
```

### block:be42c1289f042464

Evidence: `01.Programs/archive/02-GMI format.do:L130-L130`. Next: `block:c4bd88e115e73068`.

```stata
la var fgt1 "Poverty gap"
```

### block:c4bd88e115e73068

Evidence: `01.Programs/archive/02-GMI format.do:L131-L131`. Next: `block:4478dede2be7d722`.

```stata
la var fgt2 "Poverty severity"
```

### block:4478dede2be7d722

Evidence: `01.Programs/archive/02-GMI format.do:L132-L132`. Next: `block:20e90a670dbd2049`.

```stata
la var sh_hh "Share of household"
```

### block:20e90a670dbd2049

Evidence: `01.Programs/archive/02-GMI format.do:L133-L133`. Next: `block:1f64497a688e4d71`.

```stata
la var sh_pop "Share of population"
```

### block:1f64497a688e4d71

Evidence: `01.Programs/archive/02-GMI format.do:L134-L134`. Next: `block:1f52688743d82918`.

```stata
la var fgt0_sharepoor "Share of poor"
```

### block:1f52688743d82918

Evidence: `01.Programs/archive/02-GMI format.do:L136-L136`. Next: `block:473fd8c8066ba00d`.

```stata
split surveyid, parse("_")
```
Read candidates: `variable:345b234b7f9aed18`

### block:473fd8c8066ba00d

Evidence: `01.Programs/archive/02-GMI format.do:L137-L137`. Next: `block:01f3b2382097972b`.

```stata
ren surveyid3 survname
```
New: `variable:e1fd5af385f580a9`
Read candidates: `variable:86d61eff4b72fc97`

### block:01f3b2382097972b

Evidence: `01.Programs/archive/02-GMI format.do:L138-L138`. Next: `block:8270f81229ec7974`.

```stata
drop surveyid1 surveyid2 surveyid4-surveyid8
```
Read candidates: `variable:fbb4263e109e18b2`, `variable:651efda24e8d10fa`, `variable:b12dac3070a7782b`, `variable:6b893abd3b630d51`

### block:8270f81229ec7974

Evidence: `01.Programs/archive/02-GMI format.do:L139-L139`. Next: `block:3ef6c2b2d2cb1b84`.

```stata
drop if code=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:7eaf02b90badee77`, `variable:e1fd5af385f580a9`

### block:3ef6c2b2d2cb1b84

Evidence: `01.Programs/archive/02-GMI format.do:L141-L141`. Next: `block:c40dc5ad6e96b942`.

```stata
merge m:1 code year survname using $pfw , keepus(rep_year ref_year survey_coverage datatype comparability link)
```
Read datasets: `dataset:0fa1cc3d12b9e4be`

### block:c40dc5ad6e96b942

Evidence: `01.Programs/archive/02-GMI format.do:L144-L144`. Next: `block:b7a39e50a3dacb1a`.

```stata
drop if code =="ISO3" & _merge ==1
```
Read candidates: `variable:7eaf02b90badee77`, `variable:1137fdd538d20093`

### block:b7a39e50a3dacb1a

Evidence: `01.Programs/archive/02-GMI format.do:L146-L146`. Next: `block:87afabb5d9a1e78d`.

```stata
drop if _merge==2
```
Read candidates: `variable:1137fdd538d20093`

### block:87afabb5d9a1e78d

Evidence: `01.Programs/archive/02-GMI format.do:L147-L147`. Next: `block:5864823f1943ee15`.

```stata
drop _merge
```
Read candidates: `variable:1137fdd538d20093`

### block:5864823f1943ee15

Evidence: `01.Programs/archive/02-GMI format.do:L149-L149`. Next: `block:5a5b2759e578b3b9`.

```stata
ren year surv_year
```
New: `variable:dfa47f67022d2515`
Read candidates: `variable:05cfbcd81a6123a5`

### block:5a5b2759e578b3b9

Evidence: `01.Programs/archive/02-GMI format.do:L150-L150`. Next: `block:11b66ddba25ec617`.

```stata
ren rep_year year
```
New: `variable:05cfbcd81a6123a5`
Read candidates: `variable:86a3d11bcfe23544`

### block:11b66ddba25ec617

Evidence: `01.Programs/archive/02-GMI format.do:L152-L152`. Next: `block:0b97d1cd01249e5f`.

```stata
drop if (data=="Gender"|data=="HH head gender") & data_group=="9"
```
Read candidates: `variable:efe30c22f0cabbc2`, `variable:9c53aa7b8363c5eb`

### block:0b97d1cd01249e5f

Evidence: `01.Programs/archive/02-GMI format.do:L154-L154`. Next: `block:1b487d97887f5b19`.

```stata
order code year surv_year ref_year surveyid survname byvar level link survey_coverage datatype comparability ppp line data data_group
```

### block:1b487d97887f5b19

Evidence: `01.Programs/archive/02-GMI format.do:L156-L156`. Next: `block:e767c4622898fa3b`.

```stata
isid code surveyid year ppp line data data_group
```
Read candidates: `variable:7eaf02b90badee77`, `variable:345b234b7f9aed18`, `variable:05cfbcd81a6123a5`, `variable:2cfe74bf61835a06`, `variable:cccd162db92c2fc5`, `variable:efe30c22f0cabbc2`, `variable:9c53aa7b8363c5eb`

### block:e767c4622898fa3b

Evidence: `01.Programs/archive/02-GMI format.do:L158-L158`. Next: `block:104a5def4c7d0db1`.

```stata
compress
```

### block:104a5def4c7d0db1

Evidence: `01.Programs/archive/02-GMI format.do:L160-L160`. Next: `block:eda256994f2ad6d9`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_pov_groups_level", replace
```
Write datasets: `dataset:b5d2f995b9f23f4b`

### block:eda256994f2ad6d9

Evidence: `01.Programs/archive/02-GMI format.do:L161-L161`. Next: `block:6f7d9cd110a16a93`.

```stata
save "${pea}\GMI_extended_pov_groups_level", replace
```
Write datasets: `dataset:592f8366d2ea5de6`

### block:6f7d9cd110a16a93

Evidence: `01.Programs/archive/02-GMI format.do:L163-L163`. Next: `block:1927dfd7b2af3475`.

```stata
use `data1', clear
```
Read datasets: `dataset:5a2ef51d43dd56ca`

### block:1927dfd7b2af3475

Evidence: `01.Programs/archive/02-GMI format.do:L164-L164`. Next: `block:fce578af2c5e74f6`.

```stata
keep code surveyid year mean2017 mean2021 prosgap2017 prosgap2021 data data_group byvar level
```
Read candidates: `variable:4d1b5b287b5f986a`, `variable:5ac8112ee7d3aa36`, `variable:89e920749b4ec42d`, `variable:3b709af1f3d34632`, `variable:a664368569073177`, `variable:06512923725b45fe`, `variable:074a4b41884dbda6`, `variable:1db60a1f62193f5c`, `variable:877217c32e606f18`, `variable:fcc117c1da914371`, `variable:b8ca165ead8cc3dd`

### block:fce578af2c5e74f6

Evidence: `01.Programs/archive/02-GMI format.do:L165-L165`. Next: `block:f66c2656dccbfd74`.

```stata
reshape long mean prosgap, i(code surveyid year data data_group byvar level)  j(ppp)
```
Read candidates: `variable:e5949367322c0dae`, `variable:4d1b5b287b5f986a`, `variable:5ac8112ee7d3aa36`, `variable:89e920749b4ec42d`, `variable:1db60a1f62193f5c`, `variable:877217c32e606f18`, `variable:fcc117c1da914371`, `variable:b8ca165ead8cc3dd`, `variable:f69e993a08166fca`

### block:f66c2656dccbfd74

Evidence: `01.Programs/archive/02-GMI format.do:L166-L166`. Next: `block:2768f2669387f2f5`.

```stata
merge m:1 code surveyid year data data_group byvar level using `data1', keepus(nohh count noind* gini theil totalhh totalind* sh_hh sh_pop*)
```
Read datasets: `dataset:5a2ef51d43dd56ca`

### block:2768f2669387f2f5

Evidence: `01.Programs/archive/02-GMI format.do:L167-L167`. Next: `block:2416d0fe473ae74f`.

```stata
drop _merge
```
Read candidates: `variable:4b0ee0aabace0cb1`

### block:2416d0fe473ae74f

Evidence: `01.Programs/archive/02-GMI format.do:L169-L169`. Next: `block:c846c841e4747a87`.

```stata
sort code surveyid year ppp data data_group
```

### block:c846c841e4747a87

Evidence: `01.Programs/archive/02-GMI format.do:L172-L172`. Next: `block:4b87ac70f120e8e8`.

```stata
replace sh_pop = sh_pop15p if byvar=="_educat"
```
Modified: `variable:0c55658cc1b53a70`
Read candidates: `variable:0b048b706a10ffcd`, `variable:fcc117c1da914371`

### block:4b87ac70f120e8e8

Evidence: `01.Programs/archive/02-GMI format.do:L173-L173`. Next: `block:ed48e0effe3b5f83`.

```stata
replace sh_pop = sh_pop1564 if byvar=="_lstatus"|byvar=="_lstatus2"
```
Modified: `variable:0c55658cc1b53a70`
Read candidates: `variable:a5a25ad52900ac3c`, `variable:fcc117c1da914371`

### block:ed48e0effe3b5f83

Evidence: `01.Programs/archive/02-GMI format.do:L175-L175`. Next: `block:096fdd6292604bcc`.

```stata
la var code "Country code"
```

### block:096fdd6292604bcc

Evidence: `01.Programs/archive/02-GMI format.do:L176-L176`. Next: `block:dd08f5b0e5fa5fbd`.

```stata
la var year "Survey year"
```

### block:dd08f5b0e5fa5fbd

Evidence: `01.Programs/archive/02-GMI format.do:L177-L177`. Next: `block:1b40ed55abbd1266`.

```stata
la var surveyid "Survey ID"
```

### block:1b40ed55abbd1266

Evidence: `01.Programs/archive/02-GMI format.do:L178-L178`. Next: `block:0eb3bc1772f244fe`.

```stata
la var ppp "PPP years"
```

### block:0eb3bc1772f244fe

Evidence: `01.Programs/archive/02-GMI format.do:L179-L179`. Next: `block:19edab14865f6f1f`.

```stata
la var data "Group level"
```

### block:19edab14865f6f1f

Evidence: `01.Programs/archive/02-GMI format.do:L180-L180`. Next: `block:246fd07067d3838d`.

```stata
la var data_group "Group categories"
```

### block:246fd07067d3838d

Evidence: `01.Programs/archive/02-GMI format.do:L181-L181`. Next: `block:15e97abdb64b9c68`.

```stata
la var noind "Number of individuals"
```

### block:15e97abdb64b9c68

Evidence: `01.Programs/archive/02-GMI format.do:L182-L182`. Next: `block:299db16e798517d4`.

```stata
la var sh_hh "Share of household"
```

### block:299db16e798517d4

Evidence: `01.Programs/archive/02-GMI format.do:L183-L183`. Next: `block:50a23e4f42203f6e`.

```stata
la var sh_pop "Share of population"
```

### block:50a23e4f42203f6e

Evidence: `01.Programs/archive/02-GMI format.do:L184-L184`. Next: `block:4b4474bd61f6a579`.

```stata
la var mean "Mean of welfare"
```

### block:4b4474bd61f6a579

Evidence: `01.Programs/archive/02-GMI format.do:L185-L185`. Next: `block:c7f5f073b7f24ff7`.

```stata
la var prosgap "Prosperity gap"
```

### block:c7f5f073b7f24ff7

Evidence: `01.Programs/archive/02-GMI format.do:L186-L186`. Next: `block:c0f6bbc492d3d0f5`.

```stata
la var totalhh "Number of total households"
```

### block:c0f6bbc492d3d0f5

Evidence: `01.Programs/archive/02-GMI format.do:L187-L187`. Next: `block:d534e06adaf22055`.

```stata
la var totalind "Number of total individuals"
```

### block:d534e06adaf22055

Evidence: `01.Programs/archive/02-GMI format.do:L189-L189`. Next: `block:041f6c44aec4e31c`.

```stata
split surveyid, parse("_")
```
Read candidates: `variable:5ac8112ee7d3aa36`

### block:041f6c44aec4e31c

Evidence: `01.Programs/archive/02-GMI format.do:L190-L190`. Next: `block:ad481b74dcaf1576`.

```stata
ren surveyid3 survname
```
New: `variable:e3d58105602f771d`
Read candidates: `variable:ca6cd0ba17799721`

### block:ad481b74dcaf1576

Evidence: `01.Programs/archive/02-GMI format.do:L191-L191`. Next: `block:b5cb96621af90fda`.

```stata
drop surveyid1 surveyid2 surveyid4-surveyid8
```
Read candidates: `variable:02393081f0731028`, `variable:8fed9d328621025f`, `variable:3d5306ca26f7c333`, `variable:83bdda3e0a921b89`

### block:b5cb96621af90fda

Evidence: `01.Programs/archive/02-GMI format.do:L192-L192`. Next: `block:ab1007b7fb67ab07`.

```stata
drop if code=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:4d1b5b287b5f986a`, `variable:e3d58105602f771d`

### block:ab1007b7fb67ab07

Evidence: `01.Programs/archive/02-GMI format.do:L193-L193`. Next: `block:8a63d7be2c10aefc`.

```stata
merge m:1 code year survname using $pfw , keepus(rep_year ref_year survey_coverage datatype comparability link)
```
Read datasets: `dataset:0fa1cc3d12b9e4be`

### block:8a63d7be2c10aefc

Evidence: `01.Programs/archive/02-GMI format.do:L195-L195`. Next: `block:eb92272dc31d4e07`.

```stata
drop if _merge==2
```
Read candidates: `variable:4b0ee0aabace0cb1`

### block:eb92272dc31d4e07

Evidence: `01.Programs/archive/02-GMI format.do:L196-L196`. Next: `block:998da055c2c7d084`.

```stata
drop _merge
```
Read candidates: `variable:4b0ee0aabace0cb1`

### block:998da055c2c7d084

Evidence: `01.Programs/archive/02-GMI format.do:L197-L197`. Next: `block:6910e14a22d8bfa7`.

```stata
order code rep_year year surveyid survname byvar level link survey_coverage datatype comparability ppp  data data_group
```

### block:6910e14a22d8bfa7

Evidence: `01.Programs/archive/02-GMI format.do:L198-L198`. Next: `block:cb6e439b81be6efd`.

```stata
ren year surv_year
```
New: `variable:05a1f31444441ee0`
Read candidates: `variable:89e920749b4ec42d`

### block:cb6e439b81be6efd

Evidence: `01.Programs/archive/02-GMI format.do:L199-L199`. Next: `block:f3b8777c99d990d3`.

```stata
ren rep_year year
```
New: `variable:89e920749b4ec42d`
Read candidates: `variable:c7bbad7540b4db92`

### block:f3b8777c99d990d3

Evidence: `01.Programs/archive/02-GMI format.do:L200-L200`. Next: `block:09804a5946b56714`.

```stata
drop if (data=="Gender"|data=="HH head gender") & data_group=="9"
```
Read candidates: `variable:1db60a1f62193f5c`, `variable:877217c32e606f18`

### block:09804a5946b56714

Evidence: `01.Programs/archive/02-GMI format.do:L201-L201`. Next: `block:40f70f225abf7310`.

```stata
compress
```

### block:40f70f225abf7310

Evidence: `01.Programs/archive/02-GMI format.do:L202-L202`. Next: `block:c25fda0a9eb26316`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_inds_groups", replace
```
Write datasets: `dataset:bec648ab4c935c18`

### block:c25fda0a9eb26316

Evidence: `01.Programs/archive/02-GMI format.do:L203-L203`. Next: `block:3a18015572c7cded`.

```stata
save "${pea}\GMI_extended_inds_groups", replace
```
Write datasets: `dataset:6ab232376b9e6e8a`

### block:3a18015572c7cded

Evidence: `01.Programs/archive/02-GMI format.do:L205-L205`. Next: `block:fd819470d429b0a8`.

```stata
use `data1', clear
```
Read datasets: `dataset:5a2ef51d43dd56ca`

### block:fd819470d429b0a8

Evidence: `01.Programs/archive/02-GMI format.do:L206-L206`. Next: `block:fc9fd45d5888332b`.

```stata
ren poor* fgt0_*
```
New: `variable:c1cd2e805a905993`
Read candidates: `variable:65870545cfdac1d5`

### block:fc9fd45d5888332b

Evidence: `01.Programs/archive/02-GMI format.do:L207-L207`. Next: `block:231547d82f574916`.

```stata
ren gap1* fgt1*
```
New: `variable:6a6a6d4908b0bf41`
Read candidates: `variable:1a01f49e63a49acc`

### block:231547d82f574916

Evidence: `01.Programs/archive/02-GMI format.do:L208-L208`. Next: `block:1d96e1c011c60d0f`.

```stata
ren gap2* fgt2*
```
New: `variable:49dbfe883500657a`
Read candidates: `variable:034d0a26fff9b27b`

### block:1d96e1c011c60d0f

Evidence: `01.Programs/archive/02-GMI format.do:L210-L210`. Next: `block:67adc6bcff03b774`.

```stata
split surveyid, parse("_")
```
Read candidates: `variable:5425b0558fa3e294`

### block:67adc6bcff03b774

Evidence: `01.Programs/archive/02-GMI format.do:L211-L211`. Next: `block:40fd7248a9478295`.

```stata
ren surveyid3 survname
```
New: `variable:5e9c682efcc9a05b`
Read candidates: `variable:bd0df94258752279`

### block:40fd7248a9478295

Evidence: `01.Programs/archive/02-GMI format.do:L212-L212`. Next: `block:e137389f080cf28a`.

```stata
drop surveyid1 surveyid2 surveyid4-surveyid8
```
Read candidates: `variable:cd99fc51ecf81ef2`, `variable:e23a9f6da8150967`, `variable:939cb8ee56f70333`, `variable:0271e161ece90eba`

### block:e137389f080cf28a

Evidence: `01.Programs/archive/02-GMI format.do:L213-L213`. Next: `block:e4e98418d1ce7e8a`.

```stata
drop if code=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:f7236f0cf6e2e961`, `variable:5e9c682efcc9a05b`

### block:e4e98418d1ce7e8a

Evidence: `01.Programs/archive/02-GMI format.do:L214-L214`. Next: `block:3c6aa4628f5e60a5`.

```stata
merge m:1 code year survname using $pfw , keepus(rep_year ref_year survey_coverage datatype comparability link)
```
Read datasets: `dataset:0fa1cc3d12b9e4be`

### block:3c6aa4628f5e60a5

Evidence: `01.Programs/archive/02-GMI format.do:L216-L216`. Next: `block:c53c01b176474912`.

```stata
drop if _merge==2
```
Read candidates: `variable:cc4b4db0dec0d373`

### block:c53c01b176474912

Evidence: `01.Programs/archive/02-GMI format.do:L217-L217`. Next: `block:7e3eaa72d36a338e`.

```stata
drop _merge
```
Read candidates: `variable:cc4b4db0dec0d373`

### block:7e3eaa72d36a338e

Evidence: `01.Programs/archive/02-GMI format.do:L218-L218`. Next: `block:480fc425a9180b88`.

```stata
order code rep_year year surveyid survname byvar level link survey_coverage datatype comparability   data data_group
```

### block:480fc425a9180b88

Evidence: `01.Programs/archive/02-GMI format.do:L219-L219`. Next: `block:1817d9b4f1d9b474`.

```stata
ren year surv_year
```
New: `variable:c7c3c58828a87bb4`
Read candidates: `variable:b7439040cca6564d`

### block:1817d9b4f1d9b474

Evidence: `01.Programs/archive/02-GMI format.do:L220-L220`. Next: `block:64a51b1cee4de17f`.

```stata
ren rep_year year
```
New: `variable:b7439040cca6564d`
Read candidates: `variable:7f22cd85597a060d`

### block:64a51b1cee4de17f

Evidence: `01.Programs/archive/02-GMI format.do:L222-L222`. Next: `block:d2a1f4d43ccafc5f`.

```stata
la var code "Country code"
```

### block:d2a1f4d43ccafc5f

Evidence: `01.Programs/archive/02-GMI format.do:L223-L223`. Next: `block:61427308420e5bce`.

```stata
la var year "Survey year"
```

### block:61427308420e5bce

Evidence: `01.Programs/archive/02-GMI format.do:L224-L224`. Next: `block:83723acc5199a23c`.

```stata
la var surveyid "Survey ID"
```

### block:83723acc5199a23c

Evidence: `01.Programs/archive/02-GMI format.do:L225-L225`. Next: `block:3b5f788e99f58fac`.

```stata
la var data "Group level"
```

### block:3b5f788e99f58fac

Evidence: `01.Programs/archive/02-GMI format.do:L226-L226`. Next: `block:71ea98c325cf829a`.

```stata
la var data_group "Group categories"
```

### block:71ea98c325cf829a

Evidence: `01.Programs/archive/02-GMI format.do:L227-L227`. Next: `block:4da654f450867644`.

```stata
la var noind "Number of individuals"
```

### block:4da654f450867644

Evidence: `01.Programs/archive/02-GMI format.do:L228-L228`. Next: `block:6fab610cac7d3ef4`.

```stata
la var sh_hh "Share of household"
```

### block:6fab610cac7d3ef4

Evidence: `01.Programs/archive/02-GMI format.do:L229-L229`. Next: `block:35eaa34da5b47bc1`.

```stata
la var sh_pop "Share of population"
```

### block:35eaa34da5b47bc1

Evidence: `01.Programs/archive/02-GMI format.do:L230-L230`. Next: `block:b2c0264d4033886b`.

```stata
la var mean2017 "Mean of welfare 2017PPP"
```

### block:b2c0264d4033886b

Evidence: `01.Programs/archive/02-GMI format.do:L231-L231`. Next: `block:708c361d117648bd`.

```stata
la var mean2021 "Mean of welfare 2021PPP"
```

### block:708c361d117648bd

Evidence: `01.Programs/archive/02-GMI format.do:L232-L232`. Next: `block:17daaa52b3e24156`.

```stata
la var prosgap2017 "Prosperity gap 2017PPP"
```

### block:17daaa52b3e24156

Evidence: `01.Programs/archive/02-GMI format.do:L233-L233`. Next: `block:45ecb8b4ae544f54`.

```stata
la var prosgap2021 "Prosperity gap 2021PPP"
```

### block:45ecb8b4ae544f54

Evidence: `01.Programs/archive/02-GMI format.do:L234-L234`. Next: `block:fd272519a15ca511`.

```stata
la var totalhh "Number of total households"
```

### block:fd272519a15ca511

Evidence: `01.Programs/archive/02-GMI format.do:L235-L235`. Next: `block:2ba15f22862a7997`.

```stata
la var totalind "Number of total individuals"
```

### block:2ba15f22862a7997

Evidence: `01.Programs/archive/02-GMI format.do:L236-L236`. Next: `block:f64427288b425cad`.

```stata
drop if (data=="Gender"|data=="HH head gender") & data_group=="9"
```
Read candidates: `variable:44a8500dfaba5d7c`, `variable:336d3adcacb71190`

### block:f64427288b425cad

Evidence: `01.Programs/archive/02-GMI format.do:L238-L238`. Next: `block:44e8c5c9881846ed`.

```stata
sort code year surveyid survname   data data_group
```

### block:44e8c5c9881846ed

Evidence: `01.Programs/archive/02-GMI format.do:L239-L239`. Next: `block:fae24d826604edc4`.

```stata
compress
```

### block:fae24d826604edc4

Evidence: `01.Programs/archive/02-GMI format.do:L240-L240`. Next: `block:5da7b15dade7fa97`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_groups_wide", replace
```
Write datasets: `dataset:9595a2dd7a846432`

### block:5da7b15dade7fa97

Evidence: `01.Programs/archive/02-GMI format.do:L243-L243`. Next: `block:308e990944f093a5`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_PNP1", clear
```
Read datasets: `dataset:101da30021cb4578`

### block:308e990944f093a5

Evidence: `01.Programs/archive/02-GMI format.do:L244-L244`. Next: `block:56c0cc92c87b9063`.

```stata
replace _bygroup = 2 if _bygroup==1 & _varname=="_total"
```
Modified: `variable:7f75d55f0bde0e81`
Read candidates: `variable:7f75d55f0bde0e81`, `variable:4bfe7a95e768eaf0`

### block:56c0cc92c87b9063

Evidence: `01.Programs/archive/02-GMI format.do:L245-L245`. Next: `block:dd69b8e65d42d954`.

```stata
la def _bygroup 1 "Poor" 0 "Nonpoor" 2 "Total"
```

### block:dd69b8e65d42d954

Evidence: `01.Programs/archive/02-GMI format.do:L246-L246`. Next: `block:3571cb346faf2676`.

```stata
la val _bygroup _bygroup
```

### block:3571cb346faf2676

Evidence: `01.Programs/archive/02-GMI format.do:L248-L248`. Next: `block:db345ac903c8ac83`.

```stata
gen line1 = subinstr( _varname,"poor","",.)
```
New: `variable:e78bdb3ed509413e`
Read candidates: `variable:4bfe7a95e768eaf0`

### block:db345ac903c8ac83

Evidence: `01.Programs/archive/02-GMI format.do:L249-L249`. Next: `block:5f5bb798fafe3e08`.

```stata
gen line = line1 if line1~="_total"
```
New: `variable:3dbf393335dbc1fd`
Read candidates: `variable:e78bdb3ed509413e`

### block:5f5bb798fafe3e08

Evidence: `01.Programs/archive/02-GMI format.do:L250-L250`. Next: `block:cfbc2565b05d51f1`.

```stata
destring line, replace
```
Modified: `variable:3dbf393335dbc1fd`
Read candidates: `variable:3dbf393335dbc1fd`

### block:cfbc2565b05d51f1

Evidence: `01.Programs/archive/02-GMI format.do:L251-L251`. Next: `block:2e24203ad82436f5`.

```stata
drop line1
```
Read candidates: `variable:e78bdb3ed509413e`

### block:2e24203ad82436f5

Evidence: `01.Programs/archive/02-GMI format.do:L253-L253`. Next: `block:403056cdafbbfc31`.

```stata
gen ppp = .
```
New: `variable:75b15115ad298451`

### block:403056cdafbbfc31

Evidence: `01.Programs/archive/02-GMI format.do:L254-L254`. Next: `block:01d8b3775231ff54`.

```stata
replace ppp = 2021 if inlist(line,300, 420, 830, 450, 630, 1245, 600, 840, 1660)
```
Modified: `variable:75b15115ad298451`
Read candidates: `variable:3dbf393335dbc1fd`

### block:01d8b3775231ff54

Evidence: `01.Programs/archive/02-GMI format.do:L255-L255`. Next: `block:7ecf83f12d617ff4`.

```stata
replace ppp = 2017 if inlist(line,215, 365, 685, 322, 547, 1027, 430, 730, 1370)
```
Modified: `variable:75b15115ad298451`
Read candidates: `variable:3dbf393335dbc1fd`

### block:7ecf83f12d617ff4

Evidence: `01.Programs/archive/02-GMI format.do:L256-L256`. Next: `block:b7f32abda9a6cfb6`.

```stata
order code surveyid year mod _bygroup _varname line ppp
```

### block:b7f32abda9a6cfb6

Evidence: `01.Programs/archive/02-GMI format.do:L257-L257`. Next: `block:52920bdb74bce3bd`.

```stata
sort code surveyid year mod ppp line _varname _bygroup
```

### block:52920bdb74bce3bd

Evidence: `01.Programs/archive/02-GMI format.do:L259-L259`. Next: `block:43ce1cfd27521efb`.

```stata
la var _demo_age_hh "Age of household head (average)"
```

### block:43ce1cfd27521efb

Evidence: `01.Programs/archive/02-GMI format.do:L260-L260`. Next: `block:197ecd4f0c94dfcc`.

```stata
la var _demo_edu_hh1 "Household head's highest level of education: No education (%)"
```

### block:197ecd4f0c94dfcc

Evidence: `01.Programs/archive/02-GMI format.do:L261-L261`. Next: `block:9bc3e4fc2b2db90d`.

```stata
la var _demo_edu_hh2 "Household head's highest level of education: Primary (%)"
```

### block:9bc3e4fc2b2db90d

Evidence: `01.Programs/archive/02-GMI format.do:L262-L262`. Next: `block:137831295ddfcd51`.

```stata
la var _demo_edu_hh3 "Household head's highest level of education: Secondary (%)"
```

### block:137831295ddfcd51

Evidence: `01.Programs/archive/02-GMI format.do:L263-L263`. Next: `block:6a20c3ed647a95f9`.

```stata
la var _demo_edu_hh4 "Household head's highest level of education: Tertiary (%)"
```

### block:6a20c3ed647a95f9

Evidence: `01.Programs/archive/02-GMI format.do:L264-L264`. Next: `block:33371c37f3c25fe0`.

```stata
la var _demo_edu_hh_m "Household head's highest level of education: Missing (%)"
```

### block:33371c37f3c25fe0

Evidence: `01.Programs/archive/02-GMI format.do:L265-L265`. Next: `block:3401f13e9cb69026`.

```stata
la var _demo_male_hh "Household head is male (%)"
```

### block:3401f13e9cb69026

Evidence: `01.Programs/archive/02-GMI format.do:L266-L266`. Next: `block:590a175ee991a6ba`.

```stata
la var _married_head "Household head is married (%)"
```

### block:590a175ee991a6ba

Evidence: `01.Programs/archive/02-GMI format.do:L267-L267`. Next: `block:a48aaaf0c6ea2922`.

```stata
la var _working_head "Labor force status of household head (%) - working"
```

### block:a48aaaf0c6ea2922

Evidence: `01.Programs/archive/02-GMI format.do:L268-L268`. Next: `block:7afeb24935214052`.

```stata
la var _notworking_head "Labor force status of household head (%) - Not working (unemployed or out of labor force)"
```

### block:7afeb24935214052

Evidence: `01.Programs/archive/02-GMI format.do:L269-L269`. Next: `block:e76c22809216a16a`.

```stata
la var _misslfs_head "Labor force status of household head (%) - missing"
```

### block:e76c22809216a16a

Evidence: `01.Programs/archive/02-GMI format.do:L270-L270`. Next: `block:4ae9f04b2cbb5514`.

```stata
la var _industry_head1 "Economic sector of household head (%) - Agriculture"
```

### block:4ae9f04b2cbb5514

Evidence: `01.Programs/archive/02-GMI format.do:L271-L271`. Next: `block:cad9863f2cace879`.

```stata
la var _industry_head2 "Economic sector of household head (%) - Industry"
```

### block:cad9863f2cace879

Evidence: `01.Programs/archive/02-GMI format.do:L272-L272`. Next: `block:57d4d683eeacab5b`.

```stata
la var _industry_head3 "Economic sector of household head (%) - Services"
```

### block:57d4d683eeacab5b

Evidence: `01.Programs/archive/02-GMI format.do:L273-L273`. Next: `block:c6b8e158e54433f3`.

```stata
la var _industry_head4 "Economic sector of household head (%) - Others"
```

### block:c6b8e158e54433f3

Evidence: `01.Programs/archive/02-GMI format.do:L274-L274`. Next: `block:0a1268c1bab466d4`.

```stata
la var _industry_head_m "Economic sector of household head (%) - missing"
```

### block:0a1268c1bab466d4

Evidence: `01.Programs/archive/02-GMI format.do:L275-L275`. Next: `block:6b753db90975c1a0`.

```stata
la var _empstat_head1 "Employment status of household head (%) - Paid Employee"
```

### block:6b753db90975c1a0

Evidence: `01.Programs/archive/02-GMI format.do:L276-L276`. Next: `block:98b50c9f52af313c`.

```stata
la var _empstat_head2 "Employment status of household head (%) - Non-Paid Employee"
```

### block:98b50c9f52af313c

Evidence: `01.Programs/archive/02-GMI format.do:L277-L277`. Next: `block:444d2c334c267c39`.

```stata
la var _empstat_head3 "Employment status of household head (%) - Employer"
```

### block:444d2c334c267c39

Evidence: `01.Programs/archive/02-GMI format.do:L278-L278`. Next: `block:90c997276a253081`.

```stata
la var _empstat_head4 "Employment status of household head (%) - Self-employed"
```

### block:90c997276a253081

Evidence: `01.Programs/archive/02-GMI format.do:L279-L279`. Next: `block:e542028316fb3318`.

```stata
la var _empstat_head5 "Employment status of household head (%) - Other, workers not classifiable by status"
```

### block:e542028316fb3318

Evidence: `01.Programs/archive/02-GMI format.do:L280-L280`. Next: `block:360021b55451c14c`.

```stata
la var _empstat_head_m "Employment status of household head (%) - missing"
```

### block:360021b55451c14c

Evidence: `01.Programs/archive/02-GMI format.do:L281-L281`. Next: `block:508fb0cc7ec9eb66`.

```stata
la var imp_wat_rec "Improved access to drinking water"
```

### block:508fb0cc7ec9eb66

Evidence: `01.Programs/archive/02-GMI format.do:L282-L282`. Next: `block:39f9ac068240d131`.

```stata
la var imp_san_rec "Improved access to sanitation facilities"
```

### block:39f9ac068240d131

Evidence: `01.Programs/archive/02-GMI format.do:L283-L283`. Next: `block:5880d61eb0c19033`.

```stata
la var electricity "Access to electricity"
```

### block:5880d61eb0c19033

Evidence: `01.Programs/archive/02-GMI format.do:L284-L284`. Next: `block:9594f20536a82401`.

```stata
la var cellphone "Own mobile phone (at least one)"
```

### block:9594f20536a82401

Evidence: `01.Programs/archive/02-GMI format.do:L285-L285`. Next: `block:7c7cb523042bd38c`.

```stata
la var computer "Own computer"
```

### block:7c7cb523042bd38c

Evidence: `01.Programs/archive/02-GMI format.do:L286-L286`. Next: `block:fa6afb1af0caa46a`.

```stata
la var dep_ratio "Household dependency ratio (average)"
```

### block:fa6afb1af0caa46a

Evidence: `01.Programs/archive/02-GMI format.do:L287-L287`. Next: `block:aaf8a6ddcb63bd8d`.

```stata
la var age6t18_sh "Share of children (age 6-18) in household (%)"
```

### block:aaf8a6ddcb63bd8d

Evidence: `01.Programs/archive/02-GMI format.do:L288-L288`. Next: `block:374f8b0417e46abd`.

```stata
la var age65p_sh "Share of elderly (age 65+) in household (%)"
```

### block:374f8b0417e46abd

Evidence: `01.Programs/archive/02-GMI format.do:L289-L289`. Next: `block:27b96c6393ddabdc`.

```stata
la var age6t18_sch_ratio "Share of children age 6-18 attending school (%)"
```

### block:27b96c6393ddabdc

Evidence: `01.Programs/archive/02-GMI format.do:L290-L290`. Next: `block:38c25b53d24c4546`.

```stata
la var tv "Have TV"
```

### block:38c25b53d24c4546

Evidence: `01.Programs/archive/02-GMI format.do:L291-L291`. Next: `block:270158fb2129e8f3`.

```stata
la var car "Have car"
```

### block:270158fb2129e8f3

Evidence: `01.Programs/archive/02-GMI format.do:L292-L292`. Next: `block:39f6a679ba202180`.

```stata
la var fridge "Have fridge"
```

### block:39f6a679ba202180

Evidence: `01.Programs/archive/02-GMI format.do:L294-L294`. Next: `block:dbb6288201e75ccb`.

```stata
split surveyid, parse("_")
```
Read candidates: `variable:c654a1be1e716e86`

### block:dbb6288201e75ccb

Evidence: `01.Programs/archive/02-GMI format.do:L295-L295`. Next: `block:565c1326eea5ac8e`.

```stata
ren surveyid3 survname
```
New: `variable:e143bb23833dd0f7`
Read candidates: `variable:545103053a01a211`

### block:565c1326eea5ac8e

Evidence: `01.Programs/archive/02-GMI format.do:L296-L296`. Next: `block:245f87c83c302103`.

```stata
drop surveyid1 surveyid2 surveyid4-surveyid8
```
Read candidates: `variable:3b3aab2b3ef55d33`, `variable:a7e70b4a3cf4bc03`, `variable:88f265a6ff3a7655`, `variable:9fdf6d5c9d84d2b4`

### block:245f87c83c302103

Evidence: `01.Programs/archive/02-GMI format.do:L297-L297`. Next: `block:9d59ad7a4a518f94`.

```stata
drop if code=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:1244930a46f4e77c`, `variable:e143bb23833dd0f7`

### block:9d59ad7a4a518f94

Evidence: `01.Programs/archive/02-GMI format.do:L298-L298`. Next: `block:282d1901178cb38f`.

```stata
merge m:1 code year survname using $pfw , keepus(rep_year ref_year survey_coverage datatype comparability link)
```
Read datasets: `dataset:0fa1cc3d12b9e4be`

### block:282d1901178cb38f

Evidence: `01.Programs/archive/02-GMI format.do:L300-L300`. Next: `block:cbedd6ee7768b1cd`.

```stata
drop if _merge==2
```
Read candidates: `variable:b3846c5fab070710`

### block:cbedd6ee7768b1cd

Evidence: `01.Programs/archive/02-GMI format.do:L301-L301`. Next: `block:03838847208e3a5c`.

```stata
drop _merge
```
Read candidates: `variable:b3846c5fab070710`

### block:03838847208e3a5c

Evidence: `01.Programs/archive/02-GMI format.do:L302-L302`. Next: `block:2ea18850f7e9ab3d`.

```stata
order code rep_year year surveyid survname _bygroup _varname  link survey_coverage datatype comparability ppp line
```

### block:2ea18850f7e9ab3d

Evidence: `01.Programs/archive/02-GMI format.do:L304-L304`. Next: `block:17f4f92a8ae860cf`.

```stata
la var code "Country code"
```

### block:17f4f92a8ae860cf

Evidence: `01.Programs/archive/02-GMI format.do:L305-L305`. Next: `block:df66edd947a8fa1a`.

```stata
la var year "Survey year"
```

### block:df66edd947a8fa1a

Evidence: `01.Programs/archive/02-GMI format.do:L306-L306`. Next: `block:f6018b5b8e5666bd`.

```stata
la var surveyid "Survey ID"
```

### block:f6018b5b8e5666bd

Evidence: `01.Programs/archive/02-GMI format.do:L307-L307`. Next: `block:142e55d7634278e6`.

```stata
la var ppp "PPP years"
```

### block:142e55d7634278e6

Evidence: `01.Programs/archive/02-GMI format.do:L308-L308`. Next: `block:631af6107d0dbf01`.

```stata
la var line "Poverty lines"
```

### block:631af6107d0dbf01

Evidence: `01.Programs/archive/02-GMI format.do:L309-L309`. Next: `block:45808b09e70fc622`.

```stata
la var _bygroup "Poor/nonpoor/total"
```

### block:45808b09e70fc622

Evidence: `01.Programs/archive/02-GMI format.do:L310-L310`. Next: `block:8123c4ba74f7a0cc`.

```stata
ren year surv_year
```
New: `variable:a2029895c8aa7765`
Read candidates: `variable:cf0922bcf2c90de0`

### block:8123c4ba74f7a0cc

Evidence: `01.Programs/archive/02-GMI format.do:L311-L311`. Next: `block:886e42422e844498`.

```stata
ren rep_year year
```
New: `variable:cf0922bcf2c90de0`
Read candidates: `variable:a8d5842cfd6675da`

### block:886e42422e844498

Evidence: `01.Programs/archive/02-GMI format.do:L312-L312`. Next: `block:1ff9476b8954f90d`.

```stata
compress
```

### block:1ff9476b8954f90d

Evidence: `01.Programs/archive/02-GMI format.do:L314-L314`. Next: `block:2ef4af7b25cd163b`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_poornonpoor_groups", replace
```
Write datasets: `dataset:24f0cb3ec900f739`

### block:2ef4af7b25cd163b

Evidence: `01.Programs/archive/02-GMI format.do:L315-L315`. Next: `block:f0df8fe8e71aebc2`.

```stata
save "${pea}\GMI_extended_poornonpoor_groups", replace
```
Write datasets: `dataset:91569449211ff718`

### block:f0df8fe8e71aebc2

Evidence: `01.Programs/archive/02-GMI format.do:L319-L319`. Next: `block:c2a6f37dab2d6e8e`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_GIC.dta", clear
```
Read datasets: `dataset:97b4d1fe2fca3006`

### block:c2a6f37dab2d6e8e

Evidence: `01.Programs/archive/02-GMI format.do:L320-L320`. Next: `block:fb45eaa68a93b925`.

```stata
drop if data_group==.|data_group==.o
```
Read candidates: `variable:5f9cb8e93f8d3e5d`, `variable:ad0be610f5fcc943`

### block:fb45eaa68a93b925

Evidence: `01.Programs/archive/02-GMI format.do:L321-L321`. Next: `block:56fcf630cd65fe70`.

```stata
replace data_group= 2 if data_group==1 & data=="All sample"
```
Modified: `variable:5f9cb8e93f8d3e5d`
Read candidates: `variable:5f9cb8e93f8d3e5d`, `variable:3fb38ea91976f29f`

### block:56fcf630cd65fe70

Evidence: `01.Programs/archive/02-GMI format.do:L322-L322`. Next: `block:f67ca16c1df84271`.

```stata
la var data "Data sample"
```

### block:f67ca16c1df84271

Evidence: `01.Programs/archive/02-GMI format.do:L323-L323`. Next: `block:26486291f6e6e5e1`.

```stata
la var data_group "Data categories"
```

### block:26486291f6e6e5e1

Evidence: `01.Programs/archive/02-GMI format.do:L324-L324`. Next: `block:85044aa464028872`.

```stata
la var ppp "PPP year"
```

### block:85044aa464028872

Evidence: `01.Programs/archive/02-GMI format.do:L325-L325`. Next: `block:d7daa60741face02`.

```stata
la var welftype "Welfare type"
```

### block:d7daa60741face02

Evidence: `01.Programs/archive/02-GMI format.do:L327-L327`. Next: `block:906fd16cbbadae8b`.

```stata
merge m:1 code year welftype using `data1pfw', keepus(survname rep_year ref_year survey_coverage datatype comparability link)
```
Read datasets: `dataset:ccfc1bd3bc5a5910`

### block:906fd16cbbadae8b

Evidence: `01.Programs/archive/02-GMI format.do:L328-L328`. Next: `block:11fd61c6309a3980`.

```stata
drop if _merge==2
```
Read candidates: `variable:ac1d4ae7044ac274`

### block:11fd61c6309a3980

Evidence: `01.Programs/archive/02-GMI format.do:L329-L329`. Next: `block:880f5fcc51945086`.

```stata
drop _merge
```
Read candidates: `variable:ac1d4ae7044ac274`

### block:880f5fcc51945086

Evidence: `01.Programs/archive/02-GMI format.do:L331-L331`. Next: `block:8e0f36d951df3240`.

```stata
ren year surv_year
```
New: `variable:8a45f5c7e16ef35c`
Read candidates: `variable:e5ac718ef98b8903`

### block:8e0f36d951df3240

Evidence: `01.Programs/archive/02-GMI format.do:L332-L332`. Next: `block:e3cc2a5dc2165cfd`.

```stata
ren rep_year year
```
New: `variable:e5ac718ef98b8903`
Read candidates: `variable:da8ce05b0e89fc47`

### block:e3cc2a5dc2165cfd

Evidence: `01.Programs/archive/02-GMI format.do:L333-L333`. Next: `block:41edf5e62a32d9e8`.

```stata
drop if code=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:511084754d87dfc3`, `variable:f732199183d3cca9`

### block:41edf5e62a32d9e8

Evidence: `01.Programs/archive/02-GMI format.do:L334-L334`. Next: `block:bb82e18884f77c3c`.

```stata
order code year surv_year welftype survname    link survey_coverage datatype comparability ppp
```

### block:bb82e18884f77c3c

Evidence: `01.Programs/archive/02-GMI format.do:L335-L335`. Next: `block:eed0aeb0fc08061a`.

```stata
sort code year survname ppp data_group q100
```

### block:eed0aeb0fc08061a

Evidence: `01.Programs/archive/02-GMI format.do:L337-L337`. Next: `block:3ee0f7702389a8ec`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_GIC_fmt.dta", replace
```
Write datasets: `dataset:06d83e0b9d46c5a5`

### block:3ee0f7702389a8ec

Evidence: `01.Programs/archive/02-GMI format.do:L338-L338`. Next: `block:7b65e0bd525a12d9`.

```stata
save "${pea}\GMI_extended_GIC_fmt.dta", replace
```
Write datasets: `dataset:dc7c3223c9a9d3fe`

### block:7b65e0bd525a12d9

Evidence: `01.Programs/archive/02-GMI format.do:L340-L340`. Next: `block:30e3e081e9c4443a`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_decomp1.dta", clear
```
Read datasets: `dataset:95a0eaf4ef22f613`

### block:30e3e081e9c4443a

Evidence: `01.Programs/archive/02-GMI format.do:L341-L341`. Next: `block:b5d2a908f64bc45c`.

```stata
append using "${out}\\03.intermediate\\GMI_extended_${rnd}_decomp2.dta"
```
Read datasets: `dataset:21a89f14bf7eb45c`

### block:b5d2a908f64bc45c

Evidence: `01.Programs/archive/02-GMI format.do:L343-L343`. Next: `block:5115cff2a73bcda1`.

```stata
drop if decomp=="Shorrocks-Kolenikov"
```
Read candidates: `variable:9559066a426307d0`

### block:5115cff2a73bcda1

Evidence: `01.Programs/archive/02-GMI format.do:L344-L344`. Next: `block:9ae89117f8c3672b`.

```stata
replace value4 = . if value4==-9999
```
Modified: `variable:ffca08627a31ef43`
Read candidates: `variable:ffca08627a31ef43`

### block:9ae89117f8c3672b

Evidence: `01.Programs/archive/02-GMI format.do:L345-L345`. Next: `block:58a21b81a9ccff81`.

```stata
drop if value3==.
```
Read candidates: `variable:20c9996b7a2a0a92`

### block:58a21b81a9ccff81

Evidence: `01.Programs/archive/02-GMI format.do:L346-L346`. Next: `block:e77abb5ebc282fe9`.

```stata
la var value1 "Total change in p.p."
```

### block:e77abb5ebc282fe9

Evidence: `01.Programs/archive/02-GMI format.do:L347-L347`. Next: `block:2f392b08ef1e900d`.

```stata
la var value2 "Growth"
```

### block:2f392b08ef1e900d

Evidence: `01.Programs/archive/02-GMI format.do:L348-L348`. Next: `block:f58ce6525aaa2b1d`.

```stata
la var value3 "Redistribution"
```

### block:f58ce6525aaa2b1d

Evidence: `01.Programs/archive/02-GMI format.do:L349-L349`. Next: `block:09dcc741537f7cf3`.

```stata
la var value4 "Population shift"
```

### block:09dcc741537f7cf3

Evidence: `01.Programs/archive/02-GMI format.do:L350-L350`. Next: `block:c8ef32e04c242dd3`.

```stata
la var value5 "Interaction"
```

### block:c8ef32e04c242dd3

Evidence: `01.Programs/archive/02-GMI format.do:L352-L352`. Next: `block:e58301648826a27b`.

```stata
la var spell "Survey spells"
```

### block:e58301648826a27b

Evidence: `01.Programs/archive/02-GMI format.do:L353-L353`. Next: `block:51eca7427b17d3f9`.

```stata
la var decomp "Decomposition type"
```

### block:51eca7427b17d3f9

Evidence: `01.Programs/archive/02-GMI format.do:L354-L354`. Next: `block:c4d18d891129c2d3`.

```stata
la var welftype "Welfare type"
```

### block:c4d18d891129c2d3

Evidence: `01.Programs/archive/02-GMI format.do:L355-L355`. Next: `block:5b4a663ab98065b7`.

```stata
ren povline line
```
New: `variable:b1c97b4555f01059`
Read candidates: `variable:de4c80ff978d8bbd`

### block:5b4a663ab98065b7

Evidence: `01.Programs/archive/02-GMI format.do:L356-L356`. Next: `block:0852a0229551638e`.

```stata
la var line "Poverty line"
```

### block:0852a0229551638e

Evidence: `01.Programs/archive/02-GMI format.do:L357-L357`. Next: `block:abf2e1d852eaef6f`.

```stata
la var ppp "PPP year"
```

### block:abf2e1d852eaef6f

Evidence: `01.Programs/archive/02-GMI format.do:L359-L359`. Next: `block:9e03b0f550b347a9`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_decomp_fmt.dta", replace
```
Write datasets: `dataset:ea751d5d119be687`

### block:9e03b0f550b347a9

Evidence: `01.Programs/archive/02-GMI format.do:L360-L360`. Next: `block:4afe1a988bbe18c9`.

```stata
save "${pea}\GMI_extended_decomp_fmt.dta", replace
```
Write datasets: `dataset:966404605e9c5e00`

### block:4afe1a988bbe18c9

Evidence: `01.Programs/archive/02-GMI format.do:L363-L363`. Next: `block:2a6396b97274aad4`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_ind_labor_sub.dta" , clear
```
Read datasets: `dataset:8caab42161a45706`

### block:2a6396b97274aad4

Evidence: `01.Programs/archive/02-GMI format.do:L364-L364`. Next: `block:f8d8b74c724676d0`.

```stata
keep if byvar=="_agegr1_"|byvar=="_all_"|byvar=="_educat"|byvar=="_male_"|byvar=="_urban_"|byvar=="quintiles"
```
Read candidates: `variable:9b57051c8846bf8e`

### block:f8d8b74c724676d0

Evidence: `01.Programs/archive/02-GMI format.do:L365-L365`. Next: `block:4fb8cb94e93a0090`.

```stata
compress
```

### block:4fb8cb94e93a0090

Evidence: `01.Programs/archive/02-GMI format.do:L366-L366`. Next: `block:8c73437be83f274b`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_ind_labor.dta", replace
```
Write datasets: `dataset:17e11d81f7607ed2`

### block:8c73437be83f274b

Evidence: `01.Programs/archive/02-GMI format.do:L370-L370`. Next: `block:cfab661fe278e82d`.

```stata
replace level = trim(level)
```
Modified: `variable:475406fcc6307ff2`
Read candidates: `variable:475406fcc6307ff2`

### block:cfab661fe278e82d

Evidence: `01.Programs/archive/02-GMI format.do:L371-L371`. Next: `block:5d12a6d8662ec740`.

```stata
replace level = proper(level)
```
Modified: `variable:475406fcc6307ff2`
Read candidates: `variable:475406fcc6307ff2`

### block:5d12a6d8662ec740

Evidence: `01.Programs/archive/02-GMI format.do:L373-L373`. Next: `block:4afaeb2cc6f85e3b`.

```stata
gen data = ""
```
New: `variable:6f4c28c0a491307b`

### block:4afaeb2cc6f85e3b

Evidence: `01.Programs/archive/02-GMI format.do:L374-L374`. Next: `block:63bf96a920245555`.

```stata
replace data = "All sample" if byvar=="_all_"
```
Modified: `variable:6f4c28c0a491307b`
Read candidates: `variable:9b57051c8846bf8e`

### block:63bf96a920245555

Evidence: `01.Programs/archive/02-GMI format.do:L375-L375`. Next: `block:1152eec4357a9bb7`.

```stata
replace data = "Urban or rural" if byvar=="_urban_"
```
Modified: `variable:6f4c28c0a491307b`
Read candidates: `variable:9b57051c8846bf8e`

### block:1152eec4357a9bb7

Evidence: `01.Programs/archive/02-GMI format.do:L376-L376`. Next: `block:125600803227a5cd`.

```stata
replace data = "Gender" if byvar=="_male_"
```
Modified: `variable:6f4c28c0a491307b`
Read candidates: `variable:9b57051c8846bf8e`

### block:125600803227a5cd

Evidence: `01.Programs/archive/02-GMI format.do:L377-L377`. Next: `block:28007a8b8d0ef5e7`.

```stata
replace data = "Education" if byvar=="_educat"
```
Modified: `variable:6f4c28c0a491307b`
Read candidates: `variable:9b57051c8846bf8e`

### block:28007a8b8d0ef5e7

Evidence: `01.Programs/archive/02-GMI format.do:L378-L378`. Next: `block:f2168482af68e3b1`.

```stata
replace data = "Age groups" if byvar=="_agegr1_"
```
Modified: `variable:6f4c28c0a491307b`
Read candidates: `variable:9b57051c8846bf8e`

### block:f2168482af68e3b1

Evidence: `01.Programs/archive/02-GMI format.do:L379-L379`. Next: `block:e8f4892bf7c72b7f`.

```stata
replace data = "Quintiles" if byvar=="quintiles"
```
Modified: `variable:6f4c28c0a491307b`
Read candidates: `variable:9b57051c8846bf8e`

### block:e8f4892bf7c72b7f

Evidence: `01.Programs/archive/02-GMI format.do:L380-L380`. Next: `block:1422a61dfe1a1c83`.

```stata
drop if level=="."
```
Read candidates: `variable:475406fcc6307ff2`

### block:1422a61dfe1a1c83

Evidence: `01.Programs/archive/02-GMI format.do:L381-L381`. Next: `block:c1ed74309c566d2f`.

```stata
gen data_group = ""
```
New: `variable:9fc923e8ac1ffe18`

### block:c1ed74309c566d2f

Evidence: `01.Programs/archive/02-GMI format.do:L383-L383`. Next: `block:37adcdaae961b517`.

```stata
local byvarlist _all_ _urban_ _male_ _educat _agegr1_  quintiles
```

### block:37adcdaae961b517

Evidence: `01.Programs/archive/02-GMI format.do:L384-L384`. Next: `block:5e1f3708b7c9b120`.

```stata
foreach byvar1 of local byvarlist {
```

### block:5e1f3708b7c9b120

Evidence: `01.Programs/archive/02-GMI format.do:L385-L385`. Next: `block:11dd79b7af0dd2d3`.

```stata
replace data_group = level if byvar=="`byvar1'"
```
Enclosing controls: `foreach byvar1 of local byvarlist {`
Modified: `variable:9fc923e8ac1ffe18`
Read candidates: `variable:475406fcc6307ff2`, `variable:9b57051c8846bf8e`

### block:11dd79b7af0dd2d3

Evidence: `01.Programs/archive/02-GMI format.do:L386-L386`. Next: `block:e0fcfb78f0c85fc3`.

```stata
}
```

### block:e0fcfb78f0c85fc3

Evidence: `01.Programs/archive/02-GMI format.do:L388-L388`. Next: `block:b93938300164c165`.

```stata
replace data_group = "Urban" if byvar=="_urban_" & level=="1"| level=="1.Urban"
```
Modified: `variable:9fc923e8ac1ffe18`
Read candidates: `variable:9b57051c8846bf8e`, `variable:475406fcc6307ff2`

### block:b93938300164c165

Evidence: `01.Programs/archive/02-GMI format.do:L389-L389`. Next: `block:bb649fae6ad4e699`.

```stata
replace data_group = "Rural" if byvar=="_urban_" & level=="0"| level=="0.Rural"
```
Modified: `variable:9fc923e8ac1ffe18`
Read candidates: `variable:9b57051c8846bf8e`, `variable:475406fcc6307ff2`

### block:bb649fae6ad4e699

Evidence: `01.Programs/archive/02-GMI format.do:L391-L391`. Next: `block:c13dd689a372bcc7`.

```stata
replace data_group = "Male" if byvar=="_male_" & level=="1"| level=="1. Male"|level=="1.Male"
```
Modified: `variable:9fc923e8ac1ffe18`
Read candidates: `variable:9b57051c8846bf8e`, `variable:475406fcc6307ff2`

### block:c13dd689a372bcc7

Evidence: `01.Programs/archive/02-GMI format.do:L392-L392`. Next: `block:8b655994bd318f86`.

```stata
replace data_group = "Female" if byvar=="_male_" & level=="0"| level=="0.Female"
```
Modified: `variable:9fc923e8ac1ffe18`
Read candidates: `variable:9b57051c8846bf8e`, `variable:475406fcc6307ff2`

### block:8b655994bd318f86

Evidence: `01.Programs/archive/02-GMI format.do:L393-L393`. Next: `block:7bf2b29b21da294d`.

```stata
replace data_group = "Missing" if byvar=="_male_" & level=="."
```
Modified: `variable:9fc923e8ac1ffe18`
Read candidates: `variable:9b57051c8846bf8e`, `variable:475406fcc6307ff2`

### block:7bf2b29b21da294d

Evidence: `01.Programs/archive/02-GMI format.do:L395-L395`. Next: `block:0c6afedb8de8c91f`.

```stata
drop if (data=="Gender"|data=="HH head gender") & data_group=="9"
```
Read candidates: `variable:6f4c28c0a491307b`, `variable:9fc923e8ac1ffe18`

### block:0c6afedb8de8c91f

Evidence: `01.Programs/archive/02-GMI format.do:L397-L397`. Next: `block:edbb832c10ea079c`.

```stata
gen sample = "Individual 15-64"
```
New: `variable:b443b19c618b609e`

### block:edbb832c10ea079c

Evidence: `01.Programs/archive/02-GMI format.do:L399-L399`. Next: `block:58c903c11856465f`.

```stata
order sample code year surveyid mod byvar level data data_group nohh count noind totalhh totalind sh_hh sh_pop
```

### block:58c903c11856465f

Evidence: `01.Programs/archive/02-GMI format.do:L401-L401`. Next: `block:a203a1389ea61c4d`.

```stata
la var sample "Population sample"
```

### block:a203a1389ea61c4d

Evidence: `01.Programs/archive/02-GMI format.do:L402-L402`. Next: `block:e1d2c2d4dc27ab52`.

```stata
la var code "Country code"
```

### block:e1d2c2d4dc27ab52

Evidence: `01.Programs/archive/02-GMI format.do:L403-L403`. Next: `block:2355a28086ca11ce`.

```stata
la var year "Survey year"
```

### block:2355a28086ca11ce

Evidence: `01.Programs/archive/02-GMI format.do:L404-L404`. Next: `block:b85de313bbf779ad`.

```stata
la var surveyid "Survey ID"
```

### block:b85de313bbf779ad

Evidence: `01.Programs/archive/02-GMI format.do:L405-L405`. Next: `block:bfc80701eee4a582`.

```stata
la var mod "Module"
```

### block:bfc80701eee4a582

Evidence: `01.Programs/archive/02-GMI format.do:L406-L406`. Next: `block:57ff7d8cfaa97da5`.

```stata
la var byvar "Subgroup variable"
```

### block:57ff7d8cfaa97da5

Evidence: `01.Programs/archive/02-GMI format.do:L407-L407`. Next: `block:831fbcd77764263d`.

```stata
la var level "Subgroup categories"
```

### block:831fbcd77764263d

Evidence: `01.Programs/archive/02-GMI format.do:L408-L408`. Next: `block:3ffb609a3b027588`.

```stata
la var data "Group level"
```

### block:3ffb609a3b027588

Evidence: `01.Programs/archive/02-GMI format.do:L409-L409`. Next: `block:36ba0423163c5f2a`.

```stata
la var data_group "Group categories"
```

### block:36ba0423163c5f2a

Evidence: `01.Programs/archive/02-GMI format.do:L410-L410`. Next: `block:c5f9e563bc2955c8`.

```stata
la var nohh "number of households"
```

### block:c5f9e563bc2955c8

Evidence: `01.Programs/archive/02-GMI format.do:L411-L411`. Next: `block:e7db4346122d23f7`.

```stata
la var count "count"
```

### block:e7db4346122d23f7

Evidence: `01.Programs/archive/02-GMI format.do:L412-L412`. Next: `block:e9bca208dd449663`.

```stata
la var noind "Number of individuals"
```

### block:e9bca208dd449663

Evidence: `01.Programs/archive/02-GMI format.do:L413-L413`. Next: `block:ccca5cceffdc9d10`.

```stata
la var sh_hh "Share of household"
```

### block:ccca5cceffdc9d10

Evidence: `01.Programs/archive/02-GMI format.do:L414-L414`. Next: `block:a6bcefd1e656ef52`.

```stata
la var sh_pop "Share of population"
```

### block:a6bcefd1e656ef52

Evidence: `01.Programs/archive/02-GMI format.do:L415-L415`. Next: `block:5e9c79842af3c770`.

```stata
la var totalhh "Number of total households"
```

### block:5e9c79842af3c770

Evidence: `01.Programs/archive/02-GMI format.do:L416-L416`. Next: `block:66226692a8d7de3b`.

```stata
la var totalind "Number of total individuals"
```

### block:66226692a8d7de3b

Evidence: `01.Programs/archive/02-GMI format.do:L418-L418`. Next: `block:defd9f99c80f0c5a`.

```stata
la var _working_ind "Share of population (15-64) working (%)"
```

### block:defd9f99c80f0c5a

Evidence: `01.Programs/archive/02-GMI format.do:L419-L419`. Next: `block:ffaa97c142fb9dfc`.

```stata
la var _notworking_ind "Share of population (15-64) not working (%)"
```

### block:ffaa97c142fb9dfc

Evidence: `01.Programs/archive/02-GMI format.do:L420-L420`. Next: `block:ff5db24a8f047d13`.

```stata
la var _misslfs_ind "Share of population (15-64) missing lstatus (%)"
```

### block:ff5db24a8f047d13

Evidence: `01.Programs/archive/02-GMI format.do:L421-L421`. Next: `block:e4d57850e696cb74`.

```stata
la var _empstat_ind1 "Share of population (15-64) working as paid employee (%)"
```

### block:e4d57850e696cb74

Evidence: `01.Programs/archive/02-GMI format.do:L422-L422`. Next: `block:a01bb8f74a4b22ac`.

```stata
la var _empstat_ind2 "Share of population (15-64) working as Non-paid employee/family worker (%)"
```

### block:a01bb8f74a4b22ac

Evidence: `01.Programs/archive/02-GMI format.do:L423-L423`. Next: `block:e9f8d586025879cc`.

```stata
la var _empstat_ind3 "Share of population (15-64) working as employer (%)"
```

### block:e9f8d586025879cc

Evidence: `01.Programs/archive/02-GMI format.do:L424-L424`. Next: `block:3aef08f9efac8132`.

```stata
la var _empstat_ind4 "Share of population (15-64) working as self-employed (%)"
```

### block:3aef08f9efac8132

Evidence: `01.Programs/archive/02-GMI format.do:L425-L425`. Next: `block:99e43b99cd553ce2`.

```stata
la var _empstat_ind5 "Share of population (15-64) working as other not classifiable (%)"
```

### block:99e43b99cd553ce2

Evidence: `01.Programs/archive/02-GMI format.do:L426-L426`. Next: `block:3a479103180b07ec`.

```stata
la var _empstat_ind_m "Share of population (15-64) working with missing employment status (%)"
```

### block:3a479103180b07ec

Evidence: `01.Programs/archive/02-GMI format.do:L427-L427`. Next: `block:1c3cc085bfae17fd`.

```stata
la var _industry_ind1 "Share of population (15-64) working in agriculture (%)"
```

### block:1c3cc085bfae17fd

Evidence: `01.Programs/archive/02-GMI format.do:L428-L428`. Next: `block:2108eef5a51fa517`.

```stata
la var _industry_ind2 "Share of population (15-64) working in industry (%)"
```

### block:2108eef5a51fa517

Evidence: `01.Programs/archive/02-GMI format.do:L429-L429`. Next: `block:d45425daa0b96060`.

```stata
la var _industry_ind3 "Share of population (15-64) working in services (%)"
```

### block:d45425daa0b96060

Evidence: `01.Programs/archive/02-GMI format.do:L430-L430`. Next: `block:6a62f825c9f0149d`.

```stata
la var _industry_ind4 "Share of population (15-64) working in others (%)"
```

### block:6a62f825c9f0149d

Evidence: `01.Programs/archive/02-GMI format.do:L431-L431`. Next: `block:f955dcb2578e580c`.

```stata
la var _industry_nonagr_ind "Share of population (15-64) working in non-agriculture (%)"
```

### block:f955dcb2578e580c

Evidence: `01.Programs/archive/02-GMI format.do:L432-L432`. Next: `block:5f354c425159bfcc`.

```stata
la var _industry_ind_m "Share of population (15-64) working with missing industry (%)"
```

### block:5f354c425159bfcc

Evidence: `01.Programs/archive/02-GMI format.do:L434-L434`. Next: `block:73b74dcdc6f729bb`.

```stata
la var _industry10_ind1 "Share of population (15-64) working in Agriculture (%)"
```

### block:73b74dcdc6f729bb

Evidence: `01.Programs/archive/02-GMI format.do:L435-L435`. Next: `block:9c1bc6479c05e5e1`.

```stata
la var _industry10_ind2 "Share of population (15-64) working in Mining (%)"
```

### block:9c1bc6479c05e5e1

Evidence: `01.Programs/archive/02-GMI format.do:L436-L436`. Next: `block:79311ebe6faae44f`.

```stata
la var _industry10_ind3 "Share of population (15-64) working in Manufacturing (%)"
```

### block:79311ebe6faae44f

Evidence: `01.Programs/archive/02-GMI format.do:L437-L437`. Next: `block:56e415b2f3eb083d`.

```stata
la var _industry10_ind4 "Share of population (15-64) working in Public Utility Services (%)"
```

### block:56e415b2f3eb083d

Evidence: `01.Programs/archive/02-GMI format.do:L438-L438`. Next: `block:a267c6937d8e3808`.

```stata
la var _industry10_ind5 "Share of population (15-64) working in Construction (%)"
```

### block:a267c6937d8e3808

Evidence: `01.Programs/archive/02-GMI format.do:L439-L439`. Next: `block:2728108efd9f295b`.

```stata
la var _industry10_ind6 "Share of population (15-64) working in Commerce (%)"
```

### block:2728108efd9f295b

Evidence: `01.Programs/archive/02-GMI format.do:L440-L440`. Next: `block:476cee788d3ecbb9`.

```stata
la var _industry10_ind7 "Share of population (15-64) working in Transport and Communications (%)"
```

### block:476cee788d3ecbb9

Evidence: `01.Programs/archive/02-GMI format.do:L441-L441`. Next: `block:153d59d58a488035`.

```stata
la var _industry10_ind8 "Share of population (15-64) working in Financial and Business Services (%)"
```

### block:153d59d58a488035

Evidence: `01.Programs/archive/02-GMI format.do:L442-L442`. Next: `block:39535b2c564de764`.

```stata
la var _industry10_ind9 "Share of population (15-64) working in Public Administration (%)"
```

### block:39535b2c564de764

Evidence: `01.Programs/archive/02-GMI format.do:L443-L443`. Next: `block:e3f1603008456804`.

```stata
la var _industry10_ind10 "Share of population (15-64) working in Other services, unspecified (%)"
```

### block:e3f1603008456804

Evidence: `01.Programs/archive/02-GMI format.do:L444-L444`. Next: `block:eb6066932439294d`.

```stata
la var _industry10_ind_m "Share of population (15-64) working with missing industry (%)"
```

### block:eb6066932439294d

Evidence: `01.Programs/archive/02-GMI format.do:L446-L446`. Next: `block:da0e1a222f24e7a6`.

```stata
foreach ppp of global ppplist {
```

### block:da0e1a222f24e7a6

Evidence: `01.Programs/archive/02-GMI format.do:L447-L447`. Next: `block:cfe7fe36c88c7ce3`.

```stata
foreach line of global plines`ppp' {
```
Enclosing controls: `foreach ppp of global ppplist {`

### block:cfe7fe36c88c7ce3

Evidence: `01.Programs/archive/02-GMI format.do:L448-L448`. Next: `block:7749b0c738603890`.

```stata
local ln `=round(`line'/100,0.01)'
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:7749b0c738603890

Evidence: `01.Programs/archive/02-GMI format.do:L449-L449`. Next: `block:fd2a72dccb9c26b3`.

```stata
local ln: display %4.2f `ln'
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:fd2a72dccb9c26b3

Evidence: `01.Programs/archive/02-GMI format.do:L450-L450`. Next: `block:dc3f4b3b05e492b8`.

```stata
local ln `=trim("`ln'")'
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:dc3f4b3b05e492b8

Evidence: `01.Programs/archive/02-GMI format.do:L451-L451`. Next: `block:258907e69da9cb05`.

```stata
la var poor`line' "Poverty rate, $`ln'/day (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:258907e69da9cb05

Evidence: `01.Programs/archive/02-GMI format.do:L452-L452`. Next: `block:7a68d25b8fd7e8ca`.

```stata
la var poor`line'_wrk "Share of poor ($`ln'/day) working (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:7a68d25b8fd7e8ca

Evidence: `01.Programs/archive/02-GMI format.do:L453-L453`. Next: `block:227257c5d41d45f8`.

```stata
la var nonpoor`line'_wrk "Share of non-poor ($`ln'/day) working (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:227257c5d41d45f8

Evidence: `01.Programs/archive/02-GMI format.do:L455-L455`. Next: `block:3746b8e4b6d0c734`.

```stata
la var poor`line'_wrkemp_1 "Share of poor ($`ln'/day) working as paid employee (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:3746b8e4b6d0c734

Evidence: `01.Programs/archive/02-GMI format.do:L456-L456`. Next: `block:112a64a3458fb01e`.

```stata
la var nonpoor`line'_wrkemp_1 "Share of non-poor ($`ln'/day) working as paid employee (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:112a64a3458fb01e

Evidence: `01.Programs/archive/02-GMI format.do:L457-L457`. Next: `block:9bd3ce02cdf8a91f`.

```stata
la var poor`line'_wrkemp_2 "Share of poor ($`ln'/day) working as non-paid employee/family worker (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:9bd3ce02cdf8a91f

Evidence: `01.Programs/archive/02-GMI format.do:L458-L458`. Next: `block:c14d3ee7db1afb59`.

```stata
la var nonpoor`line'_wrkemp_2 "Share of non-poor ($`ln'/day) working as non-paid employee/family worker (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:c14d3ee7db1afb59

Evidence: `01.Programs/archive/02-GMI format.do:L459-L459`. Next: `block:77c83fdfd9426178`.

```stata
la var poor`line'_wrkemp_3 "Share of poor ($`ln'/day) working as employer (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:77c83fdfd9426178

Evidence: `01.Programs/archive/02-GMI format.do:L460-L460`. Next: `block:c8d34c8aa8a71c2e`.

```stata
la var nonpoor`line'_wrkemp_3 "Share of non-poor ($`ln'/day) working as employer (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:c8d34c8aa8a71c2e

Evidence: `01.Programs/archive/02-GMI format.do:L461-L461`. Next: `block:1b1cac146aec44f9`.

```stata
la var poor`line'_wrkemp_4 "Share of poor ($`ln'/day) working as self-employed (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:1b1cac146aec44f9

Evidence: `01.Programs/archive/02-GMI format.do:L462-L462`. Next: `block:87f5a2a72a190364`.

```stata
la var nonpoor`line'_wrkemp_4 "Share of non-poor ($`ln'/day) working as self-employed (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:87f5a2a72a190364

Evidence: `01.Programs/archive/02-GMI format.do:L463-L463`. Next: `block:d8b12afdc9a1e4f5`.

```stata
la var poor`line'_wrkemp_5 "Share of poor ($`ln'/day) working as other not classifiable (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:d8b12afdc9a1e4f5

Evidence: `01.Programs/archive/02-GMI format.do:L464-L464`. Next: `block:64476d3f3f372b07`.

```stata
la var nonpoor`line'_wrkemp_5 "Share of non-poor ($`ln'/day) working as other not classifiable (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:64476d3f3f372b07

Evidence: `01.Programs/archive/02-GMI format.do:L466-L466`. Next: `block:8ef628787a13a95f`.

```stata
la var poor`line'_wrki4_1 "Share of poor ($`ln'/day) working in agriculture (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:8ef628787a13a95f

Evidence: `01.Programs/archive/02-GMI format.do:L467-L467`. Next: `block:34e5288383320a48`.

```stata
la var nonpoor`line'_wrki4_1 "Share of non-poor ($`ln'/day) working in agriculture (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:34e5288383320a48

Evidence: `01.Programs/archive/02-GMI format.do:L468-L468`. Next: `block:5999ee3c6384e24a`.

```stata
la var poor`line'_wrki4_2 "Share of poor ($`ln'/day) working in industry (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:5999ee3c6384e24a

Evidence: `01.Programs/archive/02-GMI format.do:L469-L469`. Next: `block:2fb476feb542ad62`.

```stata
la var nonpoor`line'_wrki4_2 "Share of non-poor ($`ln'/day) working in industry (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:2fb476feb542ad62

Evidence: `01.Programs/archive/02-GMI format.do:L470-L470`. Next: `block:23475acf8bc858f4`.

```stata
la var poor`line'_wrki4_3 "Share of poor ($`ln'/day) working in Services (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:23475acf8bc858f4

Evidence: `01.Programs/archive/02-GMI format.do:L471-L471`. Next: `block:7f23e94ea67c116b`.

```stata
la var nonpoor`line'_wrki4_3 "Share of non-poor ($`ln'/day) working in Services (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:7f23e94ea67c116b

Evidence: `01.Programs/archive/02-GMI format.do:L472-L472`. Next: `block:b7a3aa9858bad418`.

```stata
la var poor`line'_wrki4_4 "Share of poor ($`ln'/day) working in Others (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:b7a3aa9858bad418

Evidence: `01.Programs/archive/02-GMI format.do:L473-L473`. Next: `block:eff5fe7cf452f030`.

```stata
la var nonpoor`line'_wrki4_4 "Share of non-poor ($`ln'/day) working in Others (%), `ppp' PPP, population 15-64"
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`

### block:eff5fe7cf452f030

Evidence: `01.Programs/archive/02-GMI format.do:L474-L474`. Next: `block:09edaa47aa2bbe10`.

```stata
}
```
Enclosing controls: `foreach ppp of global ppplist {`

### block:09edaa47aa2bbe10

Evidence: `01.Programs/archive/02-GMI format.do:L475-L475`. Next: `block:b3111143fd43a3d7`.

```stata
}
```

### block:b3111143fd43a3d7

Evidence: `01.Programs/archive/02-GMI format.do:L476-L476`. Next: `block:366a993f90cb29b0`.

```stata
drop if count<30
```
Read candidates: `variable:dce5babeccf8a9aa`

### block:366a993f90cb29b0

Evidence: `01.Programs/archive/02-GMI format.do:L477-L477`. Next: `block:7deb1533325d1c69`.

```stata
drop lvlvar
```
Read candidates: `variable:89e617b7fdbfdb89`

### block:7deb1533325d1c69

Evidence: `01.Programs/archive/02-GMI format.do:L479-L479`. Next: `block:e56e1dc3ae5e94eb`.

```stata
split surveyid, parse("_")
```
Read candidates: `variable:9df7e16f063bb942`

### block:e56e1dc3ae5e94eb

Evidence: `01.Programs/archive/02-GMI format.do:L480-L480`. Next: `block:f4822b25e7a8eaf6`.

```stata
ren surveyid3 survname
```
New: `variable:608267ec21294692`
Read candidates: `variable:ff003c599775a1bc`

### block:f4822b25e7a8eaf6

Evidence: `01.Programs/archive/02-GMI format.do:L481-L481`. Next: `block:232a2c2d895d3cf2`.

```stata
drop surveyid1 surveyid2 surveyid4-surveyid8
```
Read candidates: `variable:1e12835deb363e8f`, `variable:b00e7e6d2e1972ed`, `variable:7ec91c6c88597b08`, `variable:bf3d4c4c5916a71b`

### block:232a2c2d895d3cf2

Evidence: `01.Programs/archive/02-GMI format.do:L482-L482`. Next: `block:3cce2d589569041b`.

```stata
drop if code=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:7bec0ad3113d5fe2`, `variable:608267ec21294692`

### block:3cce2d589569041b

Evidence: `01.Programs/archive/02-GMI format.do:L484-L484`. Next: `block:faa32189175bae5a`.

```stata
merge m:1 code year survname using $pfw , keepus(rep_year ref_year survey_coverage datatype comparability link)
```
Read datasets: `dataset:0fa1cc3d12b9e4be`

### block:faa32189175bae5a

Evidence: `01.Programs/archive/02-GMI format.do:L487-L487`. Next: `block:98b6940e2d375f1d`.

```stata
drop if code =="ISO3" & _merge==1
```
Read candidates: `variable:7bec0ad3113d5fe2`, `variable:f8cff978a4f13961`

### block:98b6940e2d375f1d

Evidence: `01.Programs/archive/02-GMI format.do:L490-L490`. Next: `block:f4821f8a39de53ec`.

```stata
drop if _merge==2
```
Read candidates: `variable:f8cff978a4f13961`

### block:f4821f8a39de53ec

Evidence: `01.Programs/archive/02-GMI format.do:L491-L491`. Next: `block:1563ecf95117e341`.

```stata
drop _merge
```
Read candidates: `variable:f8cff978a4f13961`

### block:1563ecf95117e341

Evidence: `01.Programs/archive/02-GMI format.do:L493-L493`. Next: `block:d5611a7cf2e77b98`.

```stata
ren year surv_year
```
New: `variable:520426042e1acb32`
Read candidates: `variable:8278f5ca952ad72a`

### block:d5611a7cf2e77b98

Evidence: `01.Programs/archive/02-GMI format.do:L494-L494`. Next: `block:138d174e01c99751`.

```stata
ren rep_year year
```
New: `variable:8278f5ca952ad72a`
Read candidates: `variable:6de820cd34fae650`

### block:138d174e01c99751

Evidence: `01.Programs/archive/02-GMI format.do:L496-L496`. Next: `block:d87722436de1668f`.

```stata
order sample code year surv_year surveyid survname mod byvar level data data_group  link survey_coverage datatype comparability
```

### block:d87722436de1668f

Evidence: `01.Programs/archive/02-GMI format.do:L497-L497`. Next: `block:dd70c013c2cfa811`.

```stata
sort code year survname data data_group
```

### block:dd70c013c2cfa811

Evidence: `01.Programs/archive/02-GMI format.do:L498-L498`. Next: `block:2c09849c20a8eb99`.

```stata
isid code year survname data data_group
```
Read candidates: `variable:7bec0ad3113d5fe2`, `variable:8278f5ca952ad72a`, `variable:608267ec21294692`, `variable:6f4c28c0a491307b`, `variable:9fc923e8ac1ffe18`

### block:2c09849c20a8eb99

Evidence: `01.Programs/archive/02-GMI format.do:L500-L500`. Next: `block:06a482ebf54b2fc0`.

```stata
unab allnonagr : *nonagr*
```

### block:06a482ebf54b2fc0

Evidence: `01.Programs/archive/02-GMI format.do:L501-L501`. Next: `block:0211c1216e7405c4`.

```stata
local dropvars ""
```

### block:0211c1216e7405c4

Evidence: `01.Programs/archive/02-GMI format.do:L502-L502`. Next: `block:8685fc08871bad35`.

```stata
foreach v of local allnonagr {
```

### block:8685fc08871bad35

Evidence: `01.Programs/archive/02-GMI format.do:L503-L503`. Next: `block:496ef618844968f8`.

```stata
if "`v'" != "_industry_nonagr_ind" {
```
Enclosing controls: `foreach v of local allnonagr {`

### block:496ef618844968f8

Evidence: `01.Programs/archive/02-GMI format.do:L504-L504`. Next: `block:29568ebdea93953a`.

```stata
local dropvars `dropvars' `v'
```
Enclosing controls: `foreach v of local allnonagr {` → `if "`v'" != "_industry_nonagr_ind" {`

### block:29568ebdea93953a

Evidence: `01.Programs/archive/02-GMI format.do:L505-L505`. Next: `block:5bca2cde9f0d6c58`.

```stata
}
```
Enclosing controls: `foreach v of local allnonagr {`

### block:5bca2cde9f0d6c58

Evidence: `01.Programs/archive/02-GMI format.do:L506-L506`. Next: `block:56dfdc1abb0eadbc`.

```stata
}
```

### block:56dfdc1abb0eadbc

Evidence: `01.Programs/archive/02-GMI format.do:L507-L507`. Next: `block:26b9c8ba1f2e11bd`.

```stata
di "`dropvars'"
```

### block:26b9c8ba1f2e11bd

Evidence: `01.Programs/archive/02-GMI format.do:L508-L508`. Next: `block:d036945a80f92337`.

```stata
drop `dropvars'
```

### block:d036945a80f92337

Evidence: `01.Programs/archive/02-GMI format.do:L510-L510`. Next: `block:f4de575fed10ef14`.

```stata
compress
```

### block:f4de575fed10ef14

Evidence: `01.Programs/archive/02-GMI format.do:L511-L511`. Next: `block:3e855b4d20d46b09`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_ind_labor_fmt.dta", replace
```
Write datasets: `dataset:d9df33d5f531fe5e`

### block:3e855b4d20d46b09

Evidence: `01.Programs/archive/02-GMI format.do:L512-L512`. Next: `block:8c11a08a38592627`.

```stata
save "${pea}\GMI_extended_ind_labor_fmt.dta", replace
```
Write datasets: `dataset:90017e490ed978d7`

### block:8c11a08a38592627

Evidence: `01.Programs/archive/02-GMI format.do:L514-L514`. Next: `block:1a8676905024ca69`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_ind_labor_fmt.dta", clear
```
Read datasets: `dataset:d9df33d5f531fe5e`

### block:1a8676905024ca69

Evidence: `01.Programs/archive/02-GMI format.do:L516-L516`. Next: `block:3a49462f9ac8f8f8`.

```stata
drop _industry_ind1- _industry10_ind_m
```
Read candidates: `variable:18bb709873c97b30`, `variable:547a865da568296c`

### block:3a49462f9ac8f8f8

Evidence: `01.Programs/archive/02-GMI format.do:L517-L517`. Next: `block:6b0b760edf6c8854`.

```stata
drop _working_ind- _empstat_ind_m
```
Read candidates: `variable:7b03ef48c41d8d85`, `variable:c3648e8509cdc368`

### block:6b0b760edf6c8854

Evidence: `01.Programs/archive/02-GMI format.do:L518-L518`. Next: `block:b3b9873effb03d13`.

```stata
foreach ppp of global ppplist {
```

### block:b3b9873effb03d13

Evidence: `01.Programs/archive/02-GMI format.do:L519-L519`. Next: `block:d854d10b5635396f`.

```stata
foreach line of global plines`ppp' {
```
Enclosing controls: `foreach ppp of global ppplist {`

### block:d854d10b5635396f

Evidence: `01.Programs/archive/02-GMI format.do:L520-L520`. Next: `block:ed198c1982a42ee4`.

```stata
ren *`line'* **_`line'
```
Enclosing controls: `foreach ppp of global ppplist {` → `foreach line of global plines`ppp' {`
New: `variable:3277c3702153d447`
Read candidates: `variable:939086487e6f26be`

### block:ed198c1982a42ee4

Evidence: `01.Programs/archive/02-GMI format.do:L521-L521`. Next: `block:86710299d853892b`.

```stata
}
```
Enclosing controls: `foreach ppp of global ppplist {`

### block:86710299d853892b

Evidence: `01.Programs/archive/02-GMI format.do:L522-L522`. Next: `block:4c8e8c2608c5ce43`.

```stata
}
```

### block:4c8e8c2608c5ce43

Evidence: `01.Programs/archive/02-GMI format.do:L524-L524`. Next: `block:9d8512689f880249`.

```stata
reshape long poor poor_wrk nonpoor_wrk poor_wrkemp_1 nonpoor_wrkemp_1 poor_wrkemp_2 nonpoor_wrkemp_2 poor_wrkemp_3 nonpoor_wrkemp_3 poor_wrkemp_4 nonpoor_wrkemp_4 poor_wrkemp_5 nonpoor_wrkemp_5 poor_wrki4_1 nonpoor_wrki4_1 poor_wrki4_2 nonpoor_wrki4_2 poor_wrki4_3 nonpoor_wrki4_3 poor_wrki4_4 nonpoor_wrki4_4, i(code year survname data data_group) j(line) string
```
Read candidates: `variable:add252314b827c5a`, `variable:9f04b9e9ecd1c1b3`, `variable:e4b2ab062dccffc4`, `variable:0c004e6be0ed5969`, `variable:2ceed9db22ed86ee`, `variable:f09dd198c8d9c10d`, `variable:e81ae8d804a150ea`, `variable:5f91e55b22bbf2b5`, `variable:f5219bdccd24ac56`, `variable:396e95c5995bcd40`, `variable:32ad306b99766954`, `variable:5a459ba70e2839f3`, `variable:518fc29ac5fd9bce`, `variable:e6dd290574d25f67`, `variable:4b84deea1a640c3f`, `variable:57e2ec90965bc0f0`, `variable:bce0dedfde97849a`, `variable:e533832fc967124a`, `variable:3a7dea52346e2d92`, `variable:e8e236f69fa25043`, `variable:7ab34523bccf71cd`, `variable:df0d85572a747cef`, `variable:3fa0b1aa397f348d`, `variable:e6ae5887b6dd34b3`, `variable:590cc02e2a3e559c`, `variable:2eeb9f97fb3a81a5`, `variable:fd673b5476b9c48a`, `variable:8b2e6e206382d36e`

### block:9d8512689f880249

Evidence: `01.Programs/archive/02-GMI format.do:L526-L526`. Next: `block:480076bff5087b5b`.

```stata
replace line = subinstr(line, "_","",.)
```
Modified: `variable:fd673b5476b9c48a`
Read candidates: `variable:fd673b5476b9c48a`

### block:480076bff5087b5b

Evidence: `01.Programs/archive/02-GMI format.do:L527-L527`. Next: `block:90a70c9b236eb777`.

```stata
destring line, replace
```
Modified: `variable:fd673b5476b9c48a`
Read candidates: `variable:fd673b5476b9c48a`

### block:90a70c9b236eb777

Evidence: `01.Programs/archive/02-GMI format.do:L529-L529`. Next: `block:7726d62bd6933eae`.

```stata
gen ppp = .
```
New: `variable:93a8f84dbfaa2b03`

### block:7726d62bd6933eae

Evidence: `01.Programs/archive/02-GMI format.do:L530-L530`. Next: `block:18cf80013229c1cd`.

```stata
replace ppp = 2021 if inlist(line,300, 420, 830, 450, 630, 1245, 600, 840, 1660)
```
Modified: `variable:93a8f84dbfaa2b03`
Read candidates: `variable:fd673b5476b9c48a`

### block:18cf80013229c1cd

Evidence: `01.Programs/archive/02-GMI format.do:L531-L531`. Next: `block:39503ab83ac993d9`.

```stata
replace ppp = 2017 if inlist(line,215, 365, 685, 322, 547, 1027, 430, 730, 1370)
```
Modified: `variable:93a8f84dbfaa2b03`
Read candidates: `variable:fd673b5476b9c48a`

### block:39503ab83ac993d9

Evidence: `01.Programs/archive/02-GMI format.do:L532-L532`. Next: `block:493b57b149935e07`.

```stata
sort code year survname ppp line data data_group
```

### block:493b57b149935e07

Evidence: `01.Programs/archive/02-GMI format.do:L533-L533`. Next: `block:28cc9c83a3873c26`.

```stata
order sample code year surv_year ref_year surveyid survname mod byvar level data data_group  link survey_coverage datatype comparability ppp line
```

### block:28cc9c83a3873c26

Evidence: `01.Programs/archive/02-GMI format.do:L535-L535`. Next: `block:d4cd7af01e7f6ae4`.

```stata
la var poor "Poverty rate, line/day (%),  PPP, population 15-64"
```

### block:d4cd7af01e7f6ae4

Evidence: `01.Programs/archive/02-GMI format.do:L536-L536`. Next: `block:e734d32677bfab6e`.

```stata
la var poor_wrk "Share of poor (line/day) working (%),  PPP, population 15-64"
```

### block:e734d32677bfab6e

Evidence: `01.Programs/archive/02-GMI format.do:L537-L537`. Next: `block:49c9a0fa03903341`.

```stata
la var nonpoor_wrk "Share of non-poor (line/day) working (%),  PPP, population 15-64"
```

### block:49c9a0fa03903341

Evidence: `01.Programs/archive/02-GMI format.do:L539-L539`. Next: `block:e63d930f13e21739`.

```stata
la var poor_wrkemp_1 "Share of poor (line/day) working as paid employee (%),  PPP, population 15-64"
```

### block:e63d930f13e21739

Evidence: `01.Programs/archive/02-GMI format.do:L540-L540`. Next: `block:1746749e68363acc`.

```stata
la var nonpoor_wrkemp_1 "Share of non-poor (line/day) working as paid employee (%),  PPP, population 15-64"
```

### block:1746749e68363acc

Evidence: `01.Programs/archive/02-GMI format.do:L541-L541`. Next: `block:28afd4243f2e644e`.

```stata
la var poor_wrkemp_2 "Share of poor (line/day) working as non-paid employee/family worker (%),  PPP, population 15-64"
```

### block:28afd4243f2e644e

Evidence: `01.Programs/archive/02-GMI format.do:L542-L542`. Next: `block:4ee28c19f346436b`.

```stata
la var nonpoor_wrkemp_2 "Share of non-poor (line/day) working as non-paid employee/family worker (%),  PPP, population 15-64"
```

### block:4ee28c19f346436b

Evidence: `01.Programs/archive/02-GMI format.do:L543-L543`. Next: `block:58f2baca9d0c6c04`.

```stata
la var poor_wrkemp_3 "Share of poor (line/day) working as employer (%),  PPP, population 15-64"
```

### block:58f2baca9d0c6c04

Evidence: `01.Programs/archive/02-GMI format.do:L544-L544`. Next: `block:d4156f73e3801a8d`.

```stata
la var nonpoor_wrkemp_3 "Share of non-poor (line/day) working as employer (%),  PPP, population 15-64"
```

### block:d4156f73e3801a8d

Evidence: `01.Programs/archive/02-GMI format.do:L545-L545`. Next: `block:59325ac6bc1a76f1`.

```stata
la var poor_wrkemp_4 "Share of poor (line/day) working as self-employed (%),  PPP, population 15-64"
```

### block:59325ac6bc1a76f1

Evidence: `01.Programs/archive/02-GMI format.do:L546-L546`. Next: `block:0d319676dc694da1`.

```stata
la var nonpoor_wrkemp_4 "Share of non-poor (line/day) working as self-employed (%),  PPP, population 15-64"
```

### block:0d319676dc694da1

Evidence: `01.Programs/archive/02-GMI format.do:L547-L547`. Next: `block:598e7d0f8207b4d6`.

```stata
la var poor_wrkemp_5 "Share of poor (line/day) working as other not classifiable (%),  PPP, population 15-64"
```

### block:598e7d0f8207b4d6

Evidence: `01.Programs/archive/02-GMI format.do:L548-L548`. Next: `block:9daa69cd803f0dfe`.

```stata
la var nonpoor_wrkemp_5 "Share of non-poor (line/day) working as other not classifiable (%),  PPP, population 15-64"
```

### block:9daa69cd803f0dfe

Evidence: `01.Programs/archive/02-GMI format.do:L550-L550`. Next: `block:839f00ed4dbb1419`.

```stata
la var poor_wrki4_1 "Share of poor (line/day) working in agriculture (%),  PPP, population 15-64"
```

### block:839f00ed4dbb1419

Evidence: `01.Programs/archive/02-GMI format.do:L551-L551`. Next: `block:7f086b7d877779b3`.

```stata
la var nonpoor_wrki4_1 "Share of non-poor (line/day) working in agriculture (%),  PPP, population 15-64"
```

### block:7f086b7d877779b3

Evidence: `01.Programs/archive/02-GMI format.do:L552-L552`. Next: `block:04caf9fdbe8182fc`.

```stata
la var poor_wrki4_2 "Share of poor (line/day) working in industry (%),  PPP, population 15-64"
```

### block:04caf9fdbe8182fc

Evidence: `01.Programs/archive/02-GMI format.do:L553-L553`. Next: `block:73e762f5af08f4e4`.

```stata
la var nonpoor_wrki4_2 "Share of non-poor (line/day) working in industry (%),  PPP, population 15-64"
```

### block:73e762f5af08f4e4

Evidence: `01.Programs/archive/02-GMI format.do:L554-L554`. Next: `block:4017fe6654c35132`.

```stata
la var poor_wrki4_3 "Share of poor (line/day) working in Services (%),  PPP, population 15-64"
```

### block:4017fe6654c35132

Evidence: `01.Programs/archive/02-GMI format.do:L555-L555`. Next: `block:689674adad702df9`.

```stata
la var nonpoor_wrki4_3 "Share of non-poor (line/day) working in Services (%),  PPP, population 15-64"
```

### block:689674adad702df9

Evidence: `01.Programs/archive/02-GMI format.do:L556-L556`. Next: `block:1b893bd7d9b3591b`.

```stata
la var poor_wrki4_4 "Share of poor (line/day) working in Others (%),  PPP, population 15-64"
```

### block:1b893bd7d9b3591b

Evidence: `01.Programs/archive/02-GMI format.do:L557-L557`. Next: `block:7ed515d9267005f0`.

```stata
la var nonpoor_wrki4_4 "Share of non-poor (line/day) working in Others (%),  PPP, population 15-64"
```

### block:7ed515d9267005f0

Evidence: `01.Programs/archive/02-GMI format.do:L559-L559`. Next: `block:53327fc31bcaa8c1`.

```stata
la var line "Poverty line"
```

### block:53327fc31bcaa8c1

Evidence: `01.Programs/archive/02-GMI format.do:L560-L560`. Next: `block:5c8a204ab433fd2a`.

```stata
la var ppp "PPP year"
```

### block:5c8a204ab433fd2a

Evidence: `01.Programs/archive/02-GMI format.do:L561-L561`. Next: `block:ed3f68786477f0b6`.

```stata
sort code year survname ppp line data data_group
```

### block:ed3f68786477f0b6

Evidence: `01.Programs/archive/02-GMI format.do:L562-L562`. Next: `block:277af2829fed8c16`.

```stata
compress
```

### block:277af2829fed8c16

Evidence: `01.Programs/archive/02-GMI format.do:L563-L563`. Next: `block:575318a0530ddf8a`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_ind_labor_long_fmt.dta", replace
```
Write datasets: `dataset:759eecfcd83e04e0`

### block:575318a0530ddf8a

Evidence: `01.Programs/archive/02-GMI format.do:L564-L564`. Next: `block:df9a461fe16be799`.

```stata
save "${pea}\GMI_extended_ind_labor_long_fmt.dta", replace
```
Write datasets: `dataset:cdd28195c4b85619`

### block:df9a461fe16be799

Evidence: `01.Programs/archive/02-GMI format.do:L567-L567`. Next: `block:d2141f638d37649c`.

```stata
use "${out}\\03.intermediate\\GMI_extended_${rnd}_prosg_decomp.dta", clear
```
Read datasets: `dataset:f60ae57952f91282`

### block:d2141f638d37649c

Evidence: `01.Programs/archive/02-GMI format.do:L568-L568`. Next: `block:d95694d492bf5f13`.

```stata
drop if ch_lnprosg==.
```
Read candidates: `variable:1aa1454d998d1864`

### block:d95694d492bf5f13

Evidence: `01.Programs/archive/02-GMI format.do:L569-L569`. Next: `block:fb91e75501fb7c99`.

```stata
duplicates drop _all, force
```

### block:fb91e75501fb7c99

Evidence: `01.Programs/archive/02-GMI format.do:L570-L570`. Next: `block:8570fbe444ebcba2`.

```stata
sort code spell welftype ppp
```

### block:8570fbe444ebcba2

Evidence: `01.Programs/archive/02-GMI format.do:L571-L571`. Next: `block:1fe9146ef8ae56a2`.

```stata
keep code welftype spell ch_* ppp
```
Read candidates: `variable:4c11fc6569d60758`, `variable:ccca08405f00d30a`, `variable:b88b2e5f0b6bc39b`, `variable:e860cdd0934843f3`, `variable:33f2079f81c2e81e`

### block:1fe9146ef8ae56a2

Evidence: `01.Programs/archive/02-GMI format.do:L572-L572`. Next: `block:0b66d5f35f9abdee`.

```stata
isid code spell ppp welftype
```
Read candidates: `variable:4c11fc6569d60758`, `variable:b88b2e5f0b6bc39b`, `variable:33f2079f81c2e81e`, `variable:ccca08405f00d30a`

### block:0b66d5f35f9abdee

Evidence: `01.Programs/archive/02-GMI format.do:L573-L573`. Next: `block:184e305ad6b63565`.

```stata
order code spell ppp welftype
```

### block:184e305ad6b63565

Evidence: `01.Programs/archive/02-GMI format.do:L574-L574`. Next: `block:20f19a1587914951`.

```stata
la var ch_lnprosg "Growth in Prosperity gap"
```

### block:20f19a1587914951

Evidence: `01.Programs/archive/02-GMI format.do:L575-L575`. Next: `block:790291f5043bebf9`.

```stata
la var ch_lninq_y_ybar "Contribution of growth in inequality"
```

### block:790291f5043bebf9

Evidence: `01.Programs/archive/02-GMI format.do:L576-L576`. Next: `block:1f06a2b5ad20d791`.

```stata
la var ch_lnmean "Contribution of growth in mean"
```

### block:1f06a2b5ad20d791

Evidence: `01.Programs/archive/02-GMI format.do:L577-L577`. Next: `block:807f623759a6c29d`.

```stata
la var code "Country code"
```

### block:807f623759a6c29d

Evidence: `01.Programs/archive/02-GMI format.do:L578-L578`. Next: `block:519fe308407603b3`.

```stata
la var spell "Spell/period"
```

### block:519fe308407603b3

Evidence: `01.Programs/archive/02-GMI format.do:L579-L579`. Next: `block:a6bde2fcf65037e1`.

```stata
la var ppp "PPP"
```

### block:a6bde2fcf65037e1

Evidence: `01.Programs/archive/02-GMI format.do:L580-L580`. Next: `block:fcd01fb317d334f0`.

```stata
la var welftype "Welfare type: income or consumption"
```

### block:fcd01fb317d334f0

Evidence: `01.Programs/archive/02-GMI format.do:L581-L581`. Next: `block:4a2d333a25468034`.

```stata
compress
```

### block:4a2d333a25468034

Evidence: `01.Programs/archive/02-GMI format.do:L582-L582`. Next: `block:23691e2da865dfc8`.

```stata
saveold "${out}\\03.intermediate\\GMI_extended_${rnd}_prosg_decomp_fmt.dta", replace
```
Write datasets: `dataset:2fb7b76cc780482b`

### block:23691e2da865dfc8

Evidence: `01.Programs/archive/02-GMI format.do:L583-L583`. Next: `end`.

```stata
save "${pea}\GMI_extended_prosg_decomp_fmt.dta", replace
```
Write datasets: `dataset:50ac8b2767de2ab8`
