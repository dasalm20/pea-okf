# 01.Programs/archive/01aa-GMI extended indicators.do

Demographic subgroup poverty and poor/nonpoor profiles

Status: PARTIAL_STATIC. Every lexically active statement is indexed; complete runtime schema and macro expansion are not established.

Source snapshot: numbered source (deployment lookup: lookup/sources/GMI_extended/source_maps/archive-01aa-a16ea0.md.md)

## Execution-order blocks

### block:2d61ea2b98a04839

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L2-L2`. Next: `block:04222f540acf82aa`.

```stata
clear
```

### block:04222f540acf82aa

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L3-L3`. Next: `block:796493738ef1a38c`.

```stata
macro drop resume nobs
```

### block:796493738ef1a38c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L4-L4`. Next: `block:cff576cc2cb220bc`.

```stata
set max_memory ., permanently
```

### block:cff576cc2cb220bc

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L19-L19`. Next: `block:1f171d552533fae4`.

```stata
local resume 1
```

### block:1f171d552533fae4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L22-L22`. Next: `block:593bd39553e92406`.

```stata
cap confirm integer number `resume'
```

### block:593bd39553e92406

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L23-L23`. Next: `block:00de10e90da5a04a`.

```stata
if _rc {
```

### block:00de10e90da5a04a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L24-L24`. Next: `block:c9c576c1062a2277`.

```stata
dis as error "local resume is not a valid number: |`resume'|"
```
Enclosing controls: `if _rc {`

### block:c9c576c1062a2277

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L25-L25`. Next: `block:f121f26efd82965f`.

```stata
exit 198
```
Enclosing controls: `if _rc {`

### block:f121f26efd82965f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L26-L26`. Next: `block:ae235662c3c89f55`.

```stata
}
```

### block:ae235662c3c89f55

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L28-L28`. Next: `block:deef09a8f26a355f`.

```stata
local dataall  "D:\daylan\test\GMI\out\_tmp_dataall.dta"
```

### block:deef09a8f26a355f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L29-L29`. Next: `block:22c1299c1f6697f3`.

```stata
local dataall2 "D:\daylan\test\GMI\out\_tmp_dataall2.dta"
```

### block:22c1299c1f6697f3

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L32-L32`. Next: `block:2d58a5667828ae03`.

```stata
if `resume'==1 {
```

### block:2d58a5667828ae03

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L33-L33`. Next: `block:5fb8c13476b0bd20`.

```stata
save `"`dataall'"',  replace emptyok
```
Enclosing controls: `if `resume'==1 {`
Write datasets: `dataset:f69c1d7e2da6740d`

### block:5fb8c13476b0bd20

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L34-L34`. Next: `block:2209a0980c0e9bd2`.

```stata
save `"`dataall2'"', replace emptyok
```
Enclosing controls: `if `resume'==1 {`
Write datasets: `dataset:ac00872141ffb13c`

### block:2209a0980c0e9bd2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L35-L35`. Next: `block:174649a359d9e9fd`.

```stata
}
```

### block:174649a359d9e9fd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L38-L38`. Next: `block:0b78f786fc963f23`.

```stata
set varabbrev off
```

### block:0b78f786fc963f23

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L39-L39`. Next: `block:67b0aa538d8bdb7d`.

```stata
global rnd SM26
```

### block:67b0aa538d8bdb7d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L40-L40`. Next: `block:53aacc790860e612`.

```stata
global path \\wbgfscifs01\GTSD\03.projects_corp\04.GPWG\04.GPWG_${rnd}\04.GPWG_${rnd}_QA
```

### block:53aacc790860e612

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L41-L41`. Next: `block:abdaa47842a352a8`.

```stata
global reposource "${path}\01.programs\02.dofile\repo\"
```

### block:abdaa47842a352a8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L42-L42`. Next: `block:3f8f5e3db9de05df`.

```stata
global out D:\daylan\test\GMI\out\
```

### block:3f8f5e3db9de05df

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L44-L44`. Next: `block:40564ef9ffa52171`.

```stata
global ppplist 2017 2021
```

### block:40564ef9ffa52171

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L45-L45`. Next: `block:d4cb7a494700581b`.

```stata
global pppmax 2021
```

### block:d4cb7a494700581b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L47-L47`. Next: `block:1a9526623cf5b5ea`.

```stata
global floor2021 0.28
```

### block:1a9526623cf5b5ea

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L48-L48`. Next: `block:927509f38aa2fe00`.

```stata
global gap2021 28
```

### block:927509f38aa2fe00

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L49-L49`. Next: `block:5a2e291941b809f0`.

```stata
global floor2017 0.25
```

### block:5a2e291941b809f0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L50-L50`. Next: `block:034a60bc1849ac63`.

```stata
global gap2017 25
```

### block:034a60bc1849ac63

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L51-L51`. Next: `block:58857314ec133fea`.

```stata
global floor2011 0.22
```

### block:58857314ec133fea

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L52-L52`. Next: `block:e06f28a7fffc9f10`.

```stata
global gap2011 22
```

### block:e06f28a7fffc9f10

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L54-L54`. Next: `block:4e987572f538fd6a`.

```stata
global plines2021 300 420 830 450 630 1245 600 840 1660
```

### block:4e987572f538fd6a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L55-L55`. Next: `block:9ada333e56866c32`.

```stata
global plines2017 215 365 685 322 547 1027 430 730 1370
```

### block:9ada333e56866c32

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L56-L56`. Next: `block:5afcc7f145d74a79`.

```stata
global plines2011 190 320 550
```

### block:5afcc7f145d74a79

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L57-L57`. Next: `block:8c1265192d5dafb9`.

```stata
global cpiversion Support_2005_CPI_V15_M
```

### block:8c1265192d5dafb9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L60-L60`. Next: `block:46f1abf3f7755d9d`.

```stata
global pfw "D:\daylan\test\GMI\Survey_price_framework.dta"
```

### block:46f1abf3f7755d9d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L61-L61`. Next: `block:2419bb07674e57a8`.

```stata
global repotxt repo(use ${rnd}all) reporoot(${reposource})
```

### block:2419bb07674e57a8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L64-L64`. Next: `block:0286ce0283652e24`.

```stata
tempfile data1
```

### block:0286ce0283652e24

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L65-L65`. Next: `block:34c178d655b61d39`.

```stata
use \\wbgfscifs01\GTSD\03.projects_corp\04.GPWG\04.GPWG_${rnd}\04.GPWG_${rnd}_QA\01.programs\02.dofile\repo\repo_${rnd}all.dta , clear
```
Read datasets: `dataset:96215c3f23c334b3`

### block:34c178d655b61d39

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L66-L66`. Next: `block:5787198d731b5dae`.

```stata
gen year = years
```
New: `variable:5b3ce8bd315dff2e`
Read candidates: `variable:dd270916b6693766`

### block:5787198d731b5dae

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L67-L67`. Next: `block:26fba0144f790e4a`.

```stata
destring year, replace
```
Modified: `variable:5b3ce8bd315dff2e`
Read candidates: `variable:5b3ce8bd315dff2e`

### block:26fba0144f790e4a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L69-L69`. Next: `block:3832e9cfde848dec`.

```stata
drop if module=="ASPIRE" | module=="L"|module=="GROUP"
```
Read candidates: `variable:10fdf9301f112046`

### block:3832e9cfde848dec

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L71-L71`. Next: `block:65bde072be653caf`.

```stata
drop if survname=="EU-SILC" & module=="BIN"
```
Read candidates: `variable:b7ec9bffa32b097c`, `variable:10fdf9301f112046`

### block:65bde072be653caf

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L72-L72`. Next: `block:0492a28537cf0dad`.

```stata
drop if country=="ISO3"
```
Read candidates: `variable:2c4bd8c881923a38`

### block:0492a28537cf0dad

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L74-L74`. Next: `block:d26a06e2613559b3`.

```stata
drop if country=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:2c4bd8c881923a38`, `variable:b7ec9bffa32b097c`

### block:d26a06e2613559b3

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L75-L75`. Next: `block:9ee63338a8c7590c`.

```stata
drop if country=="ISO3" & survname=="EU-SILC"
```
Read candidates: `variable:2c4bd8c881923a38`, `variable:b7ec9bffa32b097c`

### block:9ee63338a8c7590c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L76-L76`. Next: `block:90c946d3cf6f2798`.

```stata
drop if country=="ISO3" & survname=="PNAD" & year>=0000 & year<=0000
```
Read candidates: `variable:2c4bd8c881923a38`, `variable:b7ec9bffa32b097c`, `variable:5b3ce8bd315dff2e`

### block:90c946d3cf6f2798

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L78-L78`. Next: `block:2637fc5a592a2a8b`.

```stata
drop if country=="ISO3" & survname=="EPH" & year==0000
```
Read candidates: `variable:2c4bd8c881923a38`, `variable:b7ec9bffa32b097c`, `variable:5b3ce8bd315dff2e`

### block:2637fc5a592a2a8b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L79-L79`. Next: `block:cdbaf1e25d1b8281`.

```stata
drop if country=="ISO3" & survname=="NSS-SCH1" & year==0000
```
Read candidates: `variable:2c4bd8c881923a38`, `variable:b7ec9bffa32b097c`, `variable:5b3ce8bd315dff2e`

### block:cdbaf1e25d1b8281

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L82-L82`. Next: `block:8a2aa3a80d411d15`.

```stata
drop if country=="ISO3" & survname=="HNAP" & year==0000
```
Read candidates: `variable:2c4bd8c881923a38`, `variable:b7ec9bffa32b097c`, `variable:5b3ce8bd315dff2e`

### block:8a2aa3a80d411d15

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L87-L87`. Next: `block:1f27437c2aa64c4a`.

```stata
keep if module=="ALL"
```
Read candidates: `variable:10fdf9301f112046`

### block:1f27437c2aa64c4a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L89-L89`. Next: `block:201e442ea25e3ac3`.

```stata
local nobs = _N
```

### block:201e442ea25e3ac3

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L90-L90`. Next: `block:2fa54a925557269c`.

```stata
save `data1', replace
```
Write datasets: `dataset:8eecbaeb414f26a5`

### block:2fa54a925557269c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L102-L102`. Next: `block:15bf93205874508e`.

```stata
if `resume' > 1 {
```

### block:15bf93205874508e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L103-L103`. Next: `block:791c496d0fc6a84f`.

```stata
tempfile purgekeys
```
Enclosing controls: `if `resume' > 1 {`

### block:791c496d0fc6a84f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L104-L104`. Next: `block:8896adf7db01f221`.

```stata
use `data1', clear
```
Enclosing controls: `if `resume' > 1 {`
Read datasets: `dataset:8eecbaeb414f26a5`

### block:8896adf7db01f221

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L105-L105`. Next: `block:f876c42d8f4c8fb4`.

```stata
keep in `resume'/`=_N'
```
Enclosing controls: `if `resume' > 1 {`

### block:f876c42d8f4c8fb4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L106-L106`. Next: `block:752de365e1e5299a`.

```stata
keep country year surveyid
```
Enclosing controls: `if `resume' > 1 {`
Read candidates: `variable:f6b71f39061c4f65`, `variable:8b2ace3ef6d2aca5`, `variable:6890772f05b16b03`

### block:752de365e1e5299a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L107-L107`. Next: `block:d44a6e7f6b68a493`.

```stata
ren country code
```
Enclosing controls: `if `resume' > 1 {`
New: `variable:f369011598fbe793`
Read candidates: `variable:f6b71f39061c4f65`

### block:d44a6e7f6b68a493

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L108-L108`. Next: `block:8c503650a6f0f884`.

```stata
duplicates drop
```
Enclosing controls: `if `resume' > 1 {`

### block:8c503650a6f0f884

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L109-L109`. Next: `block:df61874b47b2d733`.

```stata
save `purgekeys', replace
```
Enclosing controls: `if `resume' > 1 {`
Write datasets: `dataset:57b143bcd58e63cd`

### block:df61874b47b2d733

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L110-L110`. Next: `block:01e2bdefd2be49df`.

```stata
noi dis in red "Resuming at index `resume': purging accumulator rows for `=_N' survey key(s)"
```
Enclosing controls: `if `resume' > 1 {`

### block:01e2bdefd2be49df

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L112-L112`. Next: `block:57ee2b7eba89f830`.

```stata
foreach acc in `"`dataall'"' `"`dataall2'"' {
```
Enclosing controls: `if `resume' > 1 {`

### block:57ee2b7eba89f830

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L113-L113`. Next: `block:ac63d4511f91d44c`.

```stata
use `acc', clear
```
Enclosing controls: `if `resume' > 1 {` → `foreach acc in `"`dataall'"' `"`dataall2'"' {`
Read datasets: `dataset:98b585f76c18e7dd`

### block:ac63d4511f91d44c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L114-L114`. Next: `block:39fd11b574fa1a3f`.

```stata
cap confirm variable surveyid
```
Enclosing controls: `if `resume' > 1 {` → `foreach acc in `"`dataall'"' `"`dataall2'"' {`

### block:39fd11b574fa1a3f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L115-L115`. Next: `block:fae805d2cc8c56f5`.

```stata
if _rc==0 {
```
Enclosing controls: `if `resume' > 1 {` → `foreach acc in `"`dataall'"' `"`dataall2'"' {`

### block:fae805d2cc8c56f5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L116-L116`. Next: `block:9614fd22d979d266`.

```stata
merge m:1 code year surveyid using `purgekeys', keep(master) nogen
```
Enclosing controls: `if `resume' > 1 {` → `foreach acc in `"`dataall'"' `"`dataall2'"' {` → `if _rc==0 {`
Read datasets: `dataset:57b143bcd58e63cd`

### block:9614fd22d979d266

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L117-L117`. Next: `block:d32126e314f89819`.

```stata
}
```
Enclosing controls: `if `resume' > 1 {` → `foreach acc in `"`dataall'"' `"`dataall2'"' {`

### block:d32126e314f89819

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L118-L118`. Next: `block:2d5b00988886183c`.

```stata
save `acc', replace
```
Enclosing controls: `if `resume' > 1 {` → `foreach acc in `"`dataall'"' `"`dataall2'"' {`
Write datasets: `dataset:98b585f76c18e7dd`

### block:2d5b00988886183c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L119-L119`. Next: `block:c8e95305e671954d`.

```stata
}
```
Enclosing controls: `if `resume' > 1 {`

### block:c8e95305e671954d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L120-L120`. Next: `block:5f0493d5ba88c0bf`.

```stata
}
```

### block:5f0493d5ba88c0bf

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L123-L123`. Next: `block:0c4d2b454e5a11cd`.

```stata
forv i=`resume'(1)`nobs' {
```

### block:0c4d2b454e5a11cd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L124-L124`. Next: `block:ba3531b462a44255`.

```stata
use `data1', clear
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`
Read datasets: `dataset:8eecbaeb414f26a5`

### block:ba3531b462a44255

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L126-L126`. Next: `block:241bd954b444f487`.

```stata
use `data1', clear
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`
Read datasets: `dataset:8eecbaeb414f26a5`

### block:241bd954b444f487

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L127-L127`. Next: `block:4352c26460c9612c`.

```stata
local code = country[`i']
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`

### block:4352c26460c9612c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L128-L128`. Next: `block:6e8fab5ed5b42d83`.

```stata
local year = year[`i']
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`

### block:6e8fab5ed5b42d83

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L129-L129`. Next: `block:d27d2004d35a9b43`.

```stata
local surveyid = surveyid[`i']
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`

### block:d27d2004d35a9b43

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L130-L130`. Next: `block:4bda009d6282c05d`.

```stata
local survname = survname[`i']
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`

### block:4bda009d6282c05d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L131-L131`. Next: `block:050f0bc4f24a914b`.

```stata
local mod = module[`i']
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`

### block:050f0bc4f24a914b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L134-L134`. Next: `block:51f12c7d2eee4474`.

```stata
cap dlw, country(`code') year(`year') type(gmd) surveyid(`survname') mod(`mod') files $repotxt
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`
Read datasets: `dataset:af0ef1cfde119cfe`

### block:51f12c7d2eee4474

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L135-L135`. Next: `block:2c9632e81e9caef1`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`

### block:2c9632e81e9caef1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L136-L136`. Next: `block:1af381a1077892e2`.

```stata
noi dis in white "`i'-`code'-`year'-`surveyid'-`lvlvar'-`mod'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:1af381a1077892e2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L139-L139`. Next: `block:224d4f73a12a7632`.

```stata
if "`mod'"=="GPWG" local wgt weight
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:224d4f73a12a7632

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L140-L140`. Next: `block:96372e3559854cf6`.

```stata
if "`mod'"=="ALL" {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:96372e3559854cf6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L141-L141`. Next: `block:b147053a35dca130`.

```stata
cap des weight_p
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `if "`mod'"=="ALL" {`

### block:b147053a35dca130

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L142-L142`. Next: `block:b320aee1c8c2c1ff`.

```stata
if _rc==0 local wgt weight_p
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `if "`mod'"=="ALL" {`

### block:b320aee1c8c2c1ff

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L143-L143`. Next: `block:b4f0365dcc9d371c`.

```stata
else local wgt weight
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `if "`mod'"=="ALL" {`

### block:b4f0365dcc9d371c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L144-L144`. Next: `block:a0bb420840217e1c`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:a0bb420840217e1c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L146-L146`. Next: `block:84f54f3f682351d8`.

```stata
qui {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:84f54f3f682351d8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L147-L147`. Next: `block:ee12cd9af86c6316`.

```stata
drop if welfare==.
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
Read candidates: `variable:00cf972495fa42e5`

### block:ee12cd9af86c6316

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L148-L148`. Next: `block:68978b6b8771ce73`.

```stata
drop if `wgt'==.
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:68978b6b8771ce73

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L151-L151`. Next: `block:09565f6df802aa6c`.

```stata
gen _all_ = "All sample"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:93f73192acf50365`

### block:09565f6df802aa6c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L152-L152`. Next: `block:537b7655819fa35f`.

```stata
gen _total = 1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:41763cea2461a7c1`

### block:537b7655819fa35f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L154-L154`. Next: `block:85ed56263b344ced`.

```stata
local urbvar
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:85ed56263b344ced

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L155-L155`. Next: `block:07d877d0caf97d94`.

```stata
cap des urban
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:07d877d0caf97d94

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L156-L156`. Next: `block:2be38e049273cbe2`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:2be38e049273cbe2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L157-L157`. Next: `block:79557b2d3448957c`.

```stata
ta urban
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`
Read candidates: `variable:1f9a50078d35c94c`

### block:79557b2d3448957c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L158-L158`. Next: `block:e85b53d35052ad40`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:e85b53d35052ad40

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L159-L159`. Next: `block:99af826d11cc1cfb`.

```stata
cap decode urban, gen(_urban_)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:08df6bc7203cc8ca`
Read candidates: `variable:1f9a50078d35c94c`

### block:99af826d11cc1cfb

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L160-L160`. Next: `block:ae0841bdfa4fd7a9`.

```stata
if _rc~=0 tostring urban, gen(_urban_)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:08df6bc7203cc8ca`
Read candidates: `variable:1f9a50078d35c94c`

### block:ae0841bdfa4fd7a9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L161-L161`. Next: `block:55c295ede26710cd`.

```stata
replace _urban_ = trim(_urban_)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:08df6bc7203cc8ca`
Read candidates: `variable:08df6bc7203cc8ca`

### block:55c295ede26710cd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L162-L162`. Next: `block:e7aa80636391019e`.

```stata
local urbvar _urban_
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`

### block:e7aa80636391019e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L163-L163`. Next: `block:7c9d07eb4cd718ff`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:7c9d07eb4cd718ff

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L164-L164`. Next: `block:31d8e244b24b78e8`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:31d8e244b24b78e8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L167-L167`. Next: `block:2a9ab3a471f1f171`.

```stata
local gendervar
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:2a9ab3a471f1f171

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L168-L168`. Next: `block:82d1fe3c976e331b`.

```stata
cap des male
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:82d1fe3c976e331b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L169-L169`. Next: `block:28f7b302292e3af5`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:28f7b302292e3af5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L170-L170`. Next: `block:499a7032660aa9f4`.

```stata
ta male
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`
Read candidates: `variable:bf393f9db08069ce`

### block:499a7032660aa9f4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L171-L171`. Next: `block:3dd5f86917c8a3f4`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:3dd5f86917c8a3f4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L172-L172`. Next: `block:081e8602ead5f80a`.

```stata
cap decode male, gen(_male_)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:b1bef60ce0ff36bf`
Read candidates: `variable:bf393f9db08069ce`

### block:081e8602ead5f80a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L173-L173`. Next: `block:74f414214eb86952`.

```stata
if _rc~=0 tostring male, gen(_male_)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:b1bef60ce0ff36bf`
Read candidates: `variable:bf393f9db08069ce`

### block:74f414214eb86952

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L174-L174`. Next: `block:fcf0041ae87326ad`.

```stata
replace _male_ = trim(_male_)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:b1bef60ce0ff36bf`
Read candidates: `variable:b1bef60ce0ff36bf`

### block:fcf0041ae87326ad

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L175-L175`. Next: `block:ac3d579fd1d84d98`.

```stata
local gendervar _male_
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`

### block:ac3d579fd1d84d98

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L176-L176`. Next: `block:c52f53b73f46c57b`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:c52f53b73f46c57b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L177-L177`. Next: `block:3da2328e73dd66ac`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:3da2328e73dd66ac

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L180-L180`. Next: `block:42922fbc7ad7a151`.

```stata
local demohead
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:42922fbc7ad7a151

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L181-L181`. Next: `block:1426879740207624`.

```stata
local agevar
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:1426879740207624

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L182-L182`. Next: `block:d83e18ba8e151207`.

```stata
cap des age
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:d83e18ba8e151207

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L183-L183`. Next: `block:a9e50045428adbce`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:a9e50045428adbce

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L185-L185`. Next: `block:0ff48dd9d87449c3`.

```stata
if "`=upper("`code'")'" == "ISO3" {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:0ff48dd9d87449c3

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L187-L187`. Next: `block:949fa1e6a2048c0c`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:949fa1e6a2048c0c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L188-L188`. Next: `block:147649c7e69c7bd2`.

```stata
else {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:147649c7e69c7bd2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L189-L189`. Next: `block:e768801dbc26bdca`.

```stata
su age
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {`
Read candidates: `variable:5863b3da7602bb54`

### block:e768801dbc26bdca

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L190-L190`. Next: `block:98a52b5238bf6850`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {`

### block:98a52b5238bf6850

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L191-L191`. Next: `block:5462df6fd1f58b36`.

```stata
gen _agegr1_ = "0-14" if age<=14
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:3bcec4240f93e47a`
Read candidates: `variable:5863b3da7602bb54`

### block:5462df6fd1f58b36

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L192-L192`. Next: `block:9f649ef1c0e3c342`.

```stata
replace _agegr1_ = "15-64" if age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
Modified: `variable:3bcec4240f93e47a`
Read candidates: `variable:5863b3da7602bb54`

### block:9f649ef1c0e3c342

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L193-L193`. Next: `block:e35930dde19b7761`.

```stata
replace _agegr1_ = "65+" if age>=65 & age<=.
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
Modified: `variable:3bcec4240f93e47a`
Read candidates: `variable:5863b3da7602bb54`

### block:e35930dde19b7761

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L195-L195`. Next: `block:3218a59e0aaf05a9`.

```stata
gen _agegr2_ = "18-34" if age>=18 & age<=34
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:79d7dc9de6a0e049`
Read candidates: `variable:5863b3da7602bb54`

### block:3218a59e0aaf05a9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L196-L196`. Next: `block:80be0289491d3459`.

```stata
replace _agegr2_ = "35-49" if age>=35 & age<=49
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
Modified: `variable:79d7dc9de6a0e049`
Read candidates: `variable:5863b3da7602bb54`

### block:80be0289491d3459

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L197-L197`. Next: `block:379150b88154e008`.

```stata
replace _agegr2_ = "50-64" if age>=50 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
Modified: `variable:79d7dc9de6a0e049`
Read candidates: `variable:5863b3da7602bb54`

### block:379150b88154e008

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L199-L199`. Next: `block:57b0fafce9034b80`.

```stata
local agevar _agegr1_
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:57b0fafce9034b80

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L202-L202`. Next: `block:825688963233ab94`.

```stata
gen age0t14 = 1 if age<=14
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:627db79481c0f921`
Read candidates: `variable:5863b3da7602bb54`

### block:825688963233ab94

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L203-L203`. Next: `block:8ee14b0e7d5401be`.

```stata
gen age65p  = 1 if age>=65 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:ddd0c9b638c0a251`
Read candidates: `variable:5863b3da7602bb54`

### block:8ee14b0e7d5401be

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L204-L204`. Next: `block:45a2eccb918a0fa4`.

```stata
gen age15t64 = 1 if age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:91617240b24049de`
Read candidates: `variable:5863b3da7602bb54`

### block:45a2eccb918a0fa4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L205-L205`. Next: `block:9a018fd072e6ed29`.

```stata
gen age6t18 = 1 if age>=6 & age<=18
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:6c33b83602c4cb81`
Read candidates: `variable:5863b3da7602bb54`

### block:9a018fd072e6ed29

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L207-L207`. Next: `block:4330111c5f5cd1a7`.

```stata
bys hhid (pid): egen age0t14sum = total(age0t14)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:290fa5178c39015f`
Read candidates: `variable:627db79481c0f921`, `variable:2d34be2f5c7100d6`

### block:4330111c5f5cd1a7

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L208-L208`. Next: `block:2fde41810a128b35`.

```stata
bys hhid (pid): egen age65psum = total(age65p)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:167899f3ec0ff6f4`
Read candidates: `variable:ddd0c9b638c0a251`, `variable:2d34be2f5c7100d6`

### block:2fde41810a128b35

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L209-L209`. Next: `block:4228b5148f7831f2`.

```stata
bys hhid (pid): egen age15t64sum = total(age15t64)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:f5600d0354c59228`
Read candidates: `variable:91617240b24049de`, `variable:2d34be2f5c7100d6`

### block:4228b5148f7831f2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L210-L210`. Next: `block:8d216cd0db9f53e2`.

```stata
bys hhid (pid): egen age6t18sum = total(age6t18)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:921d06a36f75cd1c`
Read candidates: `variable:6c33b83602c4cb81`, `variable:2d34be2f5c7100d6`

### block:8d216cd0db9f53e2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L211-L211`. Next: `block:35e44e02609b19a2`.

```stata
bys hhid (pid): gen _hhx = _N
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:c4bbf277b2c261b4`
Read candidates: `variable:2d34be2f5c7100d6`

### block:35e44e02609b19a2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L213-L213`. Next: `block:bfd4a2bc572b5718`.

```stata
egen depnum = rowtotal(age0t14sum age65psum), missing
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:a8195cc77b065cf4`
Read candidates: `variable:290fa5178c39015f`, `variable:167899f3ec0ff6f4`

### block:bfd4a2bc572b5718

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L214-L214`. Next: `block:03dc030705b2febb`.

```stata
gen dep_ratio = (depnum/age15t64sum)*100
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:f19ba8148ec7e919`
Read candidates: `variable:a8195cc77b065cf4`, `variable:f5600d0354c59228`

### block:03dc030705b2febb

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L215-L215`. Next: `block:96323704bc0b3fd2`.

```stata
gen age6t18_sh = (age6t18sum/_hhx)*100
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:1c84866853168a24`
Read candidates: `variable:921d06a36f75cd1c`, `variable:c4bbf277b2c261b4`

### block:96323704bc0b3fd2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L216-L216`. Next: `block:9a7adf607fb6eeb2`.

```stata
gen age65p_sh = (age65psum/_hhx)*100
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`
New: `variable:4f279c1621230da9`
Read candidates: `variable:167899f3ec0ff6f4`, `variable:c4bbf277b2c261b4`

### block:9a7adf607fb6eeb2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L217-L217`. Next: `block:2717e65c4ff3f2ea`.

```stata
la var dep_ratio "Household dependency ratio (average)"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:2717e65c4ff3f2ea

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L218-L218`. Next: `block:d32944a3243a3233`.

```stata
la var age6t18_sh "Share of children (age 6-18) in household (%)"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:d32944a3243a3233

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L219-L219`. Next: `block:f2e63d755a4e96d0`.

```stata
la var age65p_sh "Share of elderly (age 65+) in household (%)"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:f2e63d755a4e96d0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L220-L220`. Next: `block:8319d535f033aa49`.

```stata
local demohead dep_ratio age6t18_sh age65p_sh
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:8319d535f033aa49

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L221-L221`. Next: `block:80d1d9fdbff55625`.

```stata
local dep_ratio dep_ratio
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:80d1d9fdbff55625

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L222-L222`. Next: `block:f1ddb68c5208218e`.

```stata
local age6t18_sh age6t18_sh
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:f1ddb68c5208218e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L223-L223`. Next: `block:6b8984bc52b90186`.

```stata
local age65p_sh age65p_sh
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:6b8984bc52b90186

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L225-L225`. Next: `block:53e0cc03e61133a8`.

```stata
cap des school
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:53e0cc03e61133a8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L226-L226`. Next: `block:545f123ce59a40d0`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:545f123ce59a40d0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L227-L227`. Next: `block:829a16990710052d`.

```stata
su school,d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {`
Read candidates: `variable:ac8d91b764d0c84a`, `variable:9e4d35708ac3d23c`

### block:829a16990710052d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L228-L228`. Next: `block:7febe21986118881`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {`

### block:7febe21986118881

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L229-L229`. Next: `block:7b7316e0dcdc2312`.

```stata
gen age6t18_sch = age6t18==1 & school==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:2f4f2f0325d41317`
Read candidates: `variable:6c33b83602c4cb81`, `variable:ac8d91b764d0c84a`

### block:7b7316e0dcdc2312

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L230-L230`. Next: `block:65a370fbf97cdb1b`.

```stata
bys hhid (pid): egen age6t18schsum = total(age6t18_sch)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:5f7b9cf37dbc7c2a`
Read candidates: `variable:2f4f2f0325d41317`, `variable:2d34be2f5c7100d6`

### block:65a370fbf97cdb1b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L231-L231`. Next: `block:04ebdbbbd2f04535`.

```stata
gen age6t18_sch_ratio = (age6t18schsum/age6t18sum)*100
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:d7809d3267a6e9a3`
Read candidates: `variable:5f7b9cf37dbc7c2a`, `variable:921d06a36f75cd1c`

### block:04ebdbbbd2f04535

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L232-L232`. Next: `block:23fd41da08b9f4cb`.

```stata
local demohead "`demohead' age6t18_sch_ratio"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {` → `if r(N)>0 {`

### block:23fd41da08b9f4cb

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L233-L233`. Next: `block:dd62addc8250c0a5`.

```stata
la var age6t18_sch_ratio "Share of children age 6-18 attending school (%)"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {` → `if r(N)>0 {`

### block:dd62addc8250c0a5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L234-L234`. Next: `block:2cfc68d97eaff74b`.

```stata
local age6t18_sch_ratio age6t18_sch_ratio
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {` → `if r(N)>0 {`

### block:2cfc68d97eaff74b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L235-L235`. Next: `block:5ecd412adf4695c9`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {` → `qui if _rc==0 {`

### block:5ecd412adf4695c9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L236-L236`. Next: `block:0d60c9485daed654`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {` → `if r(N)>0 {`

### block:0d60c9485daed654

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L237-L237`. Next: `block:c7f08a61907e4c36`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `else {`

### block:c7f08a61907e4c36

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L238-L238`. Next: `block:8d8968b64d00bfcb`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:8d8968b64d00bfcb

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L239-L239`. Next: `block:76591aecb372c33d`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:76591aecb372c33d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L242-L242`. Next: `block:4fbc176bfe53ad23`.

```stata
cap replace lstatus = lstatus_year if missing(lstatus) & !missing(lstatus_year)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
Modified: `variable:069c57dd3c07cf9e`
Read candidates: `variable:b9d592c43e199e1f`, `variable:069c57dd3c07cf9e`, `variable:1dd87e08e21357e9`

### block:4fbc176bfe53ad23

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L243-L243`. Next: `block:c47b1a587953a366`.

```stata
cap replace industrycat4 = industrycat4_year if missing(industrycat4) & !missing(industrycat4_year)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
Modified: `variable:a06654e911372c06`
Read candidates: `variable:debab6b1f4865729`, `variable:a06654e911372c06`, `variable:1dd87e08e21357e9`

### block:c47b1a587953a366

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L244-L244`. Next: `block:1da51a0d0dbed01b`.

```stata
cap replace industrycat10 = industrycat10_year if missing(industrycat10) & !missing(industrycat10_year)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
Modified: `variable:0dd2943841de0dd9`
Read candidates: `variable:986ae026beee852e`, `variable:0dd2943841de0dd9`, `variable:1dd87e08e21357e9`

### block:1da51a0d0dbed01b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L245-L245`. Next: `block:b1bc89e1e7149a76`.

```stata
cap replace empstat = empstat_year if missing(empstat) & !missing(empstat_year)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
Modified: `variable:f1f4133891883bca`
Read candidates: `variable:7ef4425498219b4c`, `variable:f1f4133891883bca`, `variable:1dd87e08e21357e9`

### block:b1bc89e1e7149a76

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L248-L248`. Next: `block:80707c44843a8a02`.

```stata
local agegender
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:80707c44843a8a02

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L249-L249`. Next: `block:5ebf9a4ebd60f898`.

```stata
if "`agevar'"~="" & "`gendervar'"~="" {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:5ebf9a4ebd60f898

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L250-L250`. Next: `block:b9b2fcde2d36bc33`.

```stata
clonevar _age = age
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
New: `variable:f86b74ead0017541`
Read candidates: `variable:5863b3da7602bb54`

### block:b9b2fcde2d36bc33

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L251-L251`. Next: `block:2cbcc541e2d9500b`.

```stata
replace _age = . if _age>80 & !missing(_age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
Modified: `variable:f86b74ead0017541`
Read candidates: `variable:f86b74ead0017541`

### block:2cbcc541e2d9500b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L253-L253`. Next: `block:1227abacf2f312c4`.

```stata
egen _tmp1 = cut(_age), at(0(5)79) label
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
New: `variable:25b9e97f01dab12b`
Read candidates: `variable:f86b74ead0017541`, `variable:3bb9c3fb94401be5`

### block:1227abacf2f312c4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L254-L254`. Next: `block:c857753359ab1afa`.

```stata
decode _tmp1, gen(_agegender1)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
New: `variable:36263258d80e5c83`
Read candidates: `variable:25b9e97f01dab12b`

### block:c857753359ab1afa

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L255-L255`. Next: `block:9372a7d372365404`.

```stata
replace _agegender1 = "m_" + _agegender1 if male==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
Modified: `variable:36263258d80e5c83`
Read candidates: `variable:36263258d80e5c83`, `variable:bf393f9db08069ce`

### block:9372a7d372365404

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L256-L256`. Next: `block:9633be726b72cecd`.

```stata
replace _agegender1 = "f_" + _agegender1 if male==0
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
Modified: `variable:36263258d80e5c83`
Read candidates: `variable:36263258d80e5c83`, `variable:bf393f9db08069ce`

### block:9633be726b72cecd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L258-L258`. Next: `block:b7e1c0d7652c2fc2`.

```stata
gen _agegender2 = ""
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
New: `variable:4d2532f58999801f`

### block:b7e1c0d7652c2fc2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L259-L259`. Next: `block:fb48474765e2c2bd`.

```stata
replace _agegender2 = "m_" + _agegr1_ if male==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
Modified: `variable:4d2532f58999801f`
Read candidates: `variable:3bcec4240f93e47a`, `variable:bf393f9db08069ce`

### block:fb48474765e2c2bd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L260-L260`. Next: `block:8e6d3045ed5a2bf1`.

```stata
replace _agegender2 = "f_" + _agegr1_ if male==0
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
Modified: `variable:4d2532f58999801f`
Read candidates: `variable:3bcec4240f93e47a`, `variable:bf393f9db08069ce`

### block:8e6d3045ed5a2bf1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L261-L261`. Next: `block:75c0c65c06a68df7`.

```stata
local agegender _agegender1 _agegender2
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`

### block:75c0c65c06a68df7

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L262-L262`. Next: `block:9b6ad7fd601a091e`.

```stata
drop _tmp1 _age
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if "`agevar'"~="" & "`gendervar'"~="" {`
Read candidates: `variable:25b9e97f01dab12b`, `variable:f86b74ead0017541`

### block:9b6ad7fd601a091e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L263-L263`. Next: `block:b5b702e469902c0b`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:b5b702e469902c0b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L266-L266`. Next: `block:7cb191717ff70e79`.

```stata
local eduvar
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:7cb191717ff70e79

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L267-L267`. Next: `block:3439bea55634794e`.

```stata
cap des educat4
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:3439bea55634794e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L268-L268`. Next: `block:be48a32e6d9c13dc`.

```stata
qui if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:be48a32e6d9c13dc

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L269-L269`. Next: `block:1e574863efee227c`.

```stata
ta educat4
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`
Read candidates: `variable:6cc5cc02f6e16631`

### block:1e574863efee227c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L270-L270`. Next: `block:7579c1ac95b31f1a`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:7579c1ac95b31f1a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L271-L271`. Next: `block:e9da337560fc1c83`.

```stata
gen _educat = "No education" if educat4==1 & age>=15 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
New: `variable:23c060ac8025d975`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:5863b3da7602bb54`

### block:e9da337560fc1c83

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L272-L272`. Next: `block:428d5585e9516b8d`.

```stata
replace _educat = "Primary" if educat4==2 & age>=15 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:23c060ac8025d975`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:5863b3da7602bb54`

### block:428d5585e9516b8d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L273-L273`. Next: `block:3ca9572c14646e91`.

```stata
replace _educat = "Secondary" if educat4==3 & age>=15 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:23c060ac8025d975`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:5863b3da7602bb54`

### block:3ca9572c14646e91

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L274-L274`. Next: `block:d65b3420b0288ed1`.

```stata
replace _educat = "Tertiary" if educat4==4 & age>=15 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:23c060ac8025d975`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:5863b3da7602bb54`

### block:d65b3420b0288ed1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L275-L275`. Next: `block:ba0ffd92018f96dd`.

```stata
replace _educat = "MISSING" if missing(educat4) & age>=15 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:23c060ac8025d975`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:5863b3da7602bb54`

### block:ba0ffd92018f96dd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L276-L276`. Next: `block:662d8731d42d6b1e`.

```stata
local eduvar _educat
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {` → `if r(N)>0 {`

### block:662d8731d42d6b1e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L277-L277`. Next: `block:96e4ee5657825ca1`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `qui if _rc==0 {`

### block:96e4ee5657825ca1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L278-L278`. Next: `block:a4514a82cbf4dd56`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:a4514a82cbf4dd56

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L281-L281`. Next: `block:c0661ba248e914ce`.

```stata
local lfsvar
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:c0661ba248e914ce

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L282-L282`. Next: `block:eda3619fe18a4c8b`.

```stata
cap des lstatus
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:eda3619fe18a4c8b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L283-L283`. Next: `block:36ca26a4aa93e939`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:36ca26a4aa93e939

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L284-L284`. Next: `block:3258a2812c175dde`.

```stata
cap su lstatus,d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:9e4d35708ac3d23c`

### block:3258a2812c175dde

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L285-L285`. Next: `block:e3da6fa10b707b41`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {`

### block:e3da6fa10b707b41

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L286-L286`. Next: `block:3482f0de5ecc0d45`.

```stata
gen _lstatus = "Employed" if lstatus==1 & age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:05b59153577dcaa7`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:5863b3da7602bb54`

### block:3482f0de5ecc0d45

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L287-L287`. Next: `block:f60b1226a7b2f47e`.

```stata
replace _lstatus = "Unemployed" if lstatus==2 & age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:05b59153577dcaa7`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:5863b3da7602bb54`

### block:f60b1226a7b2f47e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L288-L288`. Next: `block:e3ffad124989a862`.

```stata
replace _lstatus = "Not in LF" if lstatus==3 & age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:05b59153577dcaa7`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:5863b3da7602bb54`

### block:e3ffad124989a862

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L289-L289`. Next: `block:d1736048ec89ac9b`.

```stata
replace _lstatus = "MISSING" if missing(lstatus) & age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:05b59153577dcaa7`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:5863b3da7602bb54`

### block:d1736048ec89ac9b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L291-L291`. Next: `block:6d44d08f42efe6f6`.

```stata
gen _lstatus2 = "Employed" if lstatus==1 & age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:32b9baeb7a4b5cc1`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:5863b3da7602bb54`

### block:6d44d08f42efe6f6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L292-L292`. Next: `block:5892bf22cbb1e248`.

```stata
replace _lstatus2 = "Non-employed" if (lstatus==2|lstatus==3) & age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:32b9baeb7a4b5cc1`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:5863b3da7602bb54`

### block:5892bf22cbb1e248

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L293-L293`. Next: `block:a0f93d494c406e5a`.

```stata
replace _lstatus2 = "MISSING" if missing(lstatus) & age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`
Modified: `variable:32b9baeb7a4b5cc1`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:5863b3da7602bb54`

### block:a0f93d494c406e5a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L294-L294`. Next: `block:b8a7a9e0a3a6239a`.

```stata
local lfsvar _lstatus _lstatus2
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(N)>0 {`

### block:b8a7a9e0a3a6239a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L295-L295`. Next: `block:5130f40579e7114d`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {`

### block:5130f40579e7114d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L296-L296`. Next: `block:713da4b56bda528e`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:713da4b56bda528e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L299-L299`. Next: `block:90fa6a4f56eb58f9`.

```stata
cap des relationharm
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:90fa6a4f56eb58f9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L300-L300`. Next: `block:b917e9541345ef78`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:b917e9541345ef78

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L301-L301`. Next: `block:288e7bf8b6be0eb0`.

```stata
qui tab relationharm
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {`
Read candidates: `variable:996fa74226b053cd`

### block:288e7bf8b6be0eb0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L302-L302`. Next: `block:db4e52e750123915`.

```stata
if r(r)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {`

### block:db4e52e750123915

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L303-L303`. Next: `block:1d00ee9e09af1122`.

```stata
gen _head = relationharm==1 if !missing(relationharm)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {`
New: `variable:61a0a1e8e8962d33`
Read candidates: `variable:996fa74226b053cd`

### block:1d00ee9e09af1122

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L304-L304`. Next: `block:4a82c392f65bd82e`.

```stata
if "`agevar'"~="" {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {`

### block:4a82c392f65bd82e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L305-L305`. Next: `block:d59bf31f107e03b8`.

```stata
clonevar _agegr2Xhh = _agegr2_ if _head==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`
New: `variable:5465b23e4971436a`
Read candidates: `variable:79d7dc9de6a0e049`, `variable:61a0a1e8e8962d33`

### block:d59bf31f107e03b8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L306-L306`. Next: `block:8cda9b74e3ca95f7`.

```stata
local agevar "`agevar' _agegr2Xhh"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:8cda9b74e3ca95f7

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L308-L308`. Next: `block:a6ca25a3071aedf0`.

```stata
clonevar _demo_age_hh = age if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`
New: `variable:f98c70afd71ce47b`
Read candidates: `variable:5863b3da7602bb54`, `variable:61a0a1e8e8962d33`

### block:a6ca25a3071aedf0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L309-L309`. Next: `block:bf671c9a4cfd0cfc`.

```stata
local demohead _demo_age_hh
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:bf671c9a4cfd0cfc

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L311-L311`. Next: `block:80cd6023efeb6916`.

```stata
if "`eduvar'"~="" {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:80cd6023efeb6916

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L312-L312`. Next: `block:8db44e149f67d1b2`.

```stata
clonevar _eduXhh = _educat if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`
New: `variable:c54c07fdd87a697e`
Read candidates: `variable:23c060ac8025d975`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:8db44e149f67d1b2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L313-L313`. Next: `block:18951a4e9cb48ce0`.

```stata
local eduvar "`eduvar' _eduXhh"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`

### block:18951a4e9cb48ce0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L315-L315`. Next: `block:6cab580bf541a914`.

```stata
gen _demo_edu_hh1 = educat4==1 if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`
New: `variable:37253041a5c3b061`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:6cab580bf541a914

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L316-L316`. Next: `block:ef1c890fe2f2bbe7`.

```stata
gen _demo_edu_hh2 = educat4==2 if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`
New: `variable:14318ec98f3d070e`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:ef1c890fe2f2bbe7

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L317-L317`. Next: `block:ff7e0968458639b1`.

```stata
gen _demo_edu_hh3 = educat4==3 if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`
New: `variable:7806f32fc6821a6f`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:ff7e0968458639b1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L318-L318`. Next: `block:23ad5644c15b290a`.

```stata
gen _demo_edu_hh4 = educat4==4 if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`
New: `variable:bf32d78a32050e0c`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:23ad5644c15b290a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L319-L319`. Next: `block:77aedd5aba832071`.

```stata
gen _demo_edu_hh_m = missing(educat4) if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`
New: `variable:89cc1758abc75dc4`
Read candidates: `variable:6cc5cc02f6e16631`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:77aedd5aba832071

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L320-L320`. Next: `block:db428a05df42095b`.

```stata
local demohead "`demohead' _demo_edu_hh1 _demo_edu_hh2 _demo_edu_hh3 _demo_edu_hh4 _demo_edu_hh_m"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`eduvar'"~="" {`

### block:db428a05df42095b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L321-L321`. Next: `block:690a59fda47496c9`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:690a59fda47496c9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L323-L323`. Next: `block:cd0654c4b2a0b2b4`.

```stata
if "`gendervar'"~="" {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:cd0654c4b2a0b2b4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L324-L324`. Next: `block:730d94b0bf74f694`.

```stata
clonevar _maleXhh = _male_ if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`gendervar'"~="" {`
New: `variable:973b8247c4236492`
Read candidates: `variable:b1bef60ce0ff36bf`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:730d94b0bf74f694

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L325-L325`. Next: `block:2e6f40ff9b6ddd90`.

```stata
local gendervar "`gendervar' _maleXhh"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`gendervar'"~="" {`

### block:2e6f40ff9b6ddd90

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L327-L327`. Next: `block:ba84bfcf8066561b`.

```stata
clonevar _demo_male_hh = male if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`gendervar'"~="" {`
New: `variable:00dfa1b46c140d08`
Read candidates: `variable:bf393f9db08069ce`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:ba84bfcf8066561b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L328-L328`. Next: `block:a141068f64569514`.

```stata
local demohead "`demohead' _demo_male_hh"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if "`gendervar'"~="" {`

### block:a141068f64569514

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L329-L329`. Next: `block:829e8f533387bbb0`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:829e8f533387bbb0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L331-L331`. Next: `block:db5785e790dc08ab`.

```stata
cap des marital
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:db5785e790dc08ab

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L332-L332`. Next: `block:6fd408da65bde859`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:6fd408da65bde859

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L333-L333`. Next: `block:99c6846d2f8dc45e`.

```stata
cap su marital,d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`
Read candidates: `variable:49bdc9db99aa4c65`, `variable:9e4d35708ac3d23c`

### block:99c6846d2f8dc45e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L334-L334`. Next: `block:9953a5b5ad02078f`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:9953a5b5ad02078f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L335-L335`. Next: `block:0ee087c3ef56571a`.

```stata
gen _married_head = marital==1 if _head==1 & age>=18 & !missing(age) & !missing(marital)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:044b5d1912dc7d37`
Read candidates: `variable:49bdc9db99aa4c65`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:0ee087c3ef56571a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L336-L336`. Next: `block:1a6a6aa0b02b1470`.

```stata
local demohead "`demohead' _married_head"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 {`

### block:1a6a6aa0b02b1470

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L337-L337`. Next: `block:67675daeab21b62a`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:67675daeab21b62a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L338-L338`. Next: `block:94260854e42b797d`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:94260854e42b797d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L340-L340`. Next: `block:abdd7f797929ad45`.

```stata
local lstatus_ok = 0
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:abdd7f797929ad45

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L341-L341`. Next: `block:79de893b12f4114f`.

```stata
cap des lstatus
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:79de893b12f4114f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L342-L342`. Next: `block:b7a61687e9bb55c6`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:b7a61687e9bb55c6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L343-L343`. Next: `block:289a0e65d8ac4f74`.

```stata
cap su lstatus,d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:9e4d35708ac3d23c`

### block:289a0e65d8ac4f74

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L344-L344`. Next: `block:5f7ee697cdd9cf8a`.

```stata
if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:5f7ee697cdd9cf8a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L345-L345`. Next: `block:49cac81a97a1ca3d`.

```stata
gen _working_head = lstatus==1 if _head==1 & age>=18 & !missing(age) & !missing(lstatus)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:35650da9d30c4fd7`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:49cac81a97a1ca3d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L346-L346`. Next: `block:8da2e0bd56651b4e`.

```stata
gen _notworking_head = (lstatus==2|lstatus==3) if _head==1 & age>=18 & !missing(age) & !missing(lstatus)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:edf55a73bd5e874e`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:8da2e0bd56651b4e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L347-L347`. Next: `block:d9df42fe375ef4be`.

```stata
gen _misslfs_head = missing(lstatus) if _head==1 & age>=18 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 {`
New: `variable:e8a3133f29df02c0`
Read candidates: `variable:069c57dd3c07cf9e`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`

### block:d9df42fe375ef4be

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L348-L348`. Next: `block:2afe78ca6dbcd420`.

```stata
local lstatus_ok = 1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 {`

### block:2afe78ca6dbcd420

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L349-L349`. Next: `block:51ed867f533245b9`.

```stata
local demohead "`demohead' _working_head _notworking_head _misslfs_head"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 {`

### block:51ed867f533245b9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L350-L350`. Next: `block:c56ffbffeb541eaf`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:c56ffbffeb541eaf

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L351-L351`. Next: `block:2f0f670a8b1ac586`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:2f0f670a8b1ac586

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L353-L353`. Next: `block:333e5ff470c6ca2b`.

```stata
cap des industrycat4
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:333e5ff470c6ca2b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L354-L354`. Next: `block:8fac1eca4f3fd261`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:8fac1eca4f3fd261

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L355-L355`. Next: `block:e61512385ca863e2`.

```stata
cap su industrycat4,d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`
Read candidates: `variable:a06654e911372c06`, `variable:9e4d35708ac3d23c`

### block:e61512385ca863e2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L356-L356`. Next: `block:26e50f34fe925490`.

```stata
if r(N)>0 & `lstatus_ok'==1 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:26e50f34fe925490

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L357-L357`. Next: `block:d753aeec483aa853`.

```stata
forv x=1(1)4 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`

### block:d753aeec483aa853

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L358-L358`. Next: `block:6ff509ad29f3ff4d`.

```stata
gen _industry_head`x' = industrycat4==`x' if _head==1 & age>=18 & !missing(age) & !missing(industrycat4) & lstatus==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {` → `forv x=1(1)4 {`
New: `variable:1a19ccfafd03fe62`
Read candidates: `variable:a06654e911372c06`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`, `variable:069c57dd3c07cf9e`

### block:6ff509ad29f3ff4d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L359-L359`. Next: `block:2b000741f8725773`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`

### block:2b000741f8725773

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L360-L360`. Next: `block:b7e3b7961b5bedf0`.

```stata
gen _industry_head_m = missing(industrycat4) if _head==1 & age>=18 & !missing(age) & lstatus==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`
New: `variable:91322958316e3242`
Read candidates: `variable:a06654e911372c06`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`, `variable:069c57dd3c07cf9e`

### block:b7e3b7961b5bedf0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L361-L361`. Next: `block:8c650ce2e70bfed1`.

```stata
local demohead "`demohead' _industry_head1 _industry_head2 _industry_head3 _industry_head4 _industry_head_m"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`

### block:8c650ce2e70bfed1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L362-L362`. Next: `block:0c3777a51ce1aa05`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:0c3777a51ce1aa05

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L363-L363`. Next: `block:2e0b137557288cb9`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:2e0b137557288cb9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L365-L365`. Next: `block:b92865d000936248`.

```stata
cap des empstat
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:b92865d000936248

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L366-L366`. Next: `block:8b0965fb44a3fedd`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:8b0965fb44a3fedd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L367-L367`. Next: `block:0c25b98f34f4267c`.

```stata
cap su empstat,d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`
Read candidates: `variable:f1f4133891883bca`, `variable:9e4d35708ac3d23c`

### block:0c25b98f34f4267c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L368-L368`. Next: `block:845ba177a3105110`.

```stata
if r(N)>0 & `lstatus_ok'==1 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:845ba177a3105110

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L369-L369`. Next: `block:fd24db674fd0cf20`.

```stata
forv x=1(1)5 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`

### block:fd24db674fd0cf20

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L370-L370`. Next: `block:20b57481dd481ad4`.

```stata
gen _empstat_head`x' = empstat==`x' if _head==1 & age>=18 & !missing(age) & !missing(empstat) & lstatus==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {` → `forv x=1(1)5 {`
New: `variable:303559a52a2b9793`
Read candidates: `variable:f1f4133891883bca`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`, `variable:069c57dd3c07cf9e`

### block:20b57481dd481ad4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L371-L371`. Next: `block:9a2c3e122cf2ada2`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`

### block:9a2c3e122cf2ada2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L372-L372`. Next: `block:3e78a70e7b7d7351`.

```stata
gen _empstat_head_m = missing(empstat) if _head==1 & age>=18 & !missing(age) & lstatus==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`
New: `variable:447489c831a38c63`
Read candidates: `variable:f1f4133891883bca`, `variable:61a0a1e8e8962d33`, `variable:5863b3da7602bb54`, `variable:069c57dd3c07cf9e`

### block:3e78a70e7b7d7351

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L373-L373`. Next: `block:42bfbbd00d2c0940`.

```stata
local demohead "`demohead' _empstat_head1 _empstat_head2 _empstat_head3 _empstat_head4 _empstat_head5 _empstat_head_m"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {` → `if r(N)>0 & `lstatus_ok'==1 {`

### block:42bfbbd00d2c0940

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L374-L374`. Next: `block:a0ea6917ae895671`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {` → `if _rc==0 {`

### block:a0ea6917ae895671

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L375-L375`. Next: `block:3a34884b8cb0f53b`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {` → `if "`agevar'"~="" {`

### block:3a34884b8cb0f53b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L376-L376`. Next: `block:7c338a5d20d48fa0`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {` → `if r(r)>0 {`

### block:7c338a5d20d48fa0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L377-L377`. Next: `block:9158f08f097c472d`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `if _rc==0 {`

### block:9158f08f097c472d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L378-L378`. Next: `block:d5116f3c31697557`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:d5116f3c31697557

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L381-L381`. Next: `block:d2a6b7eac26842d9`.

```stata
local services imp_wat_rec imp_san_rec electricity
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:d2a6b7eac26842d9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L382-L382`. Next: `block:32a7f5b1a98b0712`.

```stata
local tmp
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:32a7f5b1a98b0712

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L383-L383`. Next: `block:09c531fadd36b771`.

```stata
foreach var of local services {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:09c531fadd36b771

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L384-L384`. Next: `block:1dec4cdca740ffbd`.

```stata
cap des `var'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local services {`

### block:1dec4cdca740ffbd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L385-L385`. Next: `block:93ce61aba0312acc`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local services {`

### block:93ce61aba0312acc

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L386-L386`. Next: `block:6d7c1e97c9ee297e`.

```stata
cap su `var',d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local services {` → `if _rc==0 {`
Read candidates: `variable:9e4d35708ac3d23c`

### block:6d7c1e97c9ee297e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L387-L387`. Next: `block:1f8b34e9546ddcdf`.

```stata
if r(N)>0 local tmp "`tmp' `var'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local services {` → `if _rc==0 {`

### block:1f8b34e9546ddcdf

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L388-L388`. Next: `block:ac2bf9cf64633539`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local services {`

### block:ac2bf9cf64633539

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L389-L389`. Next: `block:c0778461f98cc43e`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:c0778461f98cc43e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L390-L390`. Next: `block:bfe00bfabbe03dee`.

```stata
local services `tmp'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:bfe00bfabbe03dee

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L392-L392`. Next: `block:026db48aa64e2568`.

```stata
local assets tv car cellphone computer fridge
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:026db48aa64e2568

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L393-L393`. Next: `block:ee86e44d63101423`.

```stata
local tmp
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:ee86e44d63101423

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L394-L394`. Next: `block:fb64e6dc07e8b352`.

```stata
foreach var of local assets {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:fb64e6dc07e8b352

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L395-L395`. Next: `block:214914ba53f83d94`.

```stata
cap des `var'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local assets {`

### block:214914ba53f83d94

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L396-L396`. Next: `block:fcd8ac171cdb3394`.

```stata
if _rc==0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local assets {`

### block:fcd8ac171cdb3394

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L397-L397`. Next: `block:9189b858dd74b70a`.

```stata
cap su `var' if `touse',d
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local assets {` → `if _rc==0 {`
Read candidates: `variable:9e4d35708ac3d23c`

### block:9189b858dd74b70a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L398-L398`. Next: `block:c0efb1e189aa3ee2`.

```stata
if r(N)>0 local tmp "`tmp' `var'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local assets {` → `if _rc==0 {`

### block:c0efb1e189aa3ee2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L399-L399`. Next: `block:eb5648bca3bcd057`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach var of local assets {`

### block:eb5648bca3bcd057

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L400-L400`. Next: `block:61f73c8ebcec510a`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:61f73c8ebcec510a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L401-L401`. Next: `block:826baceecab8c875`.

```stata
local assets `tmp'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:826baceecab8c875

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L403-L403`. Next: `block:2a7c8afb7de31de4`.

```stata
local demolist `demohead' `services' `assets'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:2a7c8afb7de31de4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L404-L404`. Next: `block:20bb3f3e7093cedc`.

```stata
local demolist : list uniq demolist
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:20bb3f3e7093cedc

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L406-L406`. Next: `block:3d41c03d2e1653c1`.

```stata
local oklist2 _all_ `urbvar' `gendervar' `agevar' `agegender' `eduvar' `lfsvar'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:3d41c03d2e1653c1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L407-L407`. Next: `block:f1d67e7c0303755a`.

```stata
local oklist2 : list uniq oklist2
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:f1d67e7c0303755a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L410-L410`. Next: `block:3ff12937636c87f6`.

```stata
local byind _total
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:3ff12937636c87f6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L411-L411`. Next: `block:fc03d4b764333306`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:fc03d4b764333306

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L412-L412`. Next: `block:c59a911d9b3d867f`.

```stata
gen double __a`ppp1' = welfare/cpi`ppp1'/icp`ppp1'/365
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {`
New: `variable:b361a6f86d72e067`
Read candidates: `variable:00cf972495fa42e5`, `variable:56e5b75b3ff72050`, `variable:07b5a6bd848785c3`

### block:c59a911d9b3d867f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L414-L414`. Next: `block:f2260c3642afceea`.

```stata
replace __a`ppp1' = ${floor`ppp1'} if __a`ppp1' < ${floor`ppp1'}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {`
Modified: `variable:b361a6f86d72e067`
Read candidates: `variable:b21c9dced0e59704`, `variable:b361a6f86d72e067`

### block:f2260c3642afceea

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L416-L416`. Next: `block:7bba0c336922b904`.

```stata
foreach num of numlist ${plines`ppp1'} {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {`

### block:7bba0c336922b904

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L417-L417`. Next: `block:dbf0e6098a07fd17`.

```stata
gen double poor`num' = __a`ppp1' < `=`num'/100' if __a`ppp1' ~=.
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
New: `variable:1611ddb144f9c483`
Read candidates: `variable:b361a6f86d72e067`

### block:dbf0e6098a07fd17

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L418-L418`. Next: `block:52552c6a9dd26583`.

```stata
local byind "`byind' poor`num'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:52552c6a9dd26583

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L419-L419`. Next: `block:261e20e3b755601e`.

```stata
gen double gap1_`num' = (`=`num'/100' - __a`ppp1')/  `=`num'/100'  *  poor`num'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`
New: `variable:94862c923be11dd8`
Read candidates: `variable:b361a6f86d72e067`, `variable:1611ddb144f9c483`

### block:261e20e3b755601e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L420-L420`. Next: `block:a02e3f559f2dffb1`.

```stata
forv s=2(1)2 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:a02e3f559f2dffb1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L421-L421`. Next: `block:5ad1b592c7e725b5`.

```stata
gen double gap`s'_`num' = (gap1_`num')^`s'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {` → `forv s=2(1)2 {`
New: `variable:8e6ee07704fc9943`
Read candidates: `variable:94862c923be11dd8`

### block:5ad1b592c7e725b5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L422-L422`. Next: `block:93cfe5041f2dcdd6`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {` → `foreach num of numlist ${plines`ppp1'} {`

### block:93cfe5041f2dcdd6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L423-L423`. Next: `block:a009381141406246`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {`

### block:a009381141406246

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L425-L425`. Next: `block:a5373fd832c7286d`.

```stata
gen prosgap`ppp1' = ${gap`ppp1'}/__a`ppp1'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `foreach ppp1 of global ppplist {`
New: `variable:5626aca9be4146a0`
Read candidates: `variable:27494085f88e671d`, `variable:b361a6f86d72e067`

### block:a5373fd832c7286d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L426-L426`. Next: `block:b91055f0a010a4fb`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:b91055f0a010a4fb

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L429-L429`. Next: `block:a52d26d7d6e6cb74`.

```stata
cap drop tmp
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
Read candidates: `variable:6f0e84b7e3fa969e`

### block:a52d26d7d6e6cb74

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L430-L430`. Next: `block:de20120541206a04`.

```stata
_ebin __a${pppmax} [aw=`wgt'], gen(tmp) nq(5)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:6f0e84b7e3fa969e`
Read candidates: `variable:344f04fa02f50453`

### block:de20120541206a04

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L431-L431`. Next: `block:06be658472fe2b3e`.

```stata
gen poor_b40 = tmp <=2 if tmp~=.
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:5d8af76c9f7576c7`
Read candidates: `variable:6f0e84b7e3fa969e`

### block:06be658472fe2b3e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L432-L432`. Next: `block:6e706388c3a7bfef`.

```stata
forv s=1(1)5 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:6e706388c3a7bfef

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L433-L433`. Next: `block:259cafbf8e2d4e3c`.

```stata
gen poor_d`s' = tmp ==`s' if tmp~=.
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `forv s=1(1)5 {`
New: `variable:de73d95ceb6945b4`
Read candidates: `variable:6f0e84b7e3fa969e`

### block:259cafbf8e2d4e3c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L434-L434`. Next: `block:af3453606ed534c1`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:af3453606ed534c1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L435-L435`. Next: `block:6abac44ade444bf8`.

```stata
drop tmp
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
Read candidates: `variable:6f0e84b7e3fa969e`

### block:6abac44ade444bf8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L438-L438`. Next: `block:ce765f7e3394328b`.

```stata
gen double h = `wgt'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:b019e65843556b85`

### block:ce765f7e3394328b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L439-L439`. Next: `block:2417ea0ba77c5d11`.

```stata
gen double h1564 = `wgt' if age>=15 & age<=64
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:371546becb2b54b6`
Read candidates: `variable:5863b3da7602bb54`

### block:2417ea0ba77c5d11

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L440-L440`. Next: `block:107874b403635bad`.

```stata
gen double h15p = `wgt' if age>=15 & !missing(age)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:d7f0bb985d2bd799`
Read candidates: `variable:5863b3da7602bb54`

### block:107874b403635bad

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L441-L441`. Next: `block:b075ee257b7e043b`.

```stata
gen b40 = `wgt' if poor_b40==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:4f44fa77d88d53ce`
Read candidates: `variable:5d8af76c9f7576c7`

### block:b075ee257b7e043b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L442-L442`. Next: `block:0833be1b29e7d31c`.

```stata
gen t60 = `wgt' if poor_b40==0
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:03f63392696d6ed4`
Read candidates: `variable:5d8af76c9f7576c7`

### block:0833be1b29e7d31c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L443-L443`. Next: `block:c1bc398fd9f019a8`.

```stata
forv s=1(1)5 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:c1bc398fd9f019a8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L444-L444`. Next: `block:c9039c7181df72e2`.

```stata
gen d_`s' = `wgt' if poor_d`s'==1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {` → `forv s=1(1)5 {`
New: `variable:c931190e9fec260f`
Read candidates: `variable:de73d95ceb6945b4`

### block:c9039c7181df72e2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L445-L445`. Next: `block:18ed72c9bd0969a5`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`

### block:18ed72c9bd0969a5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L448-L448`. Next: `block:a1f74e9f032d1cbd`.

```stata
clonevar b1= __a${pppmax}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:cee2067c4cd6ca92`
Read candidates: `variable:344f04fa02f50453`

### block:a1f74e9f032d1cbd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L449-L449`. Next: `block:8ec00bbdee142b0e`.

```stata
clonevar b2= __a${pppmax}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:46a7a74f35fe2567`
Read candidates: `variable:344f04fa02f50453`

### block:8ec00bbdee142b0e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L450-L450`. Next: `block:a19ef8f107909c04`.

```stata
gen _count=1
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `qui {`
New: `variable:8fb83aa6758841b5`

### block:a19ef8f107909c04

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L451-L451`. Next: `block:909f29fe4fb1cf4c`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:909f29fe4fb1cf4c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L453-L453`. Next: `block:5e3d70e88623dba1`.

```stata
cap erase `data2'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:5e3d70e88623dba1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L454-L454`. Next: `block:45d54e9cb8a7df79`.

```stata
tempfile data2
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:45d54e9cb8a7df79

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L455-L455`. Next: `block:d3cdb0ab9336d41d`.

```stata
save `data2', replace
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`
Write datasets: `dataset:93e4de04cf6bb473`

### block:d3cdb0ab9336d41d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L458-L458`. Next: `block:8fc1261d0ecfb4e6`.

```stata
foreach lvl of local oklist2 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:8fc1261d0ecfb4e6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L459-L459`. Next: `block:88f407491ef142aa`.

```stata
use `data2', clear
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {`
Read datasets: `dataset:93e4de04cf6bb473`

### block:88f407491ef142aa

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L460-L460`. Next: `block:9b8e87d87f708aa9`.

```stata
qui ta `lvl'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {`

### block:9b8e87d87f708aa9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L461-L461`. Next: `block:79188f49a53fa1e2`.

```stata
qui if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {`

### block:79188f49a53fa1e2

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L462-L462`. Next: `block:752ff80173552ed4`.

```stata
noi dis in yellow "`i'-1-`code'-`year'-`surveyid'-`mod' - `lvlvar' - `lvl'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`

### block:752ff80173552ed4

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L463-L463`. Next: `block:34aab60dcd443c4a`.

```stata
cap replace `lvl'="Out of sample" if `lvl'==""
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Modified: `variable:b2bc6c70ce24a279`
Read candidates: `variable:6f4fed42b352384f`

### block:34aab60dcd443c4a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L464-L464`. Next: `block:c6ebd2b4317abedd`.

```stata
cap replace `lvl'="Out of sample" if `lvl'==".-"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Modified: `variable:b2bc6c70ce24a279`
Read candidates: `variable:6f4fed42b352384f`

### block:c6ebd2b4317abedd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L467-L467`. Next: `block:b90b2125d964441c`.

```stata
groupfunction  [aw=`wgt'], mean(__a* poor* gap* prosgap*) rawsum(_count h h1564 h15p b40 t60 d_*) count(year) gini(b1) theil(b2) by(`lvl')
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Read candidates: `variable:014570454d2363b7`, `variable:977c3918b1181639`, `variable:a03cd861ff9d0f64`, `variable:878c9f0208250431`, `variable:8c08e2d7fcf2567c`, `variable:039356b29d830f68`, `variable:4693abdb38e8ff96`, `variable:d809dce5dfe1f43b`, `variable:53b1c8c862813b6c`, `variable:5c1f4549ce505a89`, `variable:6f4575cdd519d5e6`, `variable:ef77a98ea4904213`, `variable:7673d00442b772aa`, `variable:929d939050c606ce`

### block:b90b2125d964441c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L470-L470`. Next: `block:f44b4887013306c1`.

```stata
drop if `lvl'=="Out of sample"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`

### block:f44b4887013306c1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L472-L472`. Next: `block:3193f2164009f53d`.

```stata
ren _count count
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:18530aea3640e05f`
Read candidates: `variable:8c08e2d7fcf2567c`

### block:3193f2164009f53d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L473-L473`. Next: `block:030f2fff6b293b31`.

```stata
ren year nohh
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:3d99b4001097d8d4`
Read candidates: `variable:ef77a98ea4904213`

### block:030f2fff6b293b31

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L474-L474`. Next: `block:d855f67db9b7ae4d`.

```stata
ren h noind
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:5c55b3ddd52faa0c`
Read candidates: `variable:039356b29d830f68`

### block:d855f67db9b7ae4d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L475-L475`. Next: `block:86d1c83d0c1fcccd`.

```stata
ren h1564 noind1564
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:4ccf9edebde1caf9`
Read candidates: `variable:4693abdb38e8ff96`

### block:86d1c83d0c1fcccd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L476-L476`. Next: `block:d26a710e0c90baf1`.

```stata
ren h15p noind15p
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:6f0bc28c8548d6ff`
Read candidates: `variable:d809dce5dfe1f43b`

### block:d26a710e0c90baf1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L478-L478`. Next: `block:8b3135b05e8d0a54`.

```stata
egen double totalhh = total(nohh)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:b1f0cd83a7b9f6c2`
Read candidates: `variable:3d99b4001097d8d4`

### block:8b3135b05e8d0a54

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L479-L479`. Next: `block:34bdcb31bc5322f6`.

```stata
egen double totalind = total(noind)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:574b2b33d81afbf6`
Read candidates: `variable:5c55b3ddd52faa0c`

### block:34bdcb31bc5322f6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L480-L480`. Next: `block:1522ca24c8f9bf3c`.

```stata
egen double totalind1564 = total(noind1564)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:828ddf33775b03bf`
Read candidates: `variable:4ccf9edebde1caf9`

### block:1522ca24c8f9bf3c

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L481-L481`. Next: `block:617cbe401f67df84`.

```stata
egen double totalind15p = total(noind15p)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:de227be126df6f7b`
Read candidates: `variable:6f0bc28c8548d6ff`

### block:617cbe401f67df84

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L482-L482`. Next: `block:21a865138bf5db4f`.

```stata
egen double totalb40 = total(b40)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:8720497c5587e0eb`
Read candidates: `variable:53b1c8c862813b6c`

### block:21a865138bf5db4f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L483-L483`. Next: `block:108835d9c2e942fa`.

```stata
egen double totalt60 = total(t60)
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:d599abfe048041ee`
Read candidates: `variable:5c1f4549ce505a89`

### block:108835d9c2e942fa

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L484-L484`. Next: `block:1dbb89f77e243af7`.

```stata
gen sh_hh = nohh/totalhh
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:2e327440ef995544`
Read candidates: `variable:3d99b4001097d8d4`, `variable:b1f0cd83a7b9f6c2`

### block:1dbb89f77e243af7

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L485-L485`. Next: `block:b1a7122e7cc065be`.

```stata
gen sh_pop = noind/totalind
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:bfd52ca16046e0e8`
Read candidates: `variable:5c55b3ddd52faa0c`, `variable:574b2b33d81afbf6`

### block:b1a7122e7cc065be

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L486-L486`. Next: `block:8f229945f5c82e23`.

```stata
gen sh_pop1564 = noind1564/totalind1564
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:e23be44eb563e33c`
Read candidates: `variable:4ccf9edebde1caf9`, `variable:828ddf33775b03bf`

### block:8f229945f5c82e23

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L487-L487`. Next: `block:7409c4d3660bb683`.

```stata
gen sh_pop15p = noind15p/totalind15p
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:e686415fe5066606`
Read candidates: `variable:6f0bc28c8548d6ff`, `variable:de227be126df6f7b`

### block:7409c4d3660bb683

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L488-L488`. Next: `block:282769ac48dadff9`.

```stata
gen sh_b40 = b40/totalb40
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:911abe111d017d26`
Read candidates: `variable:53b1c8c862813b6c`, `variable:8720497c5587e0eb`

### block:282769ac48dadff9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L489-L489`. Next: `block:51d2eff2ebd33fa0`.

```stata
gen sh_t60 = t60/totalt60
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:aa1e5ee0c95102e3`
Read candidates: `variable:5c1f4549ce505a89`, `variable:d599abfe048041ee`

### block:51d2eff2ebd33fa0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L490-L490`. Next: `block:a356e990794c300a`.

```stata
forv it=1(1)5 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`

### block:a356e990794c300a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L491-L491`. Next: `block:eeba70aaf93a9598`.

```stata
egen double total_d_`it' = total(d_`it')
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {` → `forv it=1(1)5 {`
New: `variable:e09ad65b23e2caef`
Read candidates: `variable:c29143621907da7f`

### block:eeba70aaf93a9598

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L492-L492`. Next: `block:bb2657e65e283090`.

```stata
gen sh_d_`it' = d_`it'/total_d_`it'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {` → `forv it=1(1)5 {`
New: `variable:5537bf6ab0978059`
Read candidates: `variable:c29143621907da7f`, `variable:e09ad65b23e2caef`

### block:bb2657e65e283090

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L493-L493`. Next: `block:10733ff09674e4aa`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`

### block:10733ff09674e4aa

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L495-L495`. Next: `block:9f2366587ce64773`.

```stata
foreach ppp1 of global ppplist {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`

### block:9f2366587ce64773

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L496-L496`. Next: `block:b64a17ead40c1105`.

```stata
ren __a`ppp1' mean`ppp1'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {` → `foreach ppp1 of global ppplist {`
New: `variable:28a46fb35c616bc3`
Read candidates: `variable:6a539cea0ad1f233`

### block:b64a17ead40c1105

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L497-L497`. Next: `block:6e85a14a129088ee`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`

### block:6e85a14a129088ee

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L499-L499`. Next: `block:410b2e7e57d536ce`.

```stata
ren b1 gini
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:005bea41b192a81f`
Read candidates: `variable:7673d00442b772aa`

### block:410b2e7e57d536ce

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L500-L500`. Next: `block:47bf22d1ad276e0b`.

```stata
ren b2 theil
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:3e48caf6cde7aed4`
Read candidates: `variable:929d939050c606ce`

### block:47bf22d1ad276e0b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L501-L501`. Next: `block:d60d5a6154678017`.

```stata
gen byvar = "`lvl'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:be93ee5260166f21`

### block:d60d5a6154678017

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L502-L502`. Next: `block:dcec5045009f6652`.

```stata
gen lvlvar = "`lvlvar'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:75ab6925e8ddee76`

### block:dcec5045009f6652

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L503-L503`. Next: `block:aac2cd0b49471bfd`.

```stata
ren `lvl' level
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:eebd1f6f089e7fa7`
Read candidates: `variable:b2bc6c70ce24a279`

### block:aac2cd0b49471bfd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L504-L504`. Next: `block:48cf1a445b214b56`.

```stata
tostring level, replace
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Modified: `variable:eebd1f6f089e7fa7`
Read candidates: `variable:eebd1f6f089e7fa7`

### block:48cf1a445b214b56

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L505-L505`. Next: `block:8db3879f1b037861`.

```stata
gen code = "`code'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:f1a438fee2f35b29`

### block:8db3879f1b037861

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L506-L506`. Next: `block:1a95180729138687`.

```stata
gen surveyid = "`surveyid'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:25e259bbec1f06be`

### block:1a95180729138687

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L507-L507`. Next: `block:1eb2adf7b733cd4a`.

```stata
gen year = `year'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:ef77a98ea4904213`

### block:1eb2adf7b733cd4a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L508-L508`. Next: `block:232bd6a29fc98bd0`.

```stata
gen mod = "`mod'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
New: `variable:8e0f8fa2831ba717`

### block:232bd6a29fc98bd0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L509-L509`. Next: `block:881b37991719e265`.

```stata
drop  d_* total_d_* b40 t60 totalb40 totalt60
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Read candidates: `variable:6f4575cdd519d5e6`, `variable:1c271e13d1068bef`, `variable:53b1c8c862813b6c`, `variable:5c1f4549ce505a89`, `variable:8720497c5587e0eb`, `variable:d599abfe048041ee`

### block:881b37991719e265

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L511-L511`. Next: `block:9afd75f942f3af1f`.

```stata
append using `dataall'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Read datasets: `dataset:09d0e95ba6dcc51c`

### block:9afd75f942f3af1f

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L512-L512`. Next: `block:4ba2a4368c71e0a0`.

```stata
save `dataall', replace
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Write datasets: `dataset:09d0e95ba6dcc51c`

### block:4ba2a4368c71e0a0

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L513-L513`. Next: `block:24e21d559ffe7be6`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_allgroups1", replace
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {` → `qui if r(N)>0 {`
Write datasets: `dataset:1a291c72644c9300`

### block:24e21d559ffe7be6

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L514-L514`. Next: `block:78cc958301006bd1`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local oklist2 {`

### block:78cc958301006bd1

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L515-L515`. Next: `block:f1cb056d97d14c31`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:f1cb056d97d14c31

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L518-L518`. Next: `block:702cee07ad94fd59`.

```stata
cap erase `data3'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:702cee07ad94fd59

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L519-L519`. Next: `block:53358d0d810a481b`.

```stata
tempfile data3
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:53358d0d810a481b

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L520-L520`. Next: `block:275134223bae818d`.

```stata
foreach lvl of local byind {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:275134223bae818d

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L521-L521`. Next: `block:8ca55d09e6dddaad`.

```stata
use `data2', clear
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {`
Read datasets: `dataset:93e4de04cf6bb473`

### block:8ca55d09e6dddaad

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L522-L522`. Next: `block:b522ea79db09e100`.

```stata
qui ta `lvl'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {`

### block:b522ea79db09e100

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L523-L523`. Next: `block:69f7f4750ffc52c8`.

```stata
qui if r(N)>0 {
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {`

### block:69f7f4750ffc52c8

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L524-L524`. Next: `block:ad0293b7c68993ce`.

```stata
noi dis in yellow "`i'-2-`code'-`year'-`surveyid'-`mod' - `lvlvar' - `lvl'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`

### block:ad0293b7c68993ce

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L527-L527`. Next: `block:0ef543bc9366ec33`.

```stata
groupfunction  [aw=`wgt'], mean(`demolist') rawsum(h) count(_count)  by(`lvl')
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
Read candidates: `variable:576753579fec5af0`, `variable:32442e9eb1e11e94`

### block:0ef543bc9366ec33

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L529-L529`. Next: `block:0a107cf08805eddf`.

```stata
ren `lvl' _bygroup
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
New: `variable:9087b9199935f1f5`
Read candidates: `variable:892a5c7b5e3b9024`

### block:0a107cf08805eddf

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L530-L530`. Next: `block:98ca4f792bdc7da5`.

```stata
gen _varname = "`lvl'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
New: `variable:6b87703df3b5710b`

### block:98ca4f792bdc7da5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L531-L531`. Next: `block:0974c2d553726cde`.

```stata
ren h _pop
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
New: `variable:f4b18f2d5320cf2c`
Read candidates: `variable:576753579fec5af0`

### block:0974c2d553726cde

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L532-L532`. Next: `block:4e2abb996bb0a2cc`.

```stata
gen code = "`code'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
New: `variable:e12750784aef88e4`

### block:4e2abb996bb0a2cc

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L533-L533`. Next: `block:a2f659db3954ca52`.

```stata
gen surveyid = "`surveyid'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
New: `variable:21b05dead29a6229`

### block:a2f659db3954ca52

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L534-L534`. Next: `block:82bf9a810f12d4d9`.

```stata
gen year = `year'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
New: `variable:55d69df355d46996`

### block:82bf9a810f12d4d9

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L535-L535`. Next: `block:223798965437ec50`.

```stata
gen mod = "`mod'"
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
New: `variable:bf591b8a4e64be60`

### block:223798965437ec50

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L536-L536`. Next: `block:2967380487145032`.

```stata
append using `dataall2'
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
Read datasets: `dataset:6869c66e344fc9c0`

### block:2967380487145032

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L537-L537`. Next: `block:cf9d8ff50defbad5`.

```stata
save `dataall2', replace
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
Write datasets: `dataset:6869c66e344fc9c0`

### block:cf9d8ff50defbad5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L538-L538`. Next: `block:86049e2323fd15e3`.

```stata
save "${out}\\03.intermediate\\GMI_extended_${rnd}_PNP1", replace
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {` → `qui if r(N)>0 {`
Write datasets: `dataset:101da30021cb4578`

### block:86049e2323fd15e3

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L552-L552`. Next: `block:0ac4eb0cacf6fc03`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {` → `foreach lvl of local byind {`

### block:0ac4eb0cacf6fc03

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L553-L553`. Next: `block:b4ce82384ee56a8a`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {` → `qui if _rc==0 {`

### block:b4ce82384ee56a8a

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L554-L554`. Next: `block:a230e728afd0e5ab`.

```stata
}
```
Enclosing controls: `forv i=`resume'(1)`nobs' {`

### block:a230e728afd0e5ab

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L555-L555`. Next: `block:e7ce153a8bbe6c67`.

```stata
}
```

### block:e7ce153a8bbe6c67

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L557-L557`. Next: `block:4ed5db8dd90980fd`.

```stata
use `dataall', clear
```
Read datasets: `dataset:09d0e95ba6dcc51c`

### block:4ed5db8dd90980fd

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L558-L558`. Next: `block:0dd93313be6d96ab`.

```stata
order code year surveyid lvlvar byvar level count
```

### block:0dd93313be6d96ab

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L559-L559`. Next: `block:9cef7463e9c70b36`.

```stata
sort code year surveyid lvlvar byvar level
```

### block:9cef7463e9c70b36

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L560-L560`. Next: `block:40fc03f5e666fbf7`.

```stata
s
```

### block:40fc03f5e666fbf7

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L561-L561`. Next: `block:b087fd9413cbdbbb`.

```stata
use "${out}\\Subnational_2017ICP_${rnd}_rev", clear
```
Read datasets: `dataset:485cadd7413edee9`

### block:b087fd9413cbdbbb

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L562-L562`. Next: `block:c5590a1cd2b2dd99`.

```stata
replace survname="ECH-S2" if survname=="ECH" & year==0000
```
Modified: `variable:33f83efa9180ace6`
Read candidates: `variable:33f83efa9180ace6`, `variable:686b916722ee3c48`

### block:c5590a1cd2b2dd99

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L563-L563`. Next: `block:f17802ea973b08a5`.

```stata
replace level = "National" if level=="1" & byvar=="_all_"
```
Modified: `variable:d58f14061b84c017`
Read candidates: `variable:d58f14061b84c017`, `variable:4325b42813aa36f9`

### block:f17802ea973b08a5

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L564-L564`. Next: `block:887de915c1f93b96`.

```stata
merge m:1 code year survname using $pfw , keepus(rep_year ref_year reg_pcn survey_coverage datatype comparability link)
```
Read datasets: `dataset:0fa1cc3d12b9e4be`

### block:887de915c1f93b96

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L565-L565`. Next: `block:3da4fc1d949efa94`.

```stata
drop if _m==2
```
Read candidates: `variable:75108191730f60f6`

### block:3da4fc1d949efa94

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L566-L566`. Next: `block:121df747571f5068`.

```stata
drop _m
```
Read candidates: `variable:75108191730f60f6`

### block:121df747571f5068

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L567-L567`. Next: `block:01eb9a49147cb616`.

```stata
order reg_pcn code year surveyid survname  byvar level link survey_coverage datatype comparability poor* nohh noind totalhh totalind sh_hh sh_pop  sh_d_* mean* gini theil
```

### block:01eb9a49147cb616

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L568-L568`. Next: `block:91109a141ddb3b0e`.

```stata
sort code year surveyid byvar level
```

### block:91109a141ddb3b0e

Evidence: `01.Programs/archive/01aa-GMI extended indicators.do:L569-L569`. Next: `end`.

```stata
br
```
